#ifndef __INC_SBXMLSOAP
#define __INC_SBXMLSOAP

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbcryptoprov.h"
#include "sbcustomcertstorage.h"
#include "sbdc.h"
#include "sbdcdef.h"
#include "sbdcsec.h"
#include "sbrandom.h"
#include "sbstreams.h"
#include "sbstrutils.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbx509.h"
#include "sbxmldefs.h"
#include "sbxmlcore.h"
#include "sbxmlsec.h"
#include "sbxmlsig.h"
#include "sbxmlutils.h"
#include "sbxmlades.h"
#include "sbxmladesintf.h"
#include "sbxmlsoapcore.h"
#include "sbxmlwsscore.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SSOAPMessageNotLoaded 	"SOAP message is not loaded"
#define SB_SSOAPSecurityHandlerAlreadyRegistered 	"Security handler already registered"
#define SB_SSOAPNoCertificate 	"No certificate"
#define SB_SSOAPNoKeyData 	"No key data"
#define SB_SSOAPCannotValidateSignatureNotCalculated 	"Cannot validate (signature is not calculated)"
#define SB_SSOAPCannotSignSignatureCalculated 	"Cannot sign (signature already calculated)"
#define SB_SSOAPSignatureHandlerNotAttached 	"The signature handler is not attached to the envelope"
#define SB_SSOAPNothingToSign 	"Nothing to sign"
#define SB_SSOAPUnsupportedCertificatePublicKeyAlg 	"Unsupported certificate public key algorithm"
#define SB_SSOAPCannotCompleteAsyncSignNoSignature 	"Cannot complete async sign (no signature)"
#define SB_SSOAPNotImplemented 	"Not implemented"
#define SB_SSOAPTargetElementHasNoId 	"The target element doesn\'t have an Id"

typedef TElClassHandle TElXMLSOAPMessageHandle;

typedef TElClassHandle TElXMLSOAPCustomSignatureHandlerHandle;

typedef TElClassHandle TElXMLSOAPBaseSignatureHandlerHandle;

typedef TElClassHandle TElXMLSOAPSignatureHandlerClassHandle;

typedef uint8_t TSBXMLSOAPSignatureValidationStatusRaw;

typedef enum
{
	ssvsUnknown = 0,
	ssvsValid = 1,
	ssvsInvalidSignature = 2,
	ssvsInvalidReferenceDigest = 3,
	ssvsNoKey = 4
} TSBXMLSOAPSignatureValidationStatus;

typedef void (SB_CALLBACK *TSBXMLSOAPSignEvent)(void * _ObjectData, TObjectHandle Sender, TElXMLSignerHandle Signer);

#ifdef SB_USE_CLASS_TELXMLSOAPMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_Clear(TElXMLSOAPMessageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_CreateEnvelope(TElXMLSOAPMessageHandle _Handle, TElXMLDOMDocumentHandle Document, TSBXMLSOAPVersionRaw Version);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_CreateEnvelope_1(TElXMLSOAPMessageHandle _Handle, TElXMLDOMDocumentHandle Document, TSBXMLSOAPVersionRaw Version, const char * pcSOAPPrefix, int32_t szSOAPPrefix);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_CreateEnvelope_2(TElXMLSOAPMessageHandle _Handle, TElXMLDOMElementHandle ParentElement, TSBXMLSOAPVersionRaw Version);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_CreateEnvelope_3(TElXMLSOAPMessageHandle _Handle, TElXMLDOMElementHandle ParentElement, TSBXMLSOAPVersionRaw Version, const char * pcSOAPPrefix, int32_t szSOAPPrefix);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_LoadFromXML(TElXMLSOAPMessageHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_LoadFromXML_1(TElXMLSOAPMessageHandle _Handle, TElXMLDOMDocumentHandle Document);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_CompleteAsyncSign(TElXMLSOAPMessageHandle _Handle, TElXMLSOAPCustomSignatureHandlerHandle Handler, TElDCAsyncStateHandle State);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_AddSignature(TElXMLSOAPMessageHandle _Handle, TElXMLSOAPCustomSignatureHandlerHandle Handler, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_AddSignature_1(TElXMLSOAPMessageHandle _Handle, TElXMLSOAPCustomSignatureHandlerHandle Handler, int8_t OwnHandler, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_RemoveSignature(TElXMLSOAPMessageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_AddSecurityHeader(TElXMLSOAPMessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_RemoveSecurityHeader(TElXMLSOAPMessageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_get_Envelope(TElXMLSOAPMessageHandle _Handle, TElXMLSOAPEnvelopeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_get_SOAPVersion(TElXMLSOAPMessageHandle _Handle, TSBXMLSOAPVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_get_IsSigned(TElXMLSOAPMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_get_SignatureHandlerCount(TElXMLSOAPMessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_get_SecurityHeaderCount(TElXMLSOAPMessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_get_SignatureHandlers(TElXMLSOAPMessageHandle _Handle, int32_t Index, TElXMLSOAPCustomSignatureHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_get_SecurityHeaders(TElXMLSOAPMessageHandle _Handle, int32_t Index, TElXMLWSSESecurityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPMessage_Create(TComponentHandle AOwner, TElXMLSOAPMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPMESSAGE */

#ifdef SB_USE_CLASS_TELXMLSOAPCUSTOMSIGNATUREHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomSignatureHandler_GetName(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomSignatureHandler_GetName_1(TElXMLSOAPCustomSignatureHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomSignatureHandler_LoadFromXML(TElXMLSOAPCustomSignatureHandlerHandle _Handle, TElXMLDOMElementHandle SignatureElement, TElXMLSOAPMessageHandle Msg);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomSignatureHandler_Reset(TElXMLSOAPCustomSignatureHandlerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomSignatureHandler_CompleteAsyncSign(TElXMLSOAPCustomSignatureHandlerHandle _Handle, TElDCAsyncStateHandle State);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomSignatureHandler_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomSignatureHandler_get_SOAPMessage(TElXMLSOAPCustomSignatureHandlerHandle _Handle, TElXMLSOAPMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomSignatureHandler_get_XMLElement(TElXMLSOAPCustomSignatureHandlerHandle _Handle, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomSignatureHandler_get_CryptoProviderManager(TElXMLSOAPCustomSignatureHandlerHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomSignatureHandler_set_CryptoProviderManager(TElXMLSOAPCustomSignatureHandlerHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomSignatureHandler_get_IsCalculated(TElXMLSOAPCustomSignatureHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomSignatureHandler_Create(TComponentHandle Owner, TElXMLSOAPCustomSignatureHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPCUSTOMSIGNATUREHANDLER */

#ifdef SB_USE_CLASS_TELXMLSOAPBASESIGNATUREHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_GetName(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_GetName_1(TElXMLSOAPBaseSignatureHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_LoadFromXML(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle SignatureElement, TElXMLSOAPMessageHandle Msg);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_Reset(TElXMLSOAPBaseSignatureHandlerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_1(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElX509CertificateHandle Certificate, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_2(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElX509CertificateHandle Certificate, int8_t IncludeKey, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_3(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElX509CertificateHandle Certificate, int8_t IncludeKey, int8_t IncludeKeyValue, TElXMLKeyInfoX509DataParamsRaw IncludeDataParams, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_4(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElCustomCertStorageHandle CertStorage, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_5(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElCustomCertStorageHandle CertStorage, int8_t IncludeKey, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_6(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElCustomCertStorageHandle CertStorage, int8_t IncludeKey, int8_t IncludeKeyValue, TElXMLKeyInfoX509DataParamsRaw IncludeDataParams, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_7(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElXMLKeyInfoDataHandle KeyData, TElXMLSignatureMethodRaw SignatureMethod, int8_t IncludeKey, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_8(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElDCParametersHandle Pars, TElXMLDOMElementHandle ParentElement, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_9(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElDCParametersHandle Pars, TElXMLDOMElementHandle ParentElement, TElX509CertificateHandle Certificate, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_10(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElDCParametersHandle Pars, TElXMLDOMElementHandle ParentElement, TElX509CertificateHandle Certificate, int8_t IncludeKey, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_11(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElDCParametersHandle Pars, TElXMLDOMElementHandle ParentElement, TElX509CertificateHandle Certificate, int8_t IncludeKey, int8_t IncludeKeyValue, TElXMLKeyInfoX509DataParamsRaw IncludeDataParams, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_12(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElDCParametersHandle Pars, TElXMLDOMElementHandle ParentElement, TElCustomCertStorageHandle CertStorage, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_13(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElDCParametersHandle Pars, TElXMLDOMElementHandle ParentElement, TElCustomCertStorageHandle CertStorage, int8_t IncludeKey, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_14(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElDCParametersHandle Pars, TElXMLDOMElementHandle ParentElement, TElCustomCertStorageHandle CertStorage, int8_t IncludeKey, int8_t IncludeKeyValue, TElXMLKeyInfoX509DataParamsRaw IncludeDataParams, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_15(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElDCParametersHandle Pars, TElXMLDOMElementHandle ParentElement, TElXMLKeyInfoDataHandle KeyData, TElXMLSignatureMethodRaw SignatureMethod, int8_t IncludeKey, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_16(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElX509CertificateHandle Certificate, int8_t IncludeKey, int8_t IncludeKeyValue, TElXMLKeyInfoX509DataParamsRaw IncludeDataParams, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_17(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElCustomCertStorageHandle CertStorage, int8_t IncludeKey, int8_t IncludeKeyValue, TElXMLKeyInfoX509DataParamsRaw IncludeDataParams, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_18(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElXMLKeyInfoDataHandle KeyData, TElXMLSignatureMethodRaw SignatureMethod, int8_t IncludeKey, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_19(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElDCParametersHandle Pars, TElXMLDOMElementHandle ParentElement, TElX509CertificateHandle Certificate, int8_t IncludeKey, int8_t IncludeKeyValue, TElXMLKeyInfoX509DataParamsRaw IncludeDataParams, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_20(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElDCParametersHandle Pars, TElXMLDOMElementHandle ParentElement, TElCustomCertStorageHandle CertStorage, int8_t IncludeKey, int8_t IncludeKeyValue, TElXMLKeyInfoX509DataParamsRaw IncludeDataParams, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_InitiateAsyncSign_21(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElDCParametersHandle Pars, TElXMLDOMElementHandle ParentElement, TElXMLKeyInfoDataHandle KeyData, TElXMLSignatureMethodRaw SignatureMethod, int8_t IncludeKey, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_CompleteAsyncSign(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElDCAsyncStateHandle State);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_Sign(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElX509CertificateHandle Certificate);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_Sign_1(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElX509CertificateHandle Certificate, int8_t IncludeKey);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_Sign_2(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElX509CertificateHandle Certificate, int8_t IncludeKey, int8_t IncludeKeyValue, TElXMLKeyInfoX509DataParamsRaw IncludeDataParams);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_Sign_3(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElCustomCertStorageHandle CertStorage);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_Sign_4(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElCustomCertStorageHandle CertStorage, int8_t IncludeKey);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_Sign_5(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElCustomCertStorageHandle CertStorage, int8_t IncludeKey, int8_t IncludeKeyValue, TElXMLKeyInfoX509DataParamsRaw IncludeDataParams);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_Sign_6(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElXMLKeyInfoDataHandle KeyData, TElXMLSignatureMethodRaw SignatureMethod, int8_t IncludeKey);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_Validate(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TSBXMLSOAPSignatureValidationStatusRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_Validate_1(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElX509CertificateHandle Certificate, TSBXMLSOAPSignatureValidationStatusRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_Validate_2(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLKeyInfoDataHandle KeyData, TSBXMLSOAPSignatureValidationStatusRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_AddReference(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle Element, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_AddReference_1(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle Element, int8_t AutoGenerateId, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_AddReference_2(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDOMElementHandle Element, const char * pcCustomId, int32_t szCustomId, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_AddReference_3(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLCustomElementHandle Element, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_AddReference_4(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLCustomElementHandle Element, int8_t AutoGenerateId, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_AddReference_5(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLCustomElementHandle Element, const char * pcCustomId, int32_t szCustomId, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_AddReference_6(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TStreamHandle Stream, const char * pcFileNameURI, int32_t szFileNameURI, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_get_Verifier(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLVerifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_get_References(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLReferenceListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_get_Certificates(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_get_KeyName(TElXMLSOAPBaseSignatureHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_set_KeyName(TElXMLSOAPBaseSignatureHandlerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_get_SignerCertificate(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_get_SignerKeyData(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLKeyInfoDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_get_ReferencesDigestMethod(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDigestMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_set_ReferencesDigestMethod(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXMLDigestMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_get_XAdESProcessor(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXAdESProcessorHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_set_XAdESProcessor(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TElXAdESProcessorHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_get_OwnXAdESProcessor(TElXMLSOAPBaseSignatureHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_set_OwnXAdESProcessor(TElXMLSOAPBaseSignatureHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_get_OnPrepareSignature(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TSBXMLSOAPSignEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_set_OnPrepareSignature(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TSBXMLSOAPSignEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_get_OnBeforeSign(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TSBXMLSOAPSignEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_set_OnBeforeSign(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TSBXMLSOAPSignEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_get_OnAfterSign(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TSBXMLSOAPSignEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_set_OnAfterSign(TElXMLSOAPBaseSignatureHandlerHandle _Handle, TSBXMLSOAPSignEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseSignatureHandler_Create(TComponentHandle Owner, TElXMLSOAPBaseSignatureHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPBASESIGNATUREHANDLER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElXMLSOAPSignatureHandlerClass_ce_ptr;
extern zend_class_entry *TElXMLSOAPMessage_ce_ptr;
extern zend_class_entry *TElXMLSOAPCustomSignatureHandler_ce_ptr;
extern zend_class_entry *TElXMLSOAPBaseSignatureHandler_ce_ptr;

void SB_CALLBACK TSBXMLSOAPSignEventRaw(void * _ObjectData, TObjectHandle Sender, TElXMLSignerHandle Signer);
void Register_TElXMLSOAPMessage(TSRMLS_D);
void Register_TElXMLSOAPCustomSignatureHandler(TSRMLS_D);
void Register_TElXMLSOAPBaseSignatureHandler(TSRMLS_D);
SB_PHP_FUNCTION(SBXMLSOAP, RegisterSecurityHandler);
SB_PHP_FUNCTION(SBXMLSOAP, UnregisterSecurityHandler);
SB_PHP_FUNCTION(SBXMLSOAP, Initialize);
void Register_SBXMLSOAP_Constants(int module_number TSRMLS_DC);
void Register_SBXMLSOAP_Enum_Flags(TSRMLS_D);
void Register_SBXMLSOAP_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_XMLSOAP
SB_IMPORT uint32_t SB_APIENTRY SBXMLSOAP_RegisterSecurityHandler(TElXMLSOAPSignatureHandlerClassHandle HandlerClass);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSOAP_UnregisterSecurityHandler(TElXMLSOAPSignatureHandlerClassHandle HandlerClass);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSOAP_Initialize(void);
#endif /* SB_USE_GLOBAL_PROCS_XMLSOAP */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLSOAP */

