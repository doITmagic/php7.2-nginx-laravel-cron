#ifndef __INC_SBXMLSOAPCLIENT
#define __INC_SBXMLSOAPCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbconstants.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbstringlist.h"
#include "sbhttpscommon.h"
#include "sbhttpsclient.h"
#include "sbxmldefs.h"
#include "sbxmlcore.h"
#include "sbxmlsec.h"
#include "sbxmlutils.h"
#include "sbxmlsoapcore.h"
#include "sbxmlsoap.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElXMLSOAPClientHandle;

typedef TElXMLSOAPClientHandle ElXMLSOAPClientHandle;

typedef TElClassHandle TElXMLSOAPParameterAttributeHandle;

typedef TElClassHandle TElXMLSOAPCustomParameterHandle;

typedef TElClassHandle TElXMLSOAPBaseParameterHandle;

typedef TElClassHandle TElXMLSOAPStringParameterHandle;

typedef TElClassHandle TElXMLSOAPBooleanParameterHandle;

typedef TElClassHandle TElXMLSOAPIntegerParameterHandle;

typedef TElClassHandle TElXMLSOAPInt64ParameterHandle;

typedef TElClassHandle TElXMLSOAPDoubleParameterHandle;

typedef TElClassHandle TElXMLSOAPDateTimeParameterHandle;

typedef TElClassHandle TElXMLSOAPBase64BinaryParameterHandle;

typedef TElClassHandle TElXMLSOAPCompoundParameterHandle;

typedef TElClassHandle TElXMLSOAPParametersManagerHandle;

typedef TElClassHandle TElXMLSOAPFaultHandle;

typedef TElClassHandle TElXMLSOAPParameterClassHandle;

typedef uint8_t TSBXMLSOAPResponseTypeRaw;

typedef enum
{
	srtNone = 0,
	srtStream = 1,
	srtXMLDocument = 2,
	srtSOAPMessage = 3
} TSBXMLSOAPResponseType;

#ifdef SB_USE_CLASS_TELXMLSOAPCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_ProcessReply(TElXMLSOAPClientHandle _Handle, int32_t AHTTPStatusCode, TStreamHandle AResponseStream);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_Clear(TElXMLSOAPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_ClearResponse(TElXMLSOAPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_GenerateMessage(TElXMLSOAPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_LoadMessage(TElXMLSOAPClientHandle _Handle, TElXMLDOMDocumentHandle ADocument);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_LoadMessage_1(TElXMLSOAPClientHandle _Handle, TStreamHandle AStream);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_LoadMessage_2(TElXMLSOAPClientHandle _Handle, const char * pcAFileName, int32_t szAFileName);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_SendMessage(TElXMLSOAPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_SendSOAPMessage(TElXMLSOAPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_SendMessageWithAttachment(TElXMLSOAPClientHandle _Handle, const char * pcPrimaryMessageID, int32_t szPrimaryMessageID, const char * pcContentID, int32_t szContentID, const char * pcContentType, int32_t szContentType, TStreamHandle ContentStream, int8_t CloseStream);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_SendMessageWithAttachments(TElXMLSOAPClientHandle _Handle, const char * pcPrimaryMessageID, int32_t szPrimaryMessageID, TElHTTPMultipartListHandle PartsList);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_SendMessageWithAttachments_1(TElXMLSOAPClientHandle _Handle, const char * pcPrimaryMessageID, int32_t szPrimaryMessageID, const char * pcRelatedStartInfo, int32_t szRelatedStartInfo, const char * pcRelatedType, int32_t szRelatedType, TElHTTPMultipartListHandle PartsList);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddParameter(TElXMLSOAPClientHandle _Handle, TElXMLSOAPCustomParameterHandle Param, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddStringParameter(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcValue, int32_t szValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddStringParameter_1(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcValue, int32_t szValue, int8_t NormalizeNEL, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddStringParameter_2(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, const char * pcValue, int32_t szValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddStringParameter_3(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, const char * pcValue, int32_t szValue, int8_t NormalizeNEL, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddBooleanParameter(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, int8_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddBooleanParameter_1(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, int8_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddIntegerParameter(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, int32_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddIntegerParameter_1(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, int32_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddInt64Parameter(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, int64_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddInt64Parameter_1(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, int64_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddDoubleParameter(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, double Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddDoubleParameter_1(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, double Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddDateTimeParameter(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, int64_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddDateTimeParameter_1(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, int64_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddBase64BinaryParameter(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, const uint8_t pValue[], int32_t szValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddBase64BinaryParameter_1(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, const uint8_t pValue[], int32_t szValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddCompoundParameter(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_AddCompoundParameter_1(TElXMLSOAPClientHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_DeleteParameter(TElXMLSOAPClientHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_XMLDocument(TElXMLSOAPClientHandle _Handle, TElXMLDOMDocumentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_SOAPMessage(TElXMLSOAPClientHandle _Handle, TElXMLSOAPMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_SOAPVersion(TElXMLSOAPClientHandle _Handle, TSBXMLSOAPVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_set_SOAPVersion(TElXMLSOAPClientHandle _Handle, TSBXMLSOAPVersionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_SOAPPrefix(TElXMLSOAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_set_SOAPPrefix(TElXMLSOAPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_MessageNamespaces(TElXMLSOAPClientHandle _Handle, TElXMLNamespaceMapHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_OperationName(TElXMLSOAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_set_OperationName(TElXMLSOAPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_OperationNamespaceURI(TElXMLSOAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_set_OperationNamespaceURI(TElXMLSOAPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_OperationResponseName(TElXMLSOAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_set_OperationResponseName(TElXMLSOAPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_OperationResponseNamespaceURI(TElXMLSOAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_set_OperationResponseNamespaceURI(TElXMLSOAPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_Encoding(TElXMLSOAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_set_Encoding(TElXMLSOAPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_SOAPAction(TElXMLSOAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_set_SOAPAction(TElXMLSOAPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_RootParameter(TElXMLSOAPClientHandle _Handle, TElXMLSOAPCompoundParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_ParameterCount(TElXMLSOAPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_Parameters(TElXMLSOAPClientHandle _Handle, int32_t Index, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_ParameterNames(TElXMLSOAPClientHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_ParameterValues(TElXMLSOAPClientHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_HTTPStatusCode(TElXMLSOAPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_ExpectedResponseType(TElXMLSOAPClientHandle _Handle, TSBXMLSOAPResponseTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_set_ExpectedResponseType(TElXMLSOAPClientHandle _Handle, TSBXMLSOAPResponseTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_ResponseType(TElXMLSOAPClientHandle _Handle, TSBXMLSOAPResponseTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_ResponseStream(TElXMLSOAPClientHandle _Handle, TMemoryStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_ResponseXMLDocument(TElXMLSOAPClientHandle _Handle, TElXMLDOMDocumentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_ResponseSOAPMessage(TElXMLSOAPClientHandle _Handle, TElXMLSOAPMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_OperationResponseXMLElement(TElXMLSOAPClientHandle _Handle, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_ResponseRootParameter(TElXMLSOAPClientHandle _Handle, TElXMLSOAPCompoundParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_ResponseParameterCount(TElXMLSOAPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_ResponseParameters(TElXMLSOAPClientHandle _Handle, int32_t Index, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_ResponseParameterNames(TElXMLSOAPClientHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_ResponseParameterValues(TElXMLSOAPClientHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_FaultCount(TElXMLSOAPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_Faults(TElXMLSOAPClientHandle _Handle, int32_t Index, TElXMLSOAPFaultHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_FaultActor(TElXMLSOAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_FaultCode(TElXMLSOAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_FaultString(TElXMLSOAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_HTTPClient(TElXMLSOAPClientHandle _Handle, TElHTTPSClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_set_HTTPClient(TElXMLSOAPClientHandle _Handle, TElHTTPSClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_URL(TElXMLSOAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_set_URL(TElXMLSOAPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_OnFormatElement(TElXMLSOAPClientHandle _Handle, TSBXMLFormatElementEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_set_OnFormatElement(TElXMLSOAPClientHandle _Handle, TSBXMLFormatElementEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_get_OnFormatText(TElXMLSOAPClientHandle _Handle, TSBXMLFormatTextEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_set_OnFormatText(TElXMLSOAPClientHandle _Handle, TSBXMLFormatTextEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPClient_Create(TComponentHandle AOwner, TElXMLSOAPClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPCLIENT */

#ifdef SB_USE_CLASS_TELXMLSOAPPARAMETERATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParameterAttribute_Clone(TElXMLSOAPParameterAttributeHandle _Handle, TElXMLSOAPParameterAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParameterAttribute_get_Name(TElXMLSOAPParameterAttributeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParameterAttribute_set_Name(TElXMLSOAPParameterAttributeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParameterAttribute_get_Value(TElXMLSOAPParameterAttributeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParameterAttribute_set_Value(TElXMLSOAPParameterAttributeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParameterAttribute_get_NamespaceURI(TElXMLSOAPParameterAttributeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParameterAttribute_set_NamespaceURI(TElXMLSOAPParameterAttributeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParameterAttribute_get_Prefix(TElXMLSOAPParameterAttributeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParameterAttribute_set_Prefix(TElXMLSOAPParameterAttributeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParameterAttribute_Create(TElXMLSOAPParameterAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParameterAttribute_Create_1(TElXMLDOMAttrHandle Attr, TElXMLSOAPParameterAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParameterAttribute_Create_2(const char * pcAName, int32_t szAName, const char * pcAValue, int32_t szAValue, TElXMLSOAPParameterAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParameterAttribute_Create_3(const char * pcANSURI, int32_t szANSURI, const char * pcAName, int32_t szAName, const char * pcAValue, int32_t szAValue, TElXMLSOAPParameterAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPPARAMETERATTRIBUTE */

#ifdef SB_USE_CLASS_TELXMLSOAPCUSTOMPARAMETER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_CreateFromXML(TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_CreateFromXML_1(TElXMLSOAPCustomParameterHandle _Handle, TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_Clone(TElXMLSOAPCustomParameterHandle _Handle, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_Clear(TElXMLSOAPCustomParameterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_LoadFromXML(TElXMLSOAPCustomParameterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_SaveToXML(TElXMLSOAPCustomParameterHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_GetAttribute(TElXMLSOAPCustomParameterHandle _Handle, const char * pcAName, int32_t szAName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_SetAttribute(TElXMLSOAPCustomParameterHandle _Handle, const char * pcAName, int32_t szAName, const char * pcaValue, int32_t szaValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_GetAttributeNS(TElXMLSOAPCustomParameterHandle _Handle, const char * pcANSURI, int32_t szANSURI, const char * pcAName, int32_t szAName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_SetAttributeNS(TElXMLSOAPCustomParameterHandle _Handle, const char * pcANSURI, int32_t szANSURI, const char * pcAName, int32_t szAName, const char * pcaValue, int32_t szaValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_RemoveAttribute(TElXMLSOAPCustomParameterHandle _Handle, const char * pcAName, int32_t szAName);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_RemoveAttributeNS(TElXMLSOAPCustomParameterHandle _Handle, const char * pcANSURI, int32_t szANSURI, const char * pcAName, int32_t szAName);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_get_ParameterName(TElXMLSOAPCustomParameterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_set_ParameterName(TElXMLSOAPCustomParameterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_get_ParameterNamespaceURI(TElXMLSOAPCustomParameterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_set_ParameterNamespaceURI(TElXMLSOAPCustomParameterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_get_AttributeCount(TElXMLSOAPCustomParameterHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_get_Attributes(TElXMLSOAPCustomParameterHandle _Handle, int32_t Index, TElXMLSOAPParameterAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_get_AttribStrings(TElXMLSOAPCustomParameterHandle _Handle, const char * pcAName, int32_t szAName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_set_AttribStrings(TElXMLSOAPCustomParameterHandle _Handle, const char * pcAName, int32_t szAName, const char * pcaValue, int32_t szaValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCustomParameter_Create(TElXMLSOAPCustomParameterHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPCUSTOMPARAMETER */

#ifdef SB_USE_CLASS_TELXMLSOAPBASEPARAMETER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseParameter_CreateFromXML(TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseParameter_CreateFromXML_1(TElXMLSOAPBaseParameterHandle _Handle, TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseParameter_Clone(TElXMLSOAPBaseParameterHandle _Handle, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseParameter_Clear(TElXMLSOAPBaseParameterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseParameter_LoadFromXML(TElXMLSOAPBaseParameterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseParameter_SaveToXML(TElXMLSOAPBaseParameterHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseParameter_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseParameter_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseParameter_get_StringValue(TElXMLSOAPBaseParameterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseParameter_set_StringValue(TElXMLSOAPBaseParameterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBaseParameter_Create(TElXMLSOAPBaseParameterHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPBASEPARAMETER */

#ifdef SB_USE_CLASS_TELXMLSOAPSTRINGPARAMETER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPStringParameter_CreateFromXML(TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPStringParameter_CreateFromXML_1(TElXMLSOAPStringParameterHandle _Handle, TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPStringParameter_Clone(TElXMLSOAPStringParameterHandle _Handle, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPStringParameter_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPStringParameter_get_Value(TElXMLSOAPStringParameterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPStringParameter_set_Value(TElXMLSOAPStringParameterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPStringParameter_Create(TElXMLSOAPBaseParameterHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPSTRINGPARAMETER */

#ifdef SB_USE_CLASS_TELXMLSOAPBOOLEANPARAMETER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBooleanParameter_CreateFromXML(TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBooleanParameter_CreateFromXML_1(TElXMLSOAPBooleanParameterHandle _Handle, TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBooleanParameter_Clone(TElXMLSOAPBooleanParameterHandle _Handle, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBooleanParameter_LoadFromXML(TElXMLSOAPBooleanParameterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBooleanParameter_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBooleanParameter_get_Value(TElXMLSOAPBooleanParameterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBooleanParameter_set_Value(TElXMLSOAPBooleanParameterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBooleanParameter_Create(TElXMLSOAPBaseParameterHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPBOOLEANPARAMETER */

#ifdef SB_USE_CLASS_TELXMLSOAPINTEGERPARAMETER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPIntegerParameter_CreateFromXML(TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPIntegerParameter_CreateFromXML_1(TElXMLSOAPIntegerParameterHandle _Handle, TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPIntegerParameter_Clone(TElXMLSOAPIntegerParameterHandle _Handle, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPIntegerParameter_LoadFromXML(TElXMLSOAPIntegerParameterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPIntegerParameter_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPIntegerParameter_get_Value(TElXMLSOAPIntegerParameterHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPIntegerParameter_set_Value(TElXMLSOAPIntegerParameterHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPIntegerParameter_Create(TElXMLSOAPBaseParameterHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPINTEGERPARAMETER */

#ifdef SB_USE_CLASS_TELXMLSOAPINT64PARAMETER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPInt64Parameter_CreateFromXML(TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPInt64Parameter_CreateFromXML_1(TElXMLSOAPInt64ParameterHandle _Handle, TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPInt64Parameter_Clone(TElXMLSOAPInt64ParameterHandle _Handle, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPInt64Parameter_LoadFromXML(TElXMLSOAPInt64ParameterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPInt64Parameter_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPInt64Parameter_get_Value(TElXMLSOAPInt64ParameterHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPInt64Parameter_set_Value(TElXMLSOAPInt64ParameterHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPInt64Parameter_Create(TElXMLSOAPBaseParameterHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPINT64PARAMETER */

#ifdef SB_USE_CLASS_TELXMLSOAPDOUBLEPARAMETER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDoubleParameter_CreateFromXML(TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDoubleParameter_CreateFromXML_1(TElXMLSOAPDoubleParameterHandle _Handle, TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDoubleParameter_Clone(TElXMLSOAPDoubleParameterHandle _Handle, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDoubleParameter_LoadFromXML(TElXMLSOAPDoubleParameterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDoubleParameter_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDoubleParameter_get_Value(TElXMLSOAPDoubleParameterHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDoubleParameter_set_Value(TElXMLSOAPDoubleParameterHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDoubleParameter_Create(TElXMLSOAPBaseParameterHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPDOUBLEPARAMETER */

#ifdef SB_USE_CLASS_TELXMLSOAPDATETIMEPARAMETER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDateTimeParameter_CreateFromXML(TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDateTimeParameter_CreateFromXML_1(TElXMLSOAPDateTimeParameterHandle _Handle, TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDateTimeParameter_Clone(TElXMLSOAPDateTimeParameterHandle _Handle, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDateTimeParameter_LoadFromXML(TElXMLSOAPDateTimeParameterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDateTimeParameter_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDateTimeParameter_get_Value(TElXMLSOAPDateTimeParameterHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDateTimeParameter_set_Value(TElXMLSOAPDateTimeParameterHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDateTimeParameter_get_DateTimeFormat(TElXMLSOAPDateTimeParameterHandle _Handle, TSBXMLDateTimeFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDateTimeParameter_set_DateTimeFormat(TElXMLSOAPDateTimeParameterHandle _Handle, TSBXMLDateTimeFormatRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDateTimeParameter_get_IncludeTimeZone(TElXMLSOAPDateTimeParameterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDateTimeParameter_set_IncludeTimeZone(TElXMLSOAPDateTimeParameterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPDateTimeParameter_Create(TElXMLSOAPDateTimeParameterHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPDATETIMEPARAMETER */

#ifdef SB_USE_CLASS_TELXMLSOAPBASE64BINARYPARAMETER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBase64BinaryParameter_CreateFromXML(TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBase64BinaryParameter_CreateFromXML_1(TElXMLSOAPBase64BinaryParameterHandle _Handle, TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBase64BinaryParameter_Clone(TElXMLSOAPBase64BinaryParameterHandle _Handle, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBase64BinaryParameter_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBase64BinaryParameter_get_Value(TElXMLSOAPBase64BinaryParameterHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBase64BinaryParameter_set_Value(TElXMLSOAPBase64BinaryParameterHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBase64BinaryParameter_Create(TElXMLSOAPBaseParameterHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPBASE64BINARYPARAMETER */

#ifdef SB_USE_CLASS_TELXMLSOAPCOMPOUNDPARAMETER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_CreateFromXML(TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_CreateFromXML_1(TElXMLSOAPCompoundParameterHandle _Handle, TElXMLDOMElementHandle Element, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_Clone(TElXMLSOAPCompoundParameterHandle _Handle, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_Add(TElXMLSOAPCompoundParameterHandle _Handle, TElXMLSOAPCustomParameterHandle Param, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddString(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcValue, int32_t szValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddString_1(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcValue, int32_t szValue, int8_t NormalizeNEL, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddString_2(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, const char * pcValue, int32_t szValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddString_3(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, const char * pcValue, int32_t szValue, int8_t NormalizeNEL, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddBoolean(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, int8_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddBoolean_1(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, int8_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddInteger(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, int32_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddInteger_1(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, int32_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddInt64(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, int64_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddInt64_1(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, int64_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddDouble(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, double Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddDouble_1(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, double Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddDateTime(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, int64_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddDateTime_1(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, int64_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddBase64Binary(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, const uint8_t pValue[], int32_t szValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddBase64Binary_1(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, const uint8_t pValue[], int32_t szValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddCompound(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_AddCompound_1(TElXMLSOAPCompoundParameterHandle _Handle, const char * pcParamName, int32_t szParamName, const char * pcParamNamespaceURI, int32_t szParamNamespaceURI, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_Delete(TElXMLSOAPCompoundParameterHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_Clear(TElXMLSOAPCompoundParameterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_LoadFromXML(TElXMLSOAPCompoundParameterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_SaveToXML(TElXMLSOAPCompoundParameterHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_get_Count(TElXMLSOAPCompoundParameterHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_get_Items(TElXMLSOAPCompoundParameterHandle _Handle, int32_t Index, TElXMLSOAPCustomParameterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPCompoundParameter_Create(TElXMLSOAPCompoundParameterHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPCOMPOUNDPARAMETER */

#ifdef SB_USE_CLASS_TELXMLSOAPPARAMETERSMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParametersManager_Add(TElXMLSOAPParametersManagerHandle _Handle, TElXMLSOAPParameterClassHandle AParamClass);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParametersManager_Add_1(TElXMLSOAPParametersManagerHandle _Handle, const char * pcAParamName, int32_t szAParamName, const char * pcAParamNamespaceURI, int32_t szAParamNamespaceURI, TElXMLSOAPParameterClassHandle AParamClass);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParametersManager_RemoveAt(TElXMLSOAPParametersManagerHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParametersManager_get_Count(TElXMLSOAPParametersManagerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParametersManager_get_ParamNames(TElXMLSOAPParametersManagerHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParametersManager_get_ParamNamespaceURIs(TElXMLSOAPParametersManagerHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParametersManager_get_ParamClasses(TElXMLSOAPParametersManagerHandle _Handle, int32_t Index, TElXMLSOAPParameterClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPParametersManager_Create(TElXMLSOAPParametersManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPPARAMETERSMANAGER */

#ifdef SB_USE_CLASS_TELXMLSOAPFAULT
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_Clear(TElXMLSOAPFaultHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_LoadFromXML(TElXMLSOAPFaultHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_SaveToXML(TElXMLSOAPFaultHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_get_FaultActor(TElXMLSOAPFaultHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_set_FaultActor(TElXMLSOAPFaultHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_get_FaultCode(TElXMLSOAPFaultHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_set_FaultCode(TElXMLSOAPFaultHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_get_FaultString(TElXMLSOAPFaultHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_set_FaultString(TElXMLSOAPFaultHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_get_Detail(TElXMLSOAPFaultHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_set_Detail(TElXMLSOAPFaultHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_Create(TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, TElXMLSOAPFaultHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_Create_1(TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, const char * pcAName, int32_t szAName, TElXMLSOAPFaultHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_Create_2(TElXMLDOMElementHandle ParentElement, TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, TElXMLSOAPFaultHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPFault_Create_3(TElXMLDOMElementHandle ParentElement, TElXMLDOMElementHandle BeforeChild, TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, const char * pcAName, int32_t szAName, TElXMLSOAPFaultHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPFAULT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElXMLSOAPParameterClass_ce_ptr;
extern zend_class_entry *TElXMLSOAPClient_ce_ptr;
extern zend_class_entry *TElXMLSOAPParameterAttribute_ce_ptr;
extern zend_class_entry *TElXMLSOAPCustomParameter_ce_ptr;
extern zend_class_entry *TElXMLSOAPBaseParameter_ce_ptr;
extern zend_class_entry *TElXMLSOAPStringParameter_ce_ptr;
extern zend_class_entry *TElXMLSOAPBooleanParameter_ce_ptr;
extern zend_class_entry *TElXMLSOAPIntegerParameter_ce_ptr;
extern zend_class_entry *TElXMLSOAPInt64Parameter_ce_ptr;
extern zend_class_entry *TElXMLSOAPDoubleParameter_ce_ptr;
extern zend_class_entry *TElXMLSOAPDateTimeParameter_ce_ptr;
extern zend_class_entry *TElXMLSOAPBase64BinaryParameter_ce_ptr;
extern zend_class_entry *TElXMLSOAPCompoundParameter_ce_ptr;
extern zend_class_entry *TElXMLSOAPParametersManager_ce_ptr;
extern zend_class_entry *TElXMLSOAPFault_ce_ptr;

void Register_TElXMLSOAPClient(TSRMLS_D);
void Register_TElXMLSOAPParameterAttribute(TSRMLS_D);
void Register_TElXMLSOAPCustomParameter(TSRMLS_D);
void Register_TElXMLSOAPBaseParameter(TSRMLS_D);
void Register_TElXMLSOAPStringParameter(TSRMLS_D);
void Register_TElXMLSOAPBooleanParameter(TSRMLS_D);
void Register_TElXMLSOAPIntegerParameter(TSRMLS_D);
void Register_TElXMLSOAPInt64Parameter(TSRMLS_D);
void Register_TElXMLSOAPDoubleParameter(TSRMLS_D);
void Register_TElXMLSOAPDateTimeParameter(TSRMLS_D);
void Register_TElXMLSOAPBase64BinaryParameter(TSRMLS_D);
void Register_TElXMLSOAPCompoundParameter(TSRMLS_D);
void Register_TElXMLSOAPParametersManager(TSRMLS_D);
void Register_TElXMLSOAPFault(TSRMLS_D);
SB_PHP_FUNCTION(SBXMLSOAPClient, SOAPParametersManager);
void Register_SBXMLSOAPClient_Enum_Flags(TSRMLS_D);
void Register_SBXMLSOAPClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_XMLSOAPCLIENT
SB_IMPORT uint32_t SB_APIENTRY SBXMLSOAPClient_SOAPParametersManager(TElXMLSOAPParametersManagerHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_XMLSOAPCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLSOAPCLIENT */

