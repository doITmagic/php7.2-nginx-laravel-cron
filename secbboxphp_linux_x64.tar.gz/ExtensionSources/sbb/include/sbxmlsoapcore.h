#ifndef __INC_SBXMLSOAPCORE
#define __INC_SBXMLSOAPCORE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstrutils.h"
#include "sbutils.h"
#include "sbxmldefs.h"
#include "sbxmlcore.h"
#include "sbxmlsec.h"
#include "sbxmlutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SSOAPUnsupportedOperation 	"This operation is not supported"
#define SB_SSOAPDocumentElementExists 	"The XML document already contains a DocumentElement"
#define SB_SSOAPEnvelopeBodyElementExists 	"SOAP envelope already contain a Body element"
#define SB_SSOAPEnvelopeHeaderElementExists 	"SOAP envelope already contain a Header element"
#define SB_SSOAPHeaderElementNotLoaded 	"Header element is not loaded"
#define SB_SSOAPHeaderBlockNotLoaded 	"Header block is not loaded"
#define SB_SSOAPBodyElementNotLoaded 	"Body element is not loaded"

typedef TElClassHandle TElXMLSOAPElementHandle;

typedef TElClassHandle TElXMLSOAPHeaderBlockHandle;

typedef TElClassHandle TElXMLSOAPHeaderHandle;

typedef TElClassHandle TElXMLSOAPBodyEntryHandle;

typedef TElClassHandle TElXMLSOAPBodyHandle;

typedef TElClassHandle TElXMLSOAPEnvelopeHandle;

typedef uint8_t TSBXMLSOAPVersionRaw;

typedef enum
{
	SOAP_v1_1 = 0,
	SOAP_v1_2 = 1
} TSBXMLSOAPVersion;

#ifdef SB_USE_CLASS_TELXMLSOAPELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPElement_LoadFromXML(TElXMLSOAPElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPElement_SaveToXML(TElXMLSOAPElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPElement_get_SOAPVersion(TElXMLSOAPElementHandle _Handle, TSBXMLSOAPVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPElement_get_NamespaceURI(TElXMLSOAPElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPElement_Create(TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, TElXMLSOAPElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPElement_Create_1(TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, const char * pcAName, int32_t szAName, TElXMLSOAPElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPElement_Create_2(TElXMLDOMElementHandle ParentElement, TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, TElXMLSOAPElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPElement_Create_3(TElXMLDOMElementHandle ParentElement, TElXMLDOMElementHandle BeforeChild, TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, const char * pcAName, int32_t szAName, TElXMLSOAPElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPELEMENT */

#ifdef SB_USE_CLASS_TELXMLSOAPHEADERBLOCK
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_LoadFromXML(TElXMLSOAPHeaderBlockHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_SaveToXML(TElXMLSOAPHeaderBlockHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_get_Actor(TElXMLSOAPHeaderBlockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_set_Actor(TElXMLSOAPHeaderBlockHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_get_EncodingStyle(TElXMLSOAPHeaderBlockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_set_EncodingStyle(TElXMLSOAPHeaderBlockHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_get_Role(TElXMLSOAPHeaderBlockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_set_Role(TElXMLSOAPHeaderBlockHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_get_MustUnderstand(TElXMLSOAPHeaderBlockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_set_MustUnderstand(TElXMLSOAPHeaderBlockHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_get_Relay(TElXMLSOAPHeaderBlockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_set_Relay(TElXMLSOAPHeaderBlockHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_get_SOAPNamespaceURI(TElXMLSOAPHeaderBlockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeaderBlock_Create(const char * pcASOAPNamespaceURI, int32_t szASOAPNamespaceURI, TElXMLSOAPHeaderBlockHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPHEADERBLOCK */

#ifdef SB_USE_CLASS_TELXMLSOAPHEADER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeader_Clear(TElXMLSOAPHeaderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeader_ReloadBlocks(TElXMLSOAPHeaderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeader_LoadFromXML(TElXMLSOAPHeaderHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeader_LoadBlockFromXML(TElXMLSOAPHeaderHandle _Handle, TElXMLDOMElementHandle Element, TElXMLSOAPHeaderBlockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeader_get_BlockCount(TElXMLSOAPHeaderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeader_get_Blocks(TElXMLSOAPHeaderHandle _Handle, int32_t Index, TElXMLSOAPHeaderBlockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeader_Create(TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, TElXMLSOAPHeaderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeader_Create_1(TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, const char * pcAName, int32_t szAName, TElXMLSOAPHeaderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeader_Create_2(TElXMLDOMElementHandle ParentElement, TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, TElXMLSOAPHeaderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPHeader_Create_3(TElXMLDOMElementHandle ParentElement, TElXMLDOMElementHandle BeforeChild, TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, const char * pcAName, int32_t szAName, TElXMLSOAPHeaderHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPHEADER */

#ifdef SB_USE_CLASS_TELXMLSOAPBODYENTRY
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBodyEntry_LoadFromXML(TElXMLSOAPBodyEntryHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBodyEntry_SaveToXML(TElXMLSOAPBodyEntryHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBodyEntry_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBodyEntry_get_EncodingStyle(TElXMLSOAPBodyEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBodyEntry_set_EncodingStyle(TElXMLSOAPBodyEntryHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBodyEntry_get_NamespaceURI(TElXMLSOAPBodyEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBodyEntry_Create(const char * pcANamespaceURI, int32_t szANamespaceURI, TElXMLSOAPBodyEntryHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPBODYENTRY */

#ifdef SB_USE_CLASS_TELXMLSOAPBODY
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBody_Clear(TElXMLSOAPBodyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBody_ReloadEntries(TElXMLSOAPBodyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBody_LoadFromXML(TElXMLSOAPBodyHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBody_get_EntryCount(TElXMLSOAPBodyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBody_get_Entries(TElXMLSOAPBodyHandle _Handle, int32_t Index, TElXMLSOAPBodyEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBody_Create(TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, TElXMLSOAPBodyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBody_Create_1(TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, const char * pcAName, int32_t szAName, TElXMLSOAPBodyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBody_Create_2(TElXMLDOMElementHandle ParentElement, TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, TElXMLSOAPBodyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPBody_Create_3(TElXMLDOMElementHandle ParentElement, TElXMLDOMElementHandle BeforeChild, TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, const char * pcAName, int32_t szAName, TElXMLSOAPBodyHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPBODY */

#ifdef SB_USE_CLASS_TELXMLSOAPENVELOPE
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPEnvelope_Clear(TElXMLSOAPEnvelopeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPEnvelope_LoadFromXML(TElXMLSOAPEnvelopeHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPEnvelope_CreateHeader(TElXMLSOAPEnvelopeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPEnvelope_CreateBody(TElXMLSOAPEnvelopeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPEnvelope_get_Header(TElXMLSOAPEnvelopeHandle _Handle, TElXMLSOAPHeaderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPEnvelope_get_Body(TElXMLSOAPEnvelopeHandle _Handle, TElXMLSOAPBodyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPEnvelope_Create(TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, TElXMLSOAPEnvelopeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPEnvelope_Create_1(TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, const char * pcAName, int32_t szAName, TElXMLSOAPEnvelopeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPEnvelope_Create_2(TElXMLDOMElementHandle ParentElement, TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, TElXMLSOAPEnvelopeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPEnvelope_Create_3(TElXMLDOMElementHandle ParentElement, TElXMLDOMElementHandle BeforeChild, TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, const char * pcAName, int32_t szAName, TElXMLSOAPEnvelopeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPEnvelope_Create_4(TElXMLDOMDocumentHandle Document, TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, TElXMLSOAPEnvelopeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSOAPEnvelope_Create_5(TElXMLDOMDocumentHandle Document, TSBXMLSOAPVersionRaw AVersion, const char * pcANamespaceURI, int32_t szANamespaceURI, const char * pcAName, int32_t szAName, TElXMLSOAPEnvelopeHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSOAPENVELOPE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElXMLSOAPElement_ce_ptr;
extern zend_class_entry *TElXMLSOAPHeaderBlock_ce_ptr;
extern zend_class_entry *TElXMLSOAPHeader_ce_ptr;
extern zend_class_entry *TElXMLSOAPBodyEntry_ce_ptr;
extern zend_class_entry *TElXMLSOAPBody_ce_ptr;
extern zend_class_entry *TElXMLSOAPEnvelope_ce_ptr;

void Register_TElXMLSOAPElement(TSRMLS_D);
void Register_TElXMLSOAPHeaderBlock(TSRMLS_D);
void Register_TElXMLSOAPHeader(TSRMLS_D);
void Register_TElXMLSOAPBodyEntry(TSRMLS_D);
void Register_TElXMLSOAPBody(TSRMLS_D);
void Register_TElXMLSOAPEnvelope(TSRMLS_D);
SB_PHP_FUNCTION(SBXMLSOAPCore, GetSOAPNamespaceURI);
SB_PHP_FUNCTION(SBXMLSOAPCore, SOAPSecGetElementId);
SB_PHP_FUNCTION(SBXMLSOAPCore, SOAPSecSetElementId);
void Register_SBXMLSOAPCore_Constants(int module_number TSRMLS_DC);
void Register_SBXMLSOAPCore_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_XMLSOAPCORE
SB_IMPORT uint32_t SB_APIENTRY SBXMLSOAPCore_GetSOAPNamespaceURI(TSBXMLSOAPVersionRaw Version, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSOAPCore_SOAPSecGetElementId(TElXMLDOMElementHandle Element, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSOAPCore_SOAPSecSetElementId(TElXMLDOMElementHandle Element, const char * pcValue, int32_t szValue);
#endif /* SB_USE_GLOBAL_PROCS_XMLSOAPCORE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLSOAPCORE */

