#ifndef __INC_SBXMLTRANSFORM
#define __INC_SBXMLTRANSFORM

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbencoding.h"
#include "sbxmldefs.h"
#include "sbxmlcore.h"
#include "sbxmlutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SFXMLCantApplyTransformToBinary 	"Cann\'t apply %s transform to binary data. (%s)"

typedef TElClassHandle TElXMLTransformHandle;

typedef TElXMLTransformHandle ElXMLTransformHandle;

typedef TElClassHandle TElXMLNullTransformHandle;

typedef TElXMLNullTransformHandle ElXMLNullTransformHandle;

typedef TElClassHandle TElXMLBase64TransformHandle;

typedef TElXMLBase64TransformHandle ElXMLBase64TransformHandle;

typedef TElClassHandle TElXMLC14NTransformHandle;

typedef TElXMLC14NTransformHandle ElXMLC14NTransformHandle;

typedef TElClassHandle TElXMLEnvelopedSignatureTransformHandle;

typedef TElXMLEnvelopedSignatureTransformHandle ElXMLEnvelopedSignatureTransformHandle;

typedef TElClassHandle TElXMLXPathTransformHandle;

typedef TElXMLXPathTransformHandle ElXMLXPathTransformHandle;

typedef TElClassHandle TElXMLXPathFilterItemHandle;

typedef TElClassHandle TElXMLXPathFilter2TransformHandle;

typedef TElClassHandle TElXMLTransformChainHandle;

typedef TElXMLTransformChainHandle ElXMLTransformChainHandle;

typedef TElClassHandle TElXMLUnsupportedTransformHandle;

typedef uint32_t TSBTransformPropertiesRaw;

typedef enum 
{
	f_tpConcatenate = 1,
	f_tpC14NCommutative = 2
} TSBTransformProperties;

typedef uint8_t TSBTransformedDataTypeRaw;

typedef enum
{
	tdtBinary = 0,
	tdtNode = 1,
	tdtNodes = 2
} TSBTransformedDataType;

typedef TElClassHandle TElXMLTransformClassHandle;

typedef TElXMLTransformClassHandle ElXMLTransformClassHandle;

typedef uint8_t TSBXPathFilterOperationRaw;

typedef enum
{
	xfIntersect = 0,
	xfSubtract = 1,
	xfUnion = 2
} TSBXPathFilterOperation;

#ifdef SB_USE_CLASS_TELXMLTRANSFORM
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_GetDefaultTransformAlgorithmURI(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_GetDefaultTransformAlgorithmURI_1(TElXMLTransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_IsTransformAlgorithmSupported(const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_IsTransformAlgorithmSupported_1(TElXMLTransformHandle _Handle, const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_Clear(TElXMLTransformHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_LoadFromXML(TElXMLTransformHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_SaveToXML(TElXMLTransformHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_TransformData(TElXMLTransformHandle _Handle, const uint8_t pData[], int32_t szData, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_TransformData_1(TElXMLTransformHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLDOMNodeHandle Reference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_TransformData_2(TElXMLTransformHandle _Handle, TElXMLDOMNodeListHandle Nodes, const TElXMLDOMNodeHandle pReference[], int32_t szReference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_get_TransformAlgorithmURI(TElXMLTransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_set_TransformAlgorithmURI(TElXMLTransformHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_get_TransformedData(TElXMLTransformHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_set_TransformedData(TElXMLTransformHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_get_TransformedNode(TElXMLTransformHandle _Handle, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_set_TransformedNode(TElXMLTransformHandle _Handle, TElXMLDOMNodeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_get_TransformedNodes(TElXMLTransformHandle _Handle, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_set_TransformedNodes(TElXMLTransformHandle _Handle, TElXMLDOMNodeListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_get_ReferenceNode(TElXMLTransformHandle _Handle, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_set_ReferenceNode(TElXMLTransformHandle _Handle, TElXMLDOMNodeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_get_ReferenceNodes(TElXMLTransformHandle _Handle, TElXMLDOMNodeHandle pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_set_ReferenceNodes(TElXMLTransformHandle _Handle, const TElXMLDOMNodeHandle pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransform_Create(TElXMLTransformHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLTRANSFORM */

#ifdef SB_USE_CLASS_TELXMLNULLTRANSFORM
SB_IMPORT uint32_t SB_APIENTRY TElXMLNullTransform_GetDefaultTransformAlgorithmURI(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNullTransform_GetDefaultTransformAlgorithmURI_1(TElXMLNullTransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNullTransform_IsTransformAlgorithmSupported(const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNullTransform_IsTransformAlgorithmSupported_1(TElXMLNullTransformHandle _Handle, const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNullTransform_TransformData(TElXMLNullTransformHandle _Handle, const uint8_t pData[], int32_t szData, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNullTransform_TransformData_1(TElXMLNullTransformHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLDOMNodeHandle Reference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNullTransform_TransformData_2(TElXMLNullTransformHandle _Handle, TElXMLDOMNodeListHandle Nodes, const TElXMLDOMNodeHandle pReference[], int32_t szReference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNullTransform_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNullTransform_Create(TElXMLNullTransformHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLNULLTRANSFORM */

#ifdef SB_USE_CLASS_TELXMLBASE64TRANSFORM
SB_IMPORT uint32_t SB_APIENTRY TElXMLBase64Transform_GetDefaultTransformAlgorithmURI(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBase64Transform_GetDefaultTransformAlgorithmURI_1(TElXMLBase64TransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBase64Transform_IsTransformAlgorithmSupported(const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBase64Transform_IsTransformAlgorithmSupported_1(TElXMLBase64TransformHandle _Handle, const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBase64Transform_TransformData(TElXMLBase64TransformHandle _Handle, const uint8_t pData[], int32_t szData, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBase64Transform_TransformData_1(TElXMLBase64TransformHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLDOMNodeHandle Reference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBase64Transform_TransformData_2(TElXMLBase64TransformHandle _Handle, TElXMLDOMNodeListHandle Nodes, const TElXMLDOMNodeHandle pReference[], int32_t szReference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBase64Transform_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBase64Transform_get_OldMode(TElXMLBase64TransformHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBase64Transform_set_OldMode(TElXMLBase64TransformHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBase64Transform_Create(TElXMLBase64TransformHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLBASE64TRANSFORM */

#ifdef SB_USE_CLASS_TELXMLC14NTRANSFORM
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_GetDefaultTransformAlgorithmURI(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_GetDefaultTransformAlgorithmURI_1(TElXMLC14NTransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_IsTransformAlgorithmSupported(const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_IsTransformAlgorithmSupported_1(TElXMLC14NTransformHandle _Handle, const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_Clear(TElXMLC14NTransformHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_LoadFromXML(TElXMLC14NTransformHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_SaveToXML(TElXMLC14NTransformHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_TransformData(TElXMLC14NTransformHandle _Handle, const uint8_t pData[], int32_t szData, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_TransformData_1(TElXMLC14NTransformHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLDOMNodeHandle Reference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_TransformData_2(TElXMLC14NTransformHandle _Handle, TElXMLDOMNodeListHandle Nodes, const TElXMLDOMNodeHandle pReference[], int32_t szReference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_get_CanonicalizationMethod(TElXMLC14NTransformHandle _Handle, TElXMLCanonicalizationMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_set_CanonicalizationMethod(TElXMLC14NTransformHandle _Handle, TElXMLCanonicalizationMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_get_ExclusiveCanonicalizationPrefix(TElXMLC14NTransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_set_ExclusiveCanonicalizationPrefix(TElXMLC14NTransformHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_get_InclusiveNamespacesPrefixList(TElXMLC14NTransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_set_InclusiveNamespacesPrefixList(TElXMLC14NTransformHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_Create(TElXMLC14NTransformHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLC14NTransform_Create_1(TElXMLCanonicalizationMethodRaw AMethod, TElXMLC14NTransformHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLC14NTRANSFORM */

#ifdef SB_USE_CLASS_TELXMLENVELOPEDSIGNATURETRANSFORM
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_GetDefaultTransformAlgorithmURI(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_GetDefaultTransformAlgorithmURI_1(TElXMLEnvelopedSignatureTransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_IsTransformAlgorithmSupported(const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_IsTransformAlgorithmSupported_1(TElXMLEnvelopedSignatureTransformHandle _Handle, const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_GetDefaultStrictMode(int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_GetDefaultStrictMode_1(TElXMLEnvelopedSignatureTransformHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_SetDefaultStrictMode(int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_SetDefaultStrictMode_1(TElXMLEnvelopedSignatureTransformHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_TransformData(TElXMLEnvelopedSignatureTransformHandle _Handle, const uint8_t pData[], int32_t szData, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_TransformData_1(TElXMLEnvelopedSignatureTransformHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLDOMNodeHandle Reference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_TransformData_2(TElXMLEnvelopedSignatureTransformHandle _Handle, TElXMLDOMNodeListHandle Nodes, const TElXMLDOMNodeHandle pReference[], int32_t szReference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_TransformNode(TElXMLEnvelopedSignatureTransformHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_get_StrictMode(TElXMLEnvelopedSignatureTransformHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_set_StrictMode(TElXMLEnvelopedSignatureTransformHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEnvelopedSignatureTransform_Create(TElXMLEnvelopedSignatureTransformHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLENVELOPEDSIGNATURETRANSFORM */

#ifdef SB_USE_CLASS_TELXMLXPATHTRANSFORM
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_GetDefaultTransformAlgorithmURI(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_GetDefaultTransformAlgorithmURI_1(TElXMLXPathTransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_IsTransformAlgorithmSupported(const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_IsTransformAlgorithmSupported_1(TElXMLXPathTransformHandle _Handle, const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_Clear(TElXMLXPathTransformHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_LoadFromXML(TElXMLXPathTransformHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_SaveToXML(TElXMLXPathTransformHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_TransformData(TElXMLXPathTransformHandle _Handle, const uint8_t pData[], int32_t szData, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_TransformData_1(TElXMLXPathTransformHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLDOMNodeHandle Reference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_TransformData_2(TElXMLXPathTransformHandle _Handle, TElXMLDOMNodeListHandle Nodes, const TElXMLDOMNodeHandle pReference[], int32_t szReference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_get_NamespaceMap(TElXMLXPathTransformHandle _Handle, TElXMLNamespaceMapHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_get_XPath(TElXMLXPathTransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_set_XPath(TElXMLXPathTransformHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathTransform_Create(TElXMLXPathTransformHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLXPATHTRANSFORM */

#ifdef SB_USE_CLASS_TELXMLXPATHFILTERITEM
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilterItem_get_Filter(TElXMLXPathFilterItemHandle _Handle, TSBXPathFilterOperationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilterItem_set_Filter(TElXMLXPathFilterItemHandle _Handle, TSBXPathFilterOperationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilterItem_get_NamespaceMap(TElXMLXPathFilterItemHandle _Handle, TElXMLNamespaceMapHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilterItem_get_XPath(TElXMLXPathFilterItemHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilterItem_set_XPath(TElXMLXPathFilterItemHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilterItem_get_XMLElement(TElXMLXPathFilterItemHandle _Handle, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilterItem_set_XMLElement(TElXMLXPathFilterItemHandle _Handle, TElXMLDOMElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilterItem_Create(TElXMLXPathFilterItemHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLXPATHFILTERITEM */

#ifdef SB_USE_CLASS_TELXMLXPATHFILTER2TRANSFORM
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_GetDefaultTransformAlgorithmURI(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_GetDefaultTransformAlgorithmURI_1(TElXMLXPathFilter2TransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_IsTransformAlgorithmSupported(const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_IsTransformAlgorithmSupported_1(TElXMLXPathFilter2TransformHandle _Handle, const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_Add(TElXMLXPathFilter2TransformHandle _Handle, TElXMLXPathFilterItemHandle AFilter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_Delete(TElXMLXPathFilter2TransformHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_Clear(TElXMLXPathFilter2TransformHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_LoadFromXML(TElXMLXPathFilter2TransformHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_SaveToXML(TElXMLXPathFilter2TransformHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_TransformData(TElXMLXPathFilter2TransformHandle _Handle, const uint8_t pData[], int32_t szData, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_TransformData_1(TElXMLXPathFilter2TransformHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLDOMNodeHandle Reference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_TransformData_2(TElXMLXPathFilter2TransformHandle _Handle, TElXMLDOMNodeListHandle Nodes, const TElXMLDOMNodeHandle pReference[], int32_t szReference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_get_Count(TElXMLXPathFilter2TransformHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_get_Filter(TElXMLXPathFilter2TransformHandle _Handle, int32_t Index, TElXMLXPathFilterItemHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLXPathFilter2Transform_Create(TElXMLXPathFilter2TransformHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLXPATHFILTER2TRANSFORM */

#ifdef SB_USE_CLASS_TELXMLTRANSFORMCHAIN
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_TransformData(TElXMLTransformChainHandle _Handle, const uint8_t pData[], int32_t szData, TElXMLCanonicalizationMethodRaw CanonicalizationMethod, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_TransformData_1(TElXMLTransformChainHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLCanonicalizationMethodRaw CanonicalizationMethod, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_TransformData_2(TElXMLTransformChainHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLDOMNodeHandle ReferenceNode, TElXMLCanonicalizationMethodRaw CanonicalizationMethod, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_TransformData_3(TElXMLTransformChainHandle _Handle, TElXMLDOMNodeListHandle Nodes, TElXMLCanonicalizationMethodRaw CanonicalizationMethod, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_TransformData_4(TElXMLTransformChainHandle _Handle, TElXMLDOMNodeListHandle Nodes, const TElXMLDOMNodeHandle pReferenceNodes[], int32_t szReferenceNodes, TElXMLCanonicalizationMethodRaw CanonicalizationMethod, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_CloneTransforms(TElXMLTransformChainHandle _Handle, const char * pcANamespaceURI, int32_t szANamespaceURI, TElXMLTransformChainHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_Add(TElXMLTransformChainHandle _Handle, TElXMLTransformHandle Transform, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_AddCanonicalizationTransform(TElXMLTransformChainHandle _Handle, TElXMLCanonicalizationMethodRaw AMethod, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_AddEnvelopedSignatureTransform(TElXMLTransformChainHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_Insert(TElXMLTransformChainHandle _Handle, int32_t Index, TElXMLTransformHandle Transform);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_Delete(TElXMLTransformChainHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_Clear(TElXMLTransformChainHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_IndexOf(TElXMLTransformChainHandle _Handle, TElXMLTransformHandle Transform, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_IsEmpty(TElXMLTransformChainHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_LoadFromXML(TElXMLTransformChainHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_SaveToXML(TElXMLTransformChainHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_get_Count(TElXMLTransformChainHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_get_Transforms(TElXMLTransformChainHandle _Handle, int32_t Index, TElXMLTransformHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTransformChain_Create(const char * pcANamespaceURI, int32_t szANamespaceURI, TElXMLTransformChainHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLTRANSFORMCHAIN */

#ifdef SB_USE_CLASS_TELXMLUNSUPPORTEDTRANSFORM
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsupportedTransform_GetDefaultTransformAlgorithmURI(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsupportedTransform_GetDefaultTransformAlgorithmURI_1(TElXMLUnsupportedTransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsupportedTransform_IsTransformAlgorithmSupported(const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsupportedTransform_IsTransformAlgorithmSupported_1(TElXMLUnsupportedTransformHandle _Handle, const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsupportedTransform_SaveToXML(TElXMLUnsupportedTransformHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsupportedTransform_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsupportedTransform_TransformData(TElXMLUnsupportedTransformHandle _Handle, const uint8_t pData[], int32_t szData, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsupportedTransform_TransformData_1(TElXMLUnsupportedTransformHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLDOMNodeHandle Reference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsupportedTransform_TransformData_2(TElXMLUnsupportedTransformHandle _Handle, TElXMLDOMNodeListHandle Nodes, const TElXMLDOMNodeHandle pReference[], int32_t szReference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsupportedTransform_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsupportedTransform_Create(TElXMLUnsupportedTransformHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLUNSUPPORTEDTRANSFORM */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElXMLTransformClass_ce_ptr;
extern zend_class_entry *TElXMLTransform_ce_ptr;
extern zend_class_entry *TElXMLNullTransform_ce_ptr;
extern zend_class_entry *TElXMLBase64Transform_ce_ptr;
extern zend_class_entry *TElXMLC14NTransform_ce_ptr;
extern zend_class_entry *TElXMLEnvelopedSignatureTransform_ce_ptr;
extern zend_class_entry *TElXMLXPathTransform_ce_ptr;
extern zend_class_entry *TElXMLXPathFilterItem_ce_ptr;
extern zend_class_entry *TElXMLXPathFilter2Transform_ce_ptr;
extern zend_class_entry *TElXMLTransformChain_ce_ptr;
extern zend_class_entry *TElXMLUnsupportedTransform_ce_ptr;

void Register_TElXMLTransform(TSRMLS_D);
void Register_TElXMLNullTransform(TSRMLS_D);
void Register_TElXMLBase64Transform(TSRMLS_D);
void Register_TElXMLC14NTransform(TSRMLS_D);
void Register_TElXMLEnvelopedSignatureTransform(TSRMLS_D);
void Register_TElXMLXPathTransform(TSRMLS_D);
void Register_TElXMLXPathFilterItem(TSRMLS_D);
void Register_TElXMLXPathFilter2Transform(TSRMLS_D);
void Register_TElXMLTransformChain(TSRMLS_D);
void Register_TElXMLUnsupportedTransform(TSRMLS_D);
SB_PHP_FUNCTION(SBXMLTransform, Initialize);
SB_PHP_FUNCTION(SBXMLTransform, LoadDocumentFromData);
SB_PHP_FUNCTION(SBXMLTransform, NodeToNodeList);
SB_PHP_FUNCTION(SBXMLTransform, RegisterTransformClass);
SB_PHP_FUNCTION(SBXMLTransform, UnregisterTransformClass);
SB_PHP_FUNCTION(SBXMLTransform, FindTransformClass);
void Register_SBXMLTransform_Constants(int module_number TSRMLS_DC);
void Register_SBXMLTransform_Enum_Flags(TSRMLS_D);
void Register_SBXMLTransform_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_XMLTRANSFORM
SB_IMPORT uint32_t SB_APIENTRY SBXMLTransform_Initialize(void);
SB_IMPORT uint32_t SB_APIENTRY SBXMLTransform_LoadDocumentFromData(const uint8_t pData[], int32_t szData, TElXMLDOMDocumentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLTransform_NodeToNodeList(const TElXMLDOMNodeHandle Node, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLTransform_RegisterTransformClass(TElXMLTransformClassHandle TransformClass);
SB_IMPORT uint32_t SB_APIENTRY SBXMLTransform_UnregisterTransformClass(TElXMLTransformClassHandle TransformClass);
SB_IMPORT uint32_t SB_APIENTRY SBXMLTransform_FindTransformClass(const char * pcAlgorithm, int32_t szAlgorithm, TElXMLTransformClassHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_XMLTRANSFORM */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLTRANSFORM */

