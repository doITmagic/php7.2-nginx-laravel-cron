#ifndef __INC_SBXMLUTILS
#define __INC_SBXMLUTILS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbstrutils.h"
#include "sbencoding.h"
#include "sbxmldefs.h"
#include "sbxmlcore.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_XML_DATETIME_SKIP_TIMEZONE 	-1000

typedef uint8_t TSBXMLDateTimeFormatRaw;

typedef enum
{
	xdfYear = 0,
	xdfYearMonth = 1,
	xdfFullDate = 2,
	xdfDateHoursMinutes = 3,
	xdfDateTimeWithSeconds = 4,
	xdfDateTimeWithSecondFraction = 5,
	xdfFullDateTime = 6
} TSBXMLDateTimeFormat;

#ifdef __cplusplus
};	/* extern "C" */
#endif

SB_PHP_FUNCTION(SBXMLUtils, ParseElementFromXMLString);
SB_PHP_FUNCTION(SBXMLUtils, ParseNodeListFromXMLString);
SB_PHP_FUNCTION(SBXMLUtils, ConvertToBase64String);
SB_PHP_FUNCTION(SBXMLUtils, ConvertFromBase64String);
SB_PHP_FUNCTION(SBXMLUtils, ConvertBinaryToBigInt);
SB_PHP_FUNCTION(SBXMLUtils, ConvertBigIntToBinary);
SB_PHP_FUNCTION(SBXMLUtils, ConvertHexToBinary);
SB_PHP_FUNCTION(SBXMLUtils, AddTextToXMLElement);
SB_PHP_FUNCTION(SBXMLUtils, InsertTextBeforeXMLElement);
SB_PHP_FUNCTION(SBXMLUtils, GetTextFromXMLElement);
SB_PHP_FUNCTION(SBXMLUtils, GetStrictTextFromXMLElement);
SB_PHP_FUNCTION(SBXMLUtils, FindChildElementByLocalName);
SB_PHP_FUNCTION(SBXMLUtils, FindChildElement);
SB_PHP_FUNCTION(SBXMLUtils, FindElementById);
SB_PHP_FUNCTION(SBXMLUtils, FindElementByName);
SB_PHP_FUNCTION(SBXMLUtils, ExtractIdFromLocalURI);
SB_PHP_FUNCTION(SBXMLUtils, GetElementId);
SB_PHP_FUNCTION(SBXMLUtils, SetElementId);
SB_PHP_FUNCTION(SBXMLUtils, CanonicalizationMethodToURI);
SB_PHP_FUNCTION(SBXMLUtils, URIToCanonicalizationMethod);
SB_PHP_FUNCTION(SBXMLUtils, AddPrefixes);
SB_PHP_FUNCTION(SBXMLUtils, DateTimeToXMLString);
SB_PHP_FUNCTION(SBXMLUtils, XMLStringToDateTime);
SB_PHP_FUNCTION(SBXMLUtils, DateTimeFormatToString);
SB_PHP_FUNCTION(SBXMLUtils, DecodeXMLEntities);
SB_PHP_FUNCTION(SBXMLUtils, EncodeXMLEntities);
void Register_SBXMLUtils_Constants(int module_number TSRMLS_DC);
void Register_SBXMLUtils_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_XMLUTILS
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_ParseElementFromXMLString(const char * pcData, int32_t szData, const TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_ParseNodeListFromXMLString(const char * pcData, int32_t szData, const TElXMLDOMDocumentHandle Document, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_ConvertToBase64String(const uint8_t pBuf[], int32_t szBuf, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_ConvertFromBase64String(const char * pcS, int32_t szS, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_ConvertBinaryToBigInt(const uint8_t pBuf[], int32_t szBuf, int8_t AllowNegativeNumbers, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_ConvertBigIntToBinary(const char * pcValue, int32_t szValue, int8_t AllowHexNumbers, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_ConvertHexToBinary(const char * pcValue, int32_t szValue, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_AddTextToXMLElement(const char * pcText, int32_t szText, const TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_InsertTextBeforeXMLElement(const char * pcText, int32_t szText, TElXMLDOMElementHandle Element, TElXMLDOMNodeHandle Ref);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_GetTextFromXMLElement(const TElXMLDOMElementHandle Element, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_GetStrictTextFromXMLElement(const TElXMLDOMElementHandle Element, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_FindChildElementByLocalName(const TElXMLDOMElementHandle Element, const char * pcLocalName, int32_t szLocalName, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_FindChildElement(const TElXMLDOMElementHandle Element, const char * pcName, int32_t szName, const char * pcNamespaceURI, int32_t szNamespaceURI, const char * pcDefaultPrefix, int32_t szDefaultPrefix, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_FindElementById(const TElXMLDOMElementHandle RootElement, const char * pcID, int32_t szID, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_FindElementById_1(const TElXMLDOMElementHandle RootElement, const char * pcID, int32_t szID, const char * pcNamespaceURI, int32_t szNamespaceURI, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_FindElementByName(const TElXMLDOMElementHandle RootElement, const char * pcName, int32_t szName, const char * pcNamespaceURI, int32_t szNamespaceURI, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_ExtractIdFromLocalURI(const char * pcURI, int32_t szURI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_ExtractIdFromLocalURI_1(const char * pcURI, int32_t szURI, char * pcId, int32_t * szId, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_GetElementId(TElXMLDOMElementHandle Element, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_SetElementId(TElXMLDOMElementHandle Element, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_CanonicalizationMethodToURI(TElXMLCanonicalizationMethodRaw ACanonicalizationMethod, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_URIToCanonicalizationMethod(const char * pcAURI, int32_t szAURI, TElXMLCanonicalizationMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_AddPrefixes(TElXMLDOMElementHandle Element, const char * pcPrefixes, int32_t szPrefixes, const char * pcNamespaceURI, int32_t szNamespaceURI);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_DateTimeToXMLString(int64_t Value, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_DateTimeToXMLString_1(int64_t Value, TSBXMLDateTimeFormatRaw Format, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_DateTimeToXMLString_2(int64_t Value, TSBXMLDateTimeFormatRaw Format, int32_t TimeZoneOffset, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_XMLStringToDateTime(const char * pcValue, int32_t szValue, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_DateTimeFormatToString(TSBXMLDateTimeFormatRaw Format, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_DecodeXMLEntities(const char * pcStr, int32_t szStr, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLUtils_EncodeXMLEntities(const char * pcStr, int32_t szStr, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_XMLUTILS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLUTILS */

