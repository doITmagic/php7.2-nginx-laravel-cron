#ifndef __INC_SBXMLWSSCORE
#define __INC_SBXMLWSSCORE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbcryptoprov.h"
#include "sbcustomcertstorage.h"
#include "sbcrlstorage.h"
#include "sbpkcs7.h"
#include "sbstrutils.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbx509.h"
#include "sbxmldefs.h"
#include "sbxmlcore.h"
#include "sbxmlsec.h"
#include "sbxmlutils.h"
#include "sbxmlsoapcore.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElXMLWSSEElementHandle;

typedef TElClassHandle TElXMLWSSEBaseTokenHandle;

typedef TElClassHandle TElXMLWSSETextElementHandle;

typedef TElClassHandle TElXMLWSSEPasswordHandle;

typedef TElClassHandle TElXMLWSSENonceHandle;

typedef TElClassHandle TElXMLWSUDateTimeHandle;

typedef TElClassHandle TElXMLWSSEUsernameTokenHandle;

typedef TElClassHandle TElXMLWSUTimestampHandle;

typedef TElClassHandle TElXMLWSSEBinarySecurityTokenHandle;

typedef TElClassHandle TElXMLWSSESecurityHandle;

typedef TElClassHandle TElXMLWSSEReferenceHandle;

typedef TElClassHandle TElXMLWSSEKeyIdentifierHandle;

typedef TElClassHandle TElXMLWSSESecurityTokenReferenceHandle;

typedef uint8_t TElXMLWSSESecurityTokenReferenceTypeRaw;

typedef enum
{
	wsrtNone = 0,
	wsrtReference = 1,
	wsrtKeyIdentifier = 2,
	wsrtEmbeddedReference = 3
} TElXMLWSSESecurityTokenReferenceType;

typedef uint8_t TSBXMLWSSETokenTypeRaw;

typedef enum
{
	wttX509v3 = 0,
	wttPKCS7 = 1,
	wttX509PKIPathv1 = 2,
	wttUnknown = 3
} TSBXMLWSSETokenType;

#ifdef SB_USE_CLASS_TELXMLWSSEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEElement_LoadFromXML(TElXMLWSSEElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEElement_SaveToXML(TElXMLWSSEElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEElement_Create(TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEElement_Create_1(const char * pcAName, int32_t szAName, TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEElement_Create_2(TElXMLDOMElementHandle ParentElement, TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEElement_Create_3(TElXMLDOMElementHandle ParentElement, const char * pcAName, int32_t szAName, TElXMLWSSEElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLWSSEELEMENT */

#ifdef SB_USE_CLASS_TELXMLWSSEBASETOKEN
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBaseToken_get_ID(TElXMLWSSEBaseTokenHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBaseToken_set_ID(TElXMLWSSEBaseTokenHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBaseToken_Create(TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBaseToken_Create_1(const char * pcAName, int32_t szAName, TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBaseToken_Create_2(TElXMLDOMElementHandle ParentElement, TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBaseToken_Create_3(TElXMLDOMElementHandle ParentElement, const char * pcAName, int32_t szAName, TElXMLWSSEElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLWSSEBASETOKEN */

#ifdef SB_USE_CLASS_TELXMLWSSETEXTELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSETextElement_get_Data(TElXMLWSSETextElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSETextElement_set_Data(TElXMLWSSETextElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSETextElement_Create(TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSETextElement_Create_1(const char * pcAName, int32_t szAName, TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSETextElement_Create_2(TElXMLDOMElementHandle ParentElement, TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSETextElement_Create_3(TElXMLDOMElementHandle ParentElement, const char * pcAName, int32_t szAName, TElXMLWSSEElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLWSSETEXTELEMENT */

#ifdef SB_USE_CLASS_TELXMLWSSEPASSWORD
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEPassword_get_PasswordType(TElXMLWSSEPasswordHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEPassword_set_PasswordType(TElXMLWSSEPasswordHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEPassword_Create(TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEPassword_Create_1(const char * pcAName, int32_t szAName, TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEPassword_Create_2(TElXMLDOMElementHandle ParentElement, TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEPassword_Create_3(TElXMLDOMElementHandle ParentElement, const char * pcAName, int32_t szAName, TElXMLWSSEElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLWSSEPASSWORD */

#ifdef SB_USE_CLASS_TELXMLWSSENONCE
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSENonce_get_EncodingType(TElXMLWSSENonceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSENonce_set_EncodingType(TElXMLWSSENonceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSENonce_Create(TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSENonce_Create_1(const char * pcAName, int32_t szAName, TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSENonce_Create_2(TElXMLDOMElementHandle ParentElement, TElXMLWSSEElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSENonce_Create_3(TElXMLDOMElementHandle ParentElement, const char * pcAName, int32_t szAName, TElXMLWSSEElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLWSSENONCE */

#ifdef SB_USE_CLASS_TELXMLWSUDATETIME
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUDateTime_get_Value(TElXMLWSUDateTimeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUDateTime_set_Value(TElXMLWSUDateTimeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUDateTime_get_ValueType(TElXMLWSUDateTimeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUDateTime_set_ValueType(TElXMLWSUDateTimeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUDateTime_get_ValueUTC(TElXMLWSUDateTimeHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUDateTime_set_ValueUTC(TElXMLWSUDateTimeHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUDateTime_Create(TElXMLWSUDateTimeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUDateTime_Create_1(const char * pcAName, int32_t szAName, TElXMLWSUDateTimeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUDateTime_Create_2(TElXMLDOMElementHandle ParentElement, TElXMLWSUDateTimeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUDateTime_Create_3(TElXMLDOMElementHandle ParentElement, const char * pcAName, int32_t szAName, TElXMLWSUDateTimeHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLWSUDATETIME */

#ifdef SB_USE_CLASS_TELXMLWSSEUSERNAMETOKEN
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_Clear(TElXMLWSSEUsernameTokenHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_CreateUsername(TElXMLWSSEUsernameTokenHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_CreatePassword(TElXMLWSSEUsernameTokenHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_CreateNonce(TElXMLWSSEUsernameTokenHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_CreateCreated(TElXMLWSSEUsernameTokenHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_LoadFromXML(TElXMLWSSEUsernameTokenHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_get_Username(TElXMLWSSEUsernameTokenHandle _Handle, TElXMLWSSETextElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_get_Password(TElXMLWSSEUsernameTokenHandle _Handle, TElXMLWSSEPasswordHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_get_Nonce(TElXMLWSSEUsernameTokenHandle _Handle, TElXMLWSSENonceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_get_Created(TElXMLWSSEUsernameTokenHandle _Handle, TElXMLWSUDateTimeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_get_CreatedUTC(TElXMLWSSEUsernameTokenHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_set_CreatedUTC(TElXMLWSSEUsernameTokenHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_Create(TElXMLWSSEUsernameTokenHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_Create_1(const char * pcAName, int32_t szAName, TElXMLWSSEUsernameTokenHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_Create_2(TElXMLDOMElementHandle ParentElement, TElXMLWSSEUsernameTokenHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEUsernameToken_Create_3(TElXMLDOMElementHandle ParentElement, const char * pcAName, int32_t szAName, TElXMLWSSEUsernameTokenHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLWSSEUSERNAMETOKEN */

#ifdef SB_USE_CLASS_TELXMLWSUTIMESTAMP
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUTimestamp_Clear(TElXMLWSUTimestampHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUTimestamp_CreateCreated(TElXMLWSUTimestampHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUTimestamp_CreateExpires(TElXMLWSUTimestampHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUTimestamp_LoadFromXML(TElXMLWSUTimestampHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUTimestamp_get_Created(TElXMLWSUTimestampHandle _Handle, TElXMLWSUDateTimeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUTimestamp_get_CreatedUTC(TElXMLWSUTimestampHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUTimestamp_set_CreatedUTC(TElXMLWSUTimestampHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUTimestamp_get_Expires(TElXMLWSUTimestampHandle _Handle, TElXMLWSUDateTimeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUTimestamp_get_ExpiresUTC(TElXMLWSUTimestampHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUTimestamp_set_ExpiresUTC(TElXMLWSUTimestampHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUTimestamp_Create(TElXMLWSUTimestampHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUTimestamp_Create_1(const char * pcAName, int32_t szAName, TElXMLWSUTimestampHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUTimestamp_Create_2(TElXMLDOMElementHandle ParentElement, TElXMLWSUTimestampHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSUTimestamp_Create_3(TElXMLDOMElementHandle ParentElement, const char * pcAName, int32_t szAName, TElXMLWSUTimestampHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLWSUTIMESTAMP */

#ifdef SB_USE_CLASS_TELXMLWSSEBINARYSECURITYTOKEN
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_Clear(TElXMLWSSEBinarySecurityTokenHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_LoadFromXML(TElXMLWSSEBinarySecurityTokenHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_ExtractCertificates(TElXMLWSSEBinarySecurityTokenHandle _Handle, TElCustomCertStorageHandle CertStorage);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_SetCertificate(TElXMLWSSEBinarySecurityTokenHandle _Handle, TElX509CertificateHandle Cert);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_SetCertificate_1(TElXMLWSSEBinarySecurityTokenHandle _Handle, TElX509CertificateHandle Cert, TSBXMLWSSETokenTypeRaw TokenType);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_SetCertificates(TElXMLWSSEBinarySecurityTokenHandle _Handle, TElCustomCertStorageHandle CertStorage);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_SetCertificates_1(TElXMLWSSEBinarySecurityTokenHandle _Handle, TElCustomCertStorageHandle CertStorage, TSBXMLWSSETokenTypeRaw TokenType);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_get_Data(TElXMLWSSEBinarySecurityTokenHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_set_Data(TElXMLWSSEBinarySecurityTokenHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_get_EncodingType(TElXMLWSSEBinarySecurityTokenHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_set_EncodingType(TElXMLWSSEBinarySecurityTokenHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_get_ValueType(TElXMLWSSEBinarySecurityTokenHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_set_ValueType(TElXMLWSSEBinarySecurityTokenHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_get_TokenType(TElXMLWSSEBinarySecurityTokenHandle _Handle, TSBXMLWSSETokenTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_Create(TElXMLWSSEBinarySecurityTokenHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_Create_1(const char * pcAName, int32_t szAName, TElXMLWSSEBinarySecurityTokenHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_Create_2(TElXMLDOMElementHandle ParentElement, TElXMLWSSEBinarySecurityTokenHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEBinarySecurityToken_Create_3(TElXMLDOMElementHandle ParentElement, const char * pcAName, int32_t szAName, TElXMLWSSEBinarySecurityTokenHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLWSSEBINARYSECURITYTOKEN */

#ifdef SB_USE_CLASS_TELXMLWSSESECURITY
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurity_Clear(TElXMLWSSESecurityHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurity_LoadFromXML(TElXMLWSSESecurityHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurity_LoadFromHeaderBlock(TElXMLWSSESecurityHandle _Handle, TElXMLSOAPHeaderBlockHandle AHeaderBlock);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurity_AddToken(TElXMLWSSESecurityHandle _Handle, TElXMLWSSEBaseTokenHandle AToken, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurity_get_HeaderBlock(TElXMLWSSESecurityHandle _Handle, TElXMLSOAPHeaderBlockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurity_set_HeaderBlock(TElXMLWSSESecurityHandle _Handle, TElXMLSOAPHeaderBlockHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurity_get_TokenCount(TElXMLWSSESecurityHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurity_get_Tokens(TElXMLWSSESecurityHandle _Handle, int32_t Index, TElXMLWSSEBaseTokenHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurity_Create(TElXMLWSSESecurityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurity_Create_1(const char * pcAName, int32_t szAName, TElXMLWSSESecurityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurity_Create_2(TElXMLDOMElementHandle ParentElement, TElXMLWSSESecurityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurity_Create_3(TElXMLDOMElementHandle ParentElement, const char * pcAName, int32_t szAName, TElXMLWSSESecurityHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLWSSESECURITY */

#ifdef SB_USE_CLASS_TELXMLWSSEREFERENCE
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEReference_Clear(TElXMLWSSEReferenceHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEReference_LoadFromXML(TElXMLWSSEReferenceHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEReference_SaveToXML(TElXMLWSSEReferenceHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEReference_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEReference_get_URI(TElXMLWSSEReferenceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEReference_set_URI(TElXMLWSSEReferenceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEReference_get_ValueType(TElXMLWSSEReferenceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEReference_set_ValueType(TElXMLWSSEReferenceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEReference_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLWSSEREFERENCE */

#ifdef SB_USE_CLASS_TELXMLWSSEKEYIDENTIFIER
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_Clear(TElXMLWSSEKeyIdentifierHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_LoadFromXML(TElXMLWSSEKeyIdentifierHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_SaveToXML(TElXMLWSSEKeyIdentifierHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_get_Data(TElXMLWSSEKeyIdentifierHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_set_Data(TElXMLWSSEKeyIdentifierHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_get_Value(TElXMLWSSEKeyIdentifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_set_Value(TElXMLWSSEKeyIdentifierHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_get_ID(TElXMLWSSEKeyIdentifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_set_ID(TElXMLWSSEKeyIdentifierHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_get_ValueType(TElXMLWSSEKeyIdentifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_set_ValueType(TElXMLWSSEKeyIdentifierHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_get_EncodingType(TElXMLWSSEKeyIdentifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_set_EncodingType(TElXMLWSSEKeyIdentifierHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSEKeyIdentifier_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLWSSEKEYIDENTIFIER */

#ifdef SB_USE_CLASS_TELXMLWSSESECURITYTOKENREFERENCE
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_Clear(TElXMLWSSESecurityTokenReferenceHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_LoadFromXML(TElXMLWSSESecurityTokenReferenceHandle _Handle, TElXMLDOMNodeHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_SaveToXML(TElXMLWSSESecurityTokenReferenceHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_get_ID(TElXMLWSSESecurityTokenReferenceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_set_ID(TElXMLWSSESecurityTokenReferenceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_get_TokenType(TElXMLWSSESecurityTokenReferenceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_set_TokenType(TElXMLWSSESecurityTokenReferenceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_get_Usage(TElXMLWSSESecurityTokenReferenceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_set_Usage(TElXMLWSSESecurityTokenReferenceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_get_ReferenceType(TElXMLWSSESecurityTokenReferenceHandle _Handle, TElXMLWSSESecurityTokenReferenceTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_set_ReferenceType(TElXMLWSSESecurityTokenReferenceHandle _Handle, TElXMLWSSESecurityTokenReferenceTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_get_Reference(TElXMLWSSESecurityTokenReferenceHandle _Handle, TElXMLWSSEReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_get_KeyIdentifier(TElXMLWSSESecurityTokenReferenceHandle _Handle, TElXMLWSSEKeyIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_get_EmbeddedNode(TElXMLWSSESecurityTokenReferenceHandle _Handle, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_set_EmbeddedNode(TElXMLWSSESecurityTokenReferenceHandle _Handle, TElXMLDOMNodeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_Create(int8_t OwnResources, TElXMLWSSESecurityTokenReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLWSSESecurityTokenReference_Create_1(int8_t AOwnResources, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElXMLWSSESecurityTokenReferenceHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLWSSESECURITYTOKENREFERENCE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElXMLWSSEElement_ce_ptr;
extern zend_class_entry *TElXMLWSSEBaseToken_ce_ptr;
extern zend_class_entry *TElXMLWSSETextElement_ce_ptr;
extern zend_class_entry *TElXMLWSSEPassword_ce_ptr;
extern zend_class_entry *TElXMLWSSENonce_ce_ptr;
extern zend_class_entry *TElXMLWSUDateTime_ce_ptr;
extern zend_class_entry *TElXMLWSSEUsernameToken_ce_ptr;
extern zend_class_entry *TElXMLWSUTimestamp_ce_ptr;
extern zend_class_entry *TElXMLWSSEBinarySecurityToken_ce_ptr;
extern zend_class_entry *TElXMLWSSESecurity_ce_ptr;
extern zend_class_entry *TElXMLWSSEReference_ce_ptr;
extern zend_class_entry *TElXMLWSSEKeyIdentifier_ce_ptr;
extern zend_class_entry *TElXMLWSSESecurityTokenReference_ce_ptr;

void Register_TElXMLWSSEElement(TSRMLS_D);
void Register_TElXMLWSSEBaseToken(TSRMLS_D);
void Register_TElXMLWSSETextElement(TSRMLS_D);
void Register_TElXMLWSSEPassword(TSRMLS_D);
void Register_TElXMLWSSENonce(TSRMLS_D);
void Register_TElXMLWSUDateTime(TSRMLS_D);
void Register_TElXMLWSSEUsernameToken(TSRMLS_D);
void Register_TElXMLWSUTimestamp(TSRMLS_D);
void Register_TElXMLWSSEBinarySecurityToken(TSRMLS_D);
void Register_TElXMLWSSESecurity(TSRMLS_D);
void Register_TElXMLWSSEReference(TSRMLS_D);
void Register_TElXMLWSSEKeyIdentifier(TSRMLS_D);
void Register_TElXMLWSSESecurityTokenReference(TSRMLS_D);
SB_PHP_FUNCTION(SBXMLWSSCore, WSUGetElementId);
SB_PHP_FUNCTION(SBXMLWSSCore, WSUSetElementId);
SB_PHP_FUNCTION(SBXMLWSSCore, WSSETokenTypeToURI);
void Register_SBXMLWSSCore_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_XMLWSSCORE
SB_IMPORT uint32_t SB_APIENTRY SBXMLWSSCore_WSUGetElementId(TElXMLDOMElementHandle Element, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLWSSCore_WSUSetElementId(TElXMLDOMElementHandle Element, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY SBXMLWSSCore_WSSETokenTypeToURI(TSBXMLWSSETokenTypeRaw TokenType, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_XMLWSSCORE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLWSSCORE */

