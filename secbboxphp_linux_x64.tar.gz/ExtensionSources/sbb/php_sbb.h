#ifndef PHP_SBB_H
#define PHP_SBB_H

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"

#include "sbutils.h"

extern zend_module_entry sbb_module_entry;
#define phpext_sbb_ptr &sbb_module_entry

#define PHP_SBB_VERSION  SBB_VERSION_NUMBER

#ifdef PHP_WIN32
#	define PHP_SBB_API __declspec(dllexport)
#elif defined(__GNUC__) && __GNUC__ >= 4
#	define PHP_SBB_API __attribute__ ((visibility("default")))
#else
#	define PHP_SBB_API
#endif

#ifdef ZTS
#include "TSRM.h"
#endif

ZEND_BEGIN_MODULE_GLOBALS(sbb)
	char * license_key;
ZEND_END_MODULE_GLOBALS(sbb)

/* In every utility function you add that needs to use variables 
   in php_sbb_globals, call TSRMLS_FETCH(); after declaring other 
   variables used by that function, or better yet, pass in TSRMLS_CC
   after the last function argument and declare your utility function
   with TSRMLS_DC after the last declared argument.  Always refer to
   the globals in your function as SBB_G(variable).  You are 
   encouraged to rename these macros something shorter, see
   examples in any other php module directory.
*/

#ifdef ZTS
#define SBB_G(v) TSRMG(sbb_globals_id, zend_sbb_globals *, v)
#else
#define SBB_G(v) (sbb_globals.v)
#endif

#endif	/* PHP_SBB_H */
