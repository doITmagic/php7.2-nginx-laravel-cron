#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php_sbb.h"
#include "sball.h"

ZEND_DECLARE_MODULE_GLOBALS(sbb)

#ifdef COMPILE_DL_SBB
ZEND_GET_MODULE(sbb)
#endif

static PHP_INI_MH(OnUpdateSBLicenseKey)
{
	SB_OUTPUT_DEBUG("On update license key")
#if PHP_VERSION_ID < 70000L
	if (0 == new_value_length)
#else
	if (0 == ZSTR_LEN(new_value))
#endif
		return SUCCESS;
	else
	{
#if PHP_VERSION_ID < 70000L
		uint32_t error = SBUtils_SetLicenseKey(new_value, new_value_length);
#else
		uint32_t error = SBUtils_SetLicenseKey(ZSTR_VAL(new_value), ZSTR_LEN(new_value));
#endif
		if (SB_ERROR_OK == error)
			return SUCCESS;
		else
		{
			char *errorMsg = NULL;
			int errorMsg_len = 0;
			uint32_t err = SBGetLastErrorMessageA(NULL, &errorMsg_len);
			if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == err)
			{
				errorMsg = emalloc(errorMsg_len + 1);
				err = SBGetLastErrorMessageA(errorMsg, &errorMsg_len);
				errorMsg[errorMsg_len] = 0;
			}
			
			php_error_docref(NULL TSRMLS_CC, E_WARNING, "[SecureBlackbox] Invalid license key in php.ini: %s", errorMsg);
			if (errorMsg)
				efree(errorMsg);
			return FAILURE;
		}
	}
}

PHP_INI_BEGIN()
	STD_PHP_INI_ENTRY("sbb.license_key", "", PHP_INI_ALL, OnUpdateSBLicenseKey, license_key, zend_sbb_globals, sbb_globals)
PHP_INI_END()

static void php_sbb_init_globals(zend_sbb_globals *sbb_globals)
{
	sbb_globals->license_key = "";
}

PHP_MINIT_FUNCTION(sbb)
{
	SB_OUTPUT_DEBUG("Module init start")
	REGISTER_INI_ENTRIES();
	SBSetEventFreeDataCallback(&SBEventFreeData);

#ifdef MACOS
	// SBAppleCommon unit constants
	Register_SBAppleCommon_Constants(module_number TSRMLS_CC);
#endif

	// SBConstants unit constants
	Register_SBConstants_Constants(module_number TSRMLS_CC);

	// SBASN1 unit constants
	Register_SBASN1_Constants(module_number TSRMLS_CC);

	// SBASN1Tree unit constants
	Register_SBASN1Tree_Constants(module_number TSRMLS_CC);

	// SBMSKeyBlob unit constants
	Register_SBMSKeyBlob_Constants(module_number TSRMLS_CC);

	// SBPEM unit constants
	Register_SBPEM_Constants(module_number TSRMLS_CC);

	// SBTypes unit constants
	Register_SBTypes_Constants(module_number TSRMLS_CC);

	// SBUtils unit constants
	Register_SBUtils_Constants(module_number TSRMLS_CC);

	// SBStrUtils unit constants
	Register_SBStrUtils_Constants(module_number TSRMLS_CC);

	// SBEncoding unit constants
	Register_SBEncoding_Constants(module_number TSRMLS_CC);

	// SBSocket unit constants
	Register_SBSocket_Constants(module_number TSRMLS_CC);

	// SBCryptoProv unit constants
	Register_SBCryptoProv_Constants(module_number TSRMLS_CC);

	// SBCryptoProvRS unit constants
	Register_SBCryptoProvRS_Constants(module_number TSRMLS_CC);

	// SBCryptoProvBuiltIn unit constants
	Register_SBCryptoProvBuiltIn_Constants(module_number TSRMLS_CC);

	// SBCryptoProvBuiltInSym unit constants
	Register_SBCryptoProvBuiltInSym_Constants(module_number TSRMLS_CC);

	// SBX509 unit constants
	Register_SBX509_Constants(module_number TSRMLS_CC);

	// SBX509Ext unit constants
	Register_SBX509Ext_Constants(module_number TSRMLS_CC);

	// SBCRL unit constants
	Register_SBCRL_Constants(module_number TSRMLS_CC);

	// SBCertRetriever unit constants
	Register_SBCertRetriever_Constants(module_number TSRMLS_CC);

	// SBCertValidator unit constants
	Register_SBCertValidator_Constants(module_number TSRMLS_CC);

	// SBMessages unit constants
	Register_SBMessages_Constants(module_number TSRMLS_CC);

	// SBPKCS5 unit constants
	Register_SBPKCS5_Constants(module_number TSRMLS_CC);

	// SBPKCS7 unit constants
	Register_SBPKCS7_Constants(module_number TSRMLS_CC);

	// SBPKCS7Utils unit constants
	Register_SBPKCS7Utils_Constants(module_number TSRMLS_CC);

	// SBPKCS8 unit constants
	Register_SBPKCS8_Constants(module_number TSRMLS_CC);

	// SBPKCS12 unit constants
	Register_SBPKCS12_Constants(module_number TSRMLS_CC);

	// SBJKS unit constants
	Register_SBJKS_Constants(module_number TSRMLS_CC);

#ifdef SB_WINDOWS
	// SBWinCrypt unit constants
	Register_SBWinCrypt_Constants(module_number TSRMLS_CC);
#endif

	// SBSMIMESignatures unit constants
	Register_SBSMIMESignatures_Constants(module_number TSRMLS_CC);

	// SBOCSPCommon unit constants
	Register_SBOCSPCommon_Constants(module_number TSRMLS_CC);

	// SBTSPCommon unit constants
	Register_SBTSPCommon_Constants(module_number TSRMLS_CC);

	// SBGSSAPI unit constants
	Register_SBGSSAPI_Constants(module_number TSRMLS_CC);

	// SBGSSAPIBase unit constants
	Register_SBGSSAPIBase_Constants(module_number TSRMLS_CC);

#ifdef SB_WINDOWS
	// SBGSSWinAuth unit constants
	Register_SBGSSWinAuth_Constants(module_number TSRMLS_CC);
#endif

	// SBDNSSECConsts unit constants
	Register_SBDNSSECConsts_Constants(module_number TSRMLS_CC);

	// SBCustomFSAdapter unit constants
	Register_SBCustomFSAdapter_Constants(module_number TSRMLS_CC);

	// SBPunycode unit constants
	Register_SBPunycode_Constants(module_number TSRMLS_CC);

	// SBHTTPAuth unit constants
	Register_SBHTTPAuth_Constants(module_number TSRMLS_CC);

	// SBHTTPSConstants unit constants
	Register_SBHTTPSConstants_Constants(module_number TSRMLS_CC);

	// SBSASL unit constants
	Register_SBSASL_Constants(module_number TSRMLS_CC);

	// SBDC unit constants
	Register_SBDC_Constants(module_number TSRMLS_CC);

	// SBDCPKIConstants unit constants
	Register_SBDCPKIConstants_Constants(module_number TSRMLS_CC);

	// SBDCStateStorage unit constants
	Register_SBDCStateStorage_Constants(module_number TSRMLS_CC);

	// SBChSCJK unit constants
	Register_SBChSCJK_Constants(module_number TSRMLS_CC);

	// SBChSConvBase unit constants
	Register_SBChSConvBase_Constants(module_number TSRMLS_CC);

	// SBChSConvConsts unit constants
	Register_SBChSConvConsts_Constants(module_number TSRMLS_CC);

	// SBChSUnicode unit constants
	Register_SBChSUnicode_Constants(module_number TSRMLS_CC);

	// SBBCrypt unit constants
	Register_SBBCrypt_Constants(module_number TSRMLS_CC);

	// SBUsers unit constants
	Register_SBUsers_Constants(module_number TSRMLS_CC);

	// SBUniversalKeyStorage unit constants
	Register_SBUniversalKeyStorage_Constants(module_number TSRMLS_CC);

	// SBUniversalCertStorage unit constants
	Register_SBUniversalCertStorage_Constants(module_number TSRMLS_CC);

	// SBAttrCert unit constants
	Register_SBAttrCert_Constants(module_number TSRMLS_CC);

	// SBEdDSA unit constants
	Register_SBEdDSA_Constants(module_number TSRMLS_CC);

	// SBDataStorage unit constants
	Register_SBDataStorage_Constants(module_number TSRMLS_CC);

	// SBDataStorageUtils unit constants
	Register_SBDataStorageUtils_Constants(module_number TSRMLS_CC);

	// SBWebDAVClient unit constants
	Register_SBWebDAVClient_Constants(module_number TSRMLS_CC);

	// SBWebDAVCommon unit constants
	Register_SBWebDAVCommon_Constants(module_number TSRMLS_CC);

	// SBVCard unit constants
	Register_SBVCard_Constants(module_number TSRMLS_CC);

	// SBWebDAVServer unit constants
	Register_SBWebDAVServer_Constants(module_number TSRMLS_CC);

	// SBDCAuth unit constants
	Register_SBDCAuth_Constants(module_number TSRMLS_CC);

	// SBJNLP unit constants
	Register_SBJNLP_Constants(module_number TSRMLS_CC);

	// SBSimpleFTPS unit constants
	Register_SBSimpleFTPS_Constants(module_number TSRMLS_CC);

	// SBFTPSServer unit constants
	Register_SBFTPSServer_Constants(module_number TSRMLS_CC);

	// SBHTTPSCommon unit constants
	Register_SBHTTPSCommon_Constants(module_number TSRMLS_CC);

	// SBHTTPSClient unit constants
	Register_SBHTTPSClient_Constants(module_number TSRMLS_CC);

	// SBCookieMgr unit constants
	Register_SBCookieMgr_Constants(module_number TSRMLS_CC);

	// SBOAuth2 unit constants
	Register_SBOAuth2_Constants(module_number TSRMLS_CC);

	// SBWebSocketCommon unit constants
	Register_SBWebSocketCommon_Constants(module_number TSRMLS_CC);

	// SBSimpleOAuth2 unit constants
	Register_SBSimpleOAuth2_Constants(module_number TSRMLS_CC);

	// SBLDAPCertStorage unit constants
	Register_SBLDAPCertStorage_Constants(module_number TSRMLS_CC);

	// SBLDAPSClient unit constants
	Register_SBLDAPSClient_Constants(module_number TSRMLS_CC);

	// SBLDAPSCore unit constants
	Register_SBLDAPSCore_Constants(module_number TSRMLS_CC);

	// SBSMTPClient unit constants
	Register_SBSMTPClient_Constants(module_number TSRMLS_CC);

	// SBPOP3Client unit constants
	Register_SBPOP3Client_Constants(module_number TSRMLS_CC);

	// SBIMAPClient unit constants
	Register_SBIMAPClient_Constants(module_number TSRMLS_CC);

	// SBDomainKeys unit constants
	Register_SBDomainKeys_Constants(module_number TSRMLS_CC);

	// SBMIME unit constants
	Register_SBMIME_Constants(module_number TSRMLS_CC);

	// SBMIMEEnc unit constants
	Register_SBMIMEEnc_Constants(module_number TSRMLS_CC);

	// SBMIMEStream unit constants
	Register_SBMIMEStream_Constants(module_number TSRMLS_CC);

	// SBCompoundFileBase unit constants
	Register_SBCompoundFileBase_Constants(module_number TSRMLS_CC);

	// SBCompoundFileResources unit constants
	Register_SBCompoundFileResources_Constants(module_number TSRMLS_CC);

	// SBOfficeBinaryCore unit constants
	Register_SBOfficeBinaryCore_Constants(module_number TSRMLS_CC);

	// SBOfficeConstants unit constants
	Register_SBOfficeConstants_Constants(module_number TSRMLS_CC);

	// SBOfficeResources unit constants
	Register_SBOfficeResources_Constants(module_number TSRMLS_CC);

	// SBOfficeSecurity unit constants
	Register_SBOfficeSecurity_Constants(module_number TSRMLS_CC);

	// SBOfficeXMLCore unit constants
	Register_SBOfficeXMLCore_Constants(module_number TSRMLS_CC);

	// SBPDF unit constants
	Register_SBPDF_Constants(module_number TSRMLS_CC);

	// SBPDFCore unit constants
	Register_SBPDFCore_Constants(module_number TSRMLS_CC);

	// SBPDFSecurity unit constants
	Register_SBPDFSecurity_Constants(module_number TSRMLS_CC);

	// SBPDFUtils unit constants
	Register_SBPDFUtils_Constants(module_number TSRMLS_CC);

	// SBPGPConstants unit constants
	Register_SBPGPConstants_Constants(module_number TSRMLS_CC);

	// SBPGPEntities unit constants
	Register_SBPGPEntities_Constants(module_number TSRMLS_CC);

	// SBPGPExceptions unit constants
	Register_SBPGPExceptions_Constants(module_number TSRMLS_CC);

	// SBPGPResourceStrings unit constants
	Register_SBPGPResourceStrings_Constants(module_number TSRMLS_CC);

	// SBPGPUtils unit constants
	Register_SBPGPUtils_Constants(module_number TSRMLS_CC);

#ifdef SB_WINDOWS
	// SBPGPSFX unit constants
	Register_SBPGPSFX_Constants(module_number TSRMLS_CC);
#endif

	// SBLDAPSKeyserverClient unit constants
	Register_SBLDAPSKeyserverClient_Constants(module_number TSRMLS_CC);

	// SBCMS unit constants
	Register_SBCMS_Constants(module_number TSRMLS_CC);

	// SBPKCS11Common unit constants
	Register_SBPKCS11Common_Constants(module_number TSRMLS_CC);

	// SBPKCS11Base unit constants
	Register_SBPKCS11Base_Constants(module_number TSRMLS_CC);

	// SBAuthenticode unit constants
	Register_SBAuthenticode_Constants(module_number TSRMLS_CC);

	// SBCAdES unit constants
	Register_SBCAdES_Constants(module_number TSRMLS_CC);

	// SBCMC unit constants
	Register_SBCMC_Constants(module_number TSRMLS_CC);

	// SBOTPCommon unit constants
	Register_SBOTPCommon_Constants(module_number TSRMLS_CC);

	// SBOTPServer unit constants
	Register_SBOTPServer_Constants(module_number TSRMLS_CC);

	// SBUniversalCertStorageEx unit constants
	Register_SBUniversalCertStorageEx_Constants(module_number TSRMLS_CC);

	// SBAttrCertEx unit constants
	Register_SBAttrCertEx_Constants(module_number TSRMLS_CC);

	// SBHID unit constants
	Register_SBHID_Constants(module_number TSRMLS_CC);

	// SBU2FHID unit constants
	Register_SBU2FHID_Constants(module_number TSRMLS_CC);

	// SBU2FCommon unit constants
	Register_SBU2FCommon_Constants(module_number TSRMLS_CC);

#ifdef SB_WINDOWS
	// SBSCWin unit constants
	Register_SBSCWin_Constants(module_number TSRMLS_CC);
#else
	// SBCardCommon unit constants
	Register_SBCardCommon_Constants(module_number TSRMLS_CC);
#endif

	// SBSftp unit constants
	Register_SBSftp_Constants(module_number TSRMLS_CC);

	// SBSftpCommon unit constants
	Register_SBSftpCommon_Constants(module_number TSRMLS_CC);

	// SBSimpleSFTPServer unit constants
	Register_SBSimpleSFTPServer_Constants(module_number TSRMLS_CC);

	// SBSMIMECore unit constants
	Register_SBSMIMECore_Constants(module_number TSRMLS_CC);

	// SBSMIMECAdES unit constants
	Register_SBSMIMECAdES_Constants(module_number TSRMLS_CC);

	// SBSSHConstants unit constants
	Register_SBSSHConstants_Constants(module_number TSRMLS_CC);

	// SBSSHKeyStorage unit constants
	Register_SBSSHKeyStorage_Constants(module_number TSRMLS_CC);

	// SBSSHTerm unit constants
	Register_SBSSHTerm_Constants(module_number TSRMLS_CC);

	// SBSSHClient unit constants
	Register_SBSSHClient_Constants(module_number TSRMLS_CC);

	// SBSSHCommon unit constants
	Register_SBSSHCommon_Constants(module_number TSRMLS_CC);

	// SBSSHForwarding unit constants
	Register_SBSSHForwarding_Constants(module_number TSRMLS_CC);

	// SBSSHPubKeyCommon unit constants
	Register_SBSSHPubKeyCommon_Constants(module_number TSRMLS_CC);

	// SBSimpleSSHServer unit constants
	Register_SBSimpleSSHServer_Constants(module_number TSRMLS_CC);

	// SBSSLClient unit constants
	Register_SBSSLClient_Constants(module_number TSRMLS_CC);

	// SBSSLCommon unit constants
	Register_SBSSLCommon_Constants(module_number TSRMLS_CC);

	// SBSSLConstants unit constants
	Register_SBSSLConstants_Constants(module_number TSRMLS_CC);

	// SBCmdSSLClient unit constants
	Register_SBCmdSSLClient_Constants(module_number TSRMLS_CC);

	// SBSSLServer unit constants
	Register_SBSSLServer_Constants(module_number TSRMLS_CC);

	// SBXMLCore unit constants
	Register_SBXMLCore_Constants(module_number TSRMLS_CC);

	// SBXMLDefs unit constants
	Register_SBXMLDefs_Constants(module_number TSRMLS_CC);

	// SBXMLUtils unit constants
	Register_SBXMLUtils_Constants(module_number TSRMLS_CC);

	// SBXMLAdES unit constants
	Register_SBXMLAdES_Constants(module_number TSRMLS_CC);

	// SBXMLEnc unit constants
	Register_SBXMLEnc_Constants(module_number TSRMLS_CC);

	// SBXMLSec unit constants
	Register_SBXMLSec_Constants(module_number TSRMLS_CC);

	// SBXMLTransform unit constants
	Register_SBXMLTransform_Constants(module_number TSRMLS_CC);

	// SBXMLSOAPCore unit constants
	Register_SBXMLSOAPCore_Constants(module_number TSRMLS_CC);

	// SBXMLSOAP unit constants
	Register_SBXMLSOAP_Constants(module_number TSRMLS_CC);

	// SBArcZip unit constants
	Register_SBArcZip_Constants(module_number TSRMLS_CC);

	// SBZipEntities unit constants
	Register_SBZipEntities_Constants(module_number TSRMLS_CC);

	// SBZipUtils unit constants
	Register_SBZipUtils_Constants(module_number TSRMLS_CC);

	// SBArcTar unit constants
	Register_SBArcTar_Constants(module_number TSRMLS_CC);

	// SBTarEntities unit constants
	Register_SBTarEntities_Constants(module_number TSRMLS_CC);

	// SBArcGZip unit constants
	Register_SBArcGZip_Constants(module_number TSRMLS_CC);

	// SBArcBZip2 unit constants
	Register_SBArcBZip2_Constants(module_number TSRMLS_CC);

#ifdef SB_WINDOWS
	// SBZIPSFX unit constants
	Register_SBZIPSFX_Constants(module_number TSRMLS_CC);
#endif

	// SBXMLSAMLBind unit constants
	Register_SBXMLSAMLBind_Constants(module_number TSRMLS_CC);

	// SBXMLSAMLCommon unit constants
	Register_SBXMLSAMLCommon_Constants(module_number TSRMLS_CC);

	// SBXMLSAMLCore unit constants
	Register_SBXMLSAMLCore_Constants(module_number TSRMLS_CC);

	// SBXMLSAMLProtocol unit constants
	Register_SBXMLSAMLProtocol_Constants(module_number TSRMLS_CC);

	// SBASiCContainer unit constants
	Register_SBASiCContainer_Constants(module_number TSRMLS_CC);

	Register_Core(TSRMLS_C);

	// sbsystem unit class registration
#ifdef SB_WINDOWS
	Register_windows_FILETIME(TSRMLS_C);
#else
	Register_in_addr(TSRMLS_C);
	Register_sockaddr_in(TSRMLS_C);
#endif
	Register_TByteArray(TSRMLS_C);
	Register_TGuid(TSRMLS_C);
	Register_TObject(TSRMLS_C);
	Register_TBits(TSRMLS_C);
	Register_TPersistent(TSRMLS_C);
	Register_TStream(TSRMLS_C);
	Register_THandleStream(TSRMLS_C);
	Register_TFileStream(TSRMLS_C);
	Register_TInterfacedObject(TSRMLS_C);
	Register_TInterfacedPersistent(TSRMLS_C);
	Register_TList(TSRMLS_C);
	Register_TCustomMemoryStream(TSRMLS_C);
	Register_TComponent(TSRMLS_C);
	Register_TMemoryStream(TSRMLS_C);
	Register_TStrings(TSRMLS_C);
	Register_TStringList(TSRMLS_C);
	Register_TThread(TSRMLS_C);
	Register_sbsystem_Enum_Flags(TSRMLS_C);
	Register_sbsystem_Aliases(TSRMLS_C);

	// SBAlgorithmIdentifier unit class registration
	Register_TElAlgorithmIdentifier(TSRMLS_C);
	Register_TElRSAAlgorithmIdentifier(TSRMLS_C);
	Register_TElRSAPSSAlgorithmIdentifier(TSRMLS_C);
	Register_TElRSAOAEPAlgorithmIdentifier(TSRMLS_C);
	Register_TElDSAAlgorithmIdentifier(TSRMLS_C);
	Register_TElDHAlgorithmIdentifier(TSRMLS_C);
	Register_TElECAlgorithmIdentifier(TSRMLS_C);
	Register_TElECDSAAlgorithmIdentifier(TSRMLS_C);
	Register_TElGOST3411AlgorithmIdentifier(TSRMLS_C);
	Register_TElGOST3410AlgorithmIdentifier(TSRMLS_C);
	Register_TElGOST3411WithGOST3410AlgorithmIdentifier(TSRMLS_C);

#ifdef MACOS
	// SBAppleCertStorage unit class registration
	Register_TElAppleCertStorage(TSRMLS_C);
	Register_SBAppleCertStorage_Aliases(TSRMLS_C);

	// SBAppleCommon unit class registration
	Register___SB_CFError(TSRMLS_C);
	Register___SB_CFNull(TSRMLS_C);
	Register___SB_CFArray(TSRMLS_C);
	Register___SB_CFDictionary(TSRMLS_C);
	Register___SB_CFBoolean(TSRMLS_C);
	Register___SB_CFAllocator(TSRMLS_C);
	Register___SB_CFString(TSRMLS_C);
	Register___SB_CFData(TSRMLS_C);
	Register_SB_CFRange(TSRMLS_C);
	Register___SB_CFNumberRef(TSRMLS_C);
	Register___SB_CFSetRef(TSRMLS_C);
	Register___SB_CFRunLoopRef(TSRMLS_C);
	Register_SB_CFDictionaryKeyCallBacks(TSRMLS_C);
	Register_SB_CFDictionaryValueCallBacks(TSRMLS_C);
	Register_SB_CFArrayCallBacks(TSRMLS_C);
	Register_SB_OpaqueSecKeychainRef(TSRMLS_C);
	Register_SB_OpaqueSecAccessRef(TSRMLS_C);
	Register_SB_OpaqueSecKeychainItemRef(TSRMLS_C);
	Register_SB_SecItemImportExportKeyParameters(TSRMLS_C);
	Register_SB_SecKeychainAttribute(TSRMLS_C);
	Register_SB_SecKeychainAttributeList(TSRMLS_C);
	Register_SB_AuthorizationOpaqueRef(TSRMLS_C);
	Register_SB_AuthorizationItem(TSRMLS_C);
	Register_SB_AuthorizationItemSet(TSRMLS_C);
	Register___SB_SecTrust(TSRMLS_C);
	Register_SB_OpaqueSecCertificateRef(TSRMLS_C);
	Register_SB_OpaqueSecIdentityRef(TSRMLS_C);
	Register_SB_OpaqueSecKeyRef(TSRMLS_C);
	Register_SB_OpaqueSecPolicyRef(TSRMLS_C);
	Register_SBAppleCommon_Enum_Flags(TSRMLS_C);
#endif

	// SBCustomCrypto unit class registration
	Register_TElKeyMaterial(TSRMLS_C);
	Register_TElCustomCrypto(TSRMLS_C);
	Register_TElKeyMaterialStorage(TSRMLS_C);
	Register_SBCustomCrypto_Aliases(TSRMLS_C);

	// SBASN1 unit class registration
	Register_TElASN1Parser(TSRMLS_C);
	Register_TElASN1ParserFactory(TSRMLS_C);
	Register_SBASN1_Enum_Flags(TSRMLS_C);
	Register_SBASN1_Aliases(TSRMLS_C);

	// SBASN1Tree unit class registration
	Register_TElASN1CustomTag(TSRMLS_C);
	Register_TElASN1ConstrainedTag(TSRMLS_C);
	Register_TElASN1DataSource(TSRMLS_C);
	Register_TElASN1SimpleTag(TSRMLS_C);
	Register_TElASN1TagInfo(TSRMLS_C);
	Register_TElASN1StreamProcessor(TSRMLS_C);
	Register_TElASN1TagInfoFactory(TSRMLS_C);
	Register_TElASN1TagPath(TSRMLS_C);
	Register_TElASN1TagPathElement(TSRMLS_C);
	Register_TElASN1SmartStreamProcessor(TSRMLS_C);
	Register_SBASN1Tree_Enum_Flags(TSRMLS_C);

	// SBHashFunction unit class registration
	Register_TElHMACKeyMaterial(TSRMLS_C);
	Register_TElHashFunction(TSRMLS_C);
	Register_SBHashFunction_Aliases(TSRMLS_C);

	// SBMath unit class registration
	Register_TLInt(TSRMLS_C);

	// SBPEM unit class registration
	Register_TElPEMProcessor(TSRMLS_C);

	// SBPoly1305 unit class registration
	Register_TSBPoly1305Tag(TSRMLS_C);
	Register_SBPoly1305_Enum_Flags(TSRMLS_C);

	// SBRandom unit class registration
	Register_TElRandom(TSRMLS_C);
	Register_SBRandom_Aliases(TSRMLS_C);

	// SBTypes unit class registration
#ifndef SB_WINDOWS
	Register__FILETIME(TSRMLS_C);
	Register__LARGE_INTEGER(TSRMLS_C);
	Register__ULARGE_INTEGER(TSRMLS_C);
#endif
	Register_TMessageDigest128(TSRMLS_C);
	Register_TMessageDigest160(TSRMLS_C);
	Register_TMessageDigest224(TSRMLS_C);
	Register_TMessageDigest256(TSRMLS_C);
	Register_TMessageDigest320(TSRMLS_C);
	Register_TMessageDigest384(TSRMLS_C);
	Register_TMessageDigest512(TSRMLS_C);
	Register_TSBUInt32Pair(TSRMLS_C);
	Register_TElStringHolder(TSRMLS_C);
	Register_TElByteArrayHolder(TSRMLS_C);
	Register_SBTypes_Enum_Flags(TSRMLS_C);
	Register_SBTypes_Aliases(TSRMLS_C);

	// SBUtils unit class registration
	Register_TElStringList(TSRMLS_C);
	Register_TElByteArrayList(TSRMLS_C);
	Register_TSBObjectList(TSRMLS_C);
	Register_TElCustomExceptionHandler(TSRMLS_C);
	Register_TElStandardExceptionHandler(TSRMLS_C);
	Register_TElDebugExceptionHandler(TSRMLS_C);
	Register_TElCustomGlobalLogger(TSRMLS_C);
	Register_TElStandardGlobalLogger(TSRMLS_C);
	Register_TElByteArrayManager(TSRMLS_C);
	Register_TElIntegerArray(TSRMLS_C);
	Register_SBUtils_Enum_Flags(TSRMLS_C);
	Register_SBUtils_Aliases(TSRMLS_C);

	// SBStrUtils unit class registration
	Register_TElStringConverter(TSRMLS_C);
#ifdef SB_WINDOWS
	Register_TElPlatformStringConverter(TSRMLS_C);
#endif

	// SBStreams unit class registration
	Register_TElFileStream(TSRMLS_C);
	Register_TElDataStream(TSRMLS_C);
	Register_TElMultiStream(TSRMLS_C);
	Register_TElReadCachingStream(TSRMLS_C);
	Register_TElWriteCachingStream(TSRMLS_C);
	Register_SBStreams_Aliases(TSRMLS_C);

	// SBEncoding unit class registration
	Register_TSBBase64Context(TSRMLS_C);
	Register_TSBBase32Context(TSRMLS_C);

	// SBLicenseManager unit class registration
	Register_TElSBLicenseManager(TSRMLS_C);
	Register_SBLicenseManager_Enum_Flags(TSRMLS_C);
	Register_SBLicenseManager_Aliases(TSRMLS_C);

	// SBSharedResource unit class registration
	Register_TElSemaphore(TSRMLS_C);
	Register_TElSharedResource(TSRMLS_C);

	// SBSocket unit class registration
#ifndef SB_WINDOWS
	Register_hostent(TSRMLS_C);
#endif
	Register_sockaddr_storage(TSRMLS_C);
	Register_TElSocket(TSRMLS_C);
	Register_TElCustomProxyHeaderInfo(TSRMLS_C);
	Register_TElHAPROXYHeaderInfo(TSRMLS_C);
	Register_TElCustomSocketBinding(TSRMLS_C);
	Register_TElClientSocketBinding(TSRMLS_C);
	Register_TElDNSSettings(TSRMLS_C);
	Register_TElSocketSettings(TSRMLS_C);
	Register_SBSocket_Enum_Flags(TSRMLS_C);
	Register_SBSocket_Aliases(TSRMLS_C);

	// SBPortKnock unit class registration
	Register_TElPortKnockEntry(TSRMLS_C);
	Register_TElPortKnock(TSRMLS_C);
	Register_SBPortKnock_Aliases(TSRMLS_C);

	// SBStringList unit class registration
	Register_TElStringTokenizer(TSRMLS_C);
	Register_SBStringList_Enum_Flags(TSRMLS_C);
	Register_SBStringList_Aliases(TSRMLS_C);

	// SBTimer unit class registration
	Register_TTimerThread(TSRMLS_C);
	Register_TElTimer(TSRMLS_C);

	// SBCryptoProv unit class registration
	Register_TElCustomCryptoProvider(TSRMLS_C);
	Register_TElCustomCryptoProviderManager(TSRMLS_C);
	Register_TElCustomCryptoKeyContainer(TSRMLS_C);
	Register_TElCustomCryptoKey(TSRMLS_C);
	Register_TElCustomCryptoObject(TSRMLS_C);
	Register_TElCustomCryptoContext(TSRMLS_C);
	Register_TElCustomCryptoProviderOptions(TSRMLS_C);
	Register_TElBlackboxCryptoProvider(TSRMLS_C);
	Register_TElExternalCryptoProvider(TSRMLS_C);
	Register_SBCryptoProv_Enum_Flags(TSRMLS_C);
	Register_SBCryptoProv_Aliases(TSRMLS_C);

	// SBCryptoProvBuiltIn unit class registration
	Register_TElBuiltInCryptoProviderOptions(TSRMLS_C);
	Register_TElBuiltInCryptoKey(TSRMLS_C);
	Register_TElBuiltInCryptoObject(TSRMLS_C);
	Register_TElBuiltInCryptoKeyContainerFileEncapsulatedElement(TSRMLS_C);
	Register_TElBuiltInCryptoKeyContainerFile(TSRMLS_C);
	Register_TElBuiltInCryptoKeyContainerFileProtectedData(TSRMLS_C);
	Register_TElBuiltInCryptoKeyContainerFileProtectionS2KParams(TSRMLS_C);
	Register_TElBuiltInCryptoKeyContainerFileProtectionInfo(TSRMLS_C);
	Register_TElBuiltInCryptoKeyContainerFileEncapsulatedKey(TSRMLS_C);
	Register_TElBuiltInCryptoKeyContainerFileEncapsulatedObject(TSRMLS_C);
	Register_TElBuiltInCryptoKeyContainerFileEncapsulatedAttribute(TSRMLS_C);
	Register_TElBuiltInCryptoKeyContainerFileElementInfo(TSRMLS_C);
	Register_TElBuiltInCryptoKeyContainerFileKeyInfo(TSRMLS_C);
	Register_TElBuiltInCryptoKeyContainerFileObjectInfo(TSRMLS_C);
	Register_TElBuiltInCryptoKeyContainerFileAttributeInfo(TSRMLS_C);
	Register_TElBuiltInCryptoKeyContainerObjectContext(TSRMLS_C);
	Register_TElBuiltInCryptoKeyContainer(TSRMLS_C);
	Register_TElBuiltInProtectedObjectInfo(TSRMLS_C);
	Register_TElBuiltInCryptoProvider(TSRMLS_C);

	// SBCryptoProvBuiltInHash unit class registration
	Register_TElBuiltInHashFunction(TSRMLS_C);
	Register_TElBuiltInMACKey(TSRMLS_C);

	// SBCryptoProvBuiltInPKI unit class registration
	Register_TElBuiltInRSACryptoKey(TSRMLS_C);
	Register_TElBuiltInDSACryptoKey(TSRMLS_C);
	Register_TElBuiltInElgamalCryptoKey(TSRMLS_C);
	Register_TElBuiltInDHCryptoKey(TSRMLS_C);
	Register_TElBuiltInECCryptoKey(TSRMLS_C);
	Register_TElBuiltInEdDSACryptoKey(TSRMLS_C);
	Register_TElBuiltInGOST341094CryptoKey(TSRMLS_C);
	Register_TElBuiltInGOST34102001CryptoKey(TSRMLS_C);
	Register_TElBuiltInPublicKeyCrypto(TSRMLS_C);
	Register_TElBuiltInRSAPublicKeyCrypto(TSRMLS_C);
	Register_TElBuiltInDSAPublicKeyCrypto(TSRMLS_C);
	Register_TElBuiltInElgamalPublicKeyCrypto(TSRMLS_C);
	Register_TElBuiltInDHPublicKeyCrypto(TSRMLS_C);
	Register_TElBuiltInECDSAPublicKeyCrypto(TSRMLS_C);
	Register_TElBuiltInECDHPublicKeyCrypto(TSRMLS_C);
	Register_TElBuiltInEdDSAPublicKeyCrypto(TSRMLS_C);
	Register_TElBuiltInGOST94PublicKeyCrypto(TSRMLS_C);
	Register_TElBuiltInGOST2001PublicKeyCrypto(TSRMLS_C);
	Register_SBCryptoProvBuiltInPKI_Enum_Flags(TSRMLS_C);
	Register_SBCryptoProvBuiltInPKI_Aliases(TSRMLS_C);

	// SBCryptoProvBuiltInSym unit class registration
	Register_TSBGCMContext(TSRMLS_C);
	Register_TElBuiltInSymmetricCryptoKey(TSRMLS_C);
	Register_TElBuiltInSymmetricCrypto(TSRMLS_C);
	Register_TElBuiltInSymmetricCryptoFactory(TSRMLS_C);
	Register_TElBuiltInIdentitySymmetricCrypto(TSRMLS_C);
	Register_TElBuiltInRC4SymmetricCrypto(TSRMLS_C);
	Register_TElBuiltInGOST28147SymmetricCrypto(TSRMLS_C);
	Register_TElBuiltInChaCha20SymmetricCrypto(TSRMLS_C);
	Register_TElBuiltInAEADChaCha20Poly1305SymmetricCrypto(TSRMLS_C);
	Register_SBCryptoProvBuiltInSym_Enum_Flags(TSRMLS_C);
	Register_SBCryptoProvBuiltInSym_Aliases(TSRMLS_C);

#ifdef SB_WINDOWS
	// SBCryptoProvWin32 unit class registration
	Register_TElWin32CryptoProviderOptions(TSRMLS_C);
	Register_TElWin32CryptoProvider(TSRMLS_C);
	Register_TElCNGCryptoProviderHandleInfo(TSRMLS_C);
	Register_TElCNGCryptoProviderHandleManager(TSRMLS_C);
#endif

	// SBCryptoProvManager unit class registration
	Register_TElBuiltInCryptoProviderManager(TSRMLS_C);
	Register_TElFIPSCompliantCryptoProviderManager(TSRMLS_C);
	Register_SBCryptoProvManager_Enum_Flags(TSRMLS_C);

	// SBX509 unit class registration
	Register_TValidity(TSRMLS_C);
	Register_TName(TSRMLS_C);
	Register_TPVKHeader(TSRMLS_C);
	Register_TElX509Certificate(TSRMLS_C);
	Register_TElSubjectPublicKeyInfo(TSRMLS_C);
	Register_TElTBSCertificate(TSRMLS_C);
	Register_TElX509CertificateChain(TSRMLS_C);
	Register_TElBaseCertStorage(TSRMLS_C);
	Register_SBX509_Enum_Flags(TSRMLS_C);
	Register_SBX509_Aliases(TSRMLS_C);

	// SBX509Ext unit class registration
	Register_TElEDIPartyName(TSRMLS_C);
	Register_TElOtherName(TSRMLS_C);
	Register_TElPermanentIdentifier(TSRMLS_C);
	Register_TElGeneralName(TSRMLS_C);
	Register_TElGeneralNames(TSRMLS_C);
	Register_TElCustomExtension(TSRMLS_C);
	Register_TElAuthorityKeyIdentifierExtension(TSRMLS_C);
	Register_TElSubjectKeyIdentifierExtension(TSRMLS_C);
	Register_TElKeyUsageExtension(TSRMLS_C);
	Register_TElPrivateKeyUsagePeriodExtension(TSRMLS_C);
	Register_TElNetscapeCertTypeExtension(TSRMLS_C);
	Register_TElNetscapeString(TSRMLS_C);
	Register_TElOCSPNoCheckExtension(TSRMLS_C);
	Register_TElNetscapeBaseURL(TSRMLS_C);
	Register_TElNetscapeRevokeURL(TSRMLS_C);
	Register_TElNetscapeCARevokeURL(TSRMLS_C);
	Register_TElNetscapeRenewalURL(TSRMLS_C);
	Register_TElNetscapeCAPolicy(TSRMLS_C);
	Register_TElNetscapeServerName(TSRMLS_C);
	Register_TElNetscapeComment(TSRMLS_C);
	Register_TElCommonName(TSRMLS_C);
	Register_TElUserNotice(TSRMLS_C);
	Register_TElSinglePolicyQualifier(TSRMLS_C);
	Register_TElSinglePolicyInformation(TSRMLS_C);
	Register_TElCertificatePoliciesExtension(TSRMLS_C);
	Register_TElPolicyMapping(TSRMLS_C);
	Register_TElPolicyMappingsExtension(TSRMLS_C);
	Register_TElAlternativeNameExtension(TSRMLS_C);
	Register_TElBasicConstraintsExtension(TSRMLS_C);
	Register_TElNameConstraint(TSRMLS_C);
	Register_TElNameConstraintsExtension(TSRMLS_C);
	Register_TElPolicyConstraintsExtension(TSRMLS_C);
	Register_TElExtendedKeyUsageExtension(TSRMLS_C);
	Register_TElDistributionPoint(TSRMLS_C);
	Register_TElCRLDistributionPointsExtension(TSRMLS_C);
	Register_TElAccessDescription(TSRMLS_C);
	Register_TElAuthorityInformationAccessExtension(TSRMLS_C);
	Register_TElSubjectDirectoryAttributesExtension(TSRMLS_C);
	Register_TElCertificateExtensions(TSRMLS_C);
	Register_TElExtensionWriter(TSRMLS_C);
	Register_TElExtensionReader(TSRMLS_C);
	Register_SBX509Ext_Enum_Flags(TSRMLS_C);
	Register_SBX509Ext_Aliases(TSRMLS_C);

	// SBCRL unit class registration
	Register_TElAuthorityKeyIdentifierCRLExtension(TSRMLS_C);
	Register_TElCRLNumberCRLExtension(TSRMLS_C);
	Register_TElDeltaCRLIndicatorCRLExtension(TSRMLS_C);
	Register_TElReasonCodeCRLExtension(TSRMLS_C);
	Register_TElHoldInstructionCodeCRLExtension(TSRMLS_C);
	Register_TElInvalidityDateCRLExtension(TSRMLS_C);
	Register_TElCertificateIssuerCRLExtension(TSRMLS_C);
	Register_TElIssuingDistributionPointCRLExtension(TSRMLS_C);
	Register_TElCRLExtensions(TSRMLS_C);
	Register_TElCRLEntryExtensions(TSRMLS_C);
	Register_TElAbstractCRL(TSRMLS_C);
	Register_TElRevocationItem(TSRMLS_C);
	Register_TElCertificateRevocationList(TSRMLS_C);
	Register_TElRawCRL(TSRMLS_C);
	Register_TElRevocationItemInfo(TSRMLS_C);
	Register_TElCRLObjectFactory(TSRMLS_C);
	Register_SBCRL_Enum_Flags(TSRMLS_C);
	Register_SBCRL_Aliases(TSRMLS_C);

	// SBCRLStorage unit class registration
	Register_TElCustomCRLStorage(TSRMLS_C);
	Register_TElCRLLookup(TSRMLS_C);
	Register_TElMemoryCRLStorage(TSRMLS_C);
	Register_TElCRLCacheStorage(TSRMLS_C);
	Register_TElCustomCRLRetriever(TSRMLS_C);
	Register_TElCustomCRLRetrieverFactory(TSRMLS_C);
	Register_TElCRLManager(TSRMLS_C);
	Register_SBCRLStorage_Enum_Flags(TSRMLS_C);
	Register_SBCRLStorage_Aliases(TSRMLS_C);

	// SBCertRetriever unit class registration
	Register_TElCustomCertificateRetriever(TSRMLS_C);
	Register_TElFileCertificateRetriever(TSRMLS_C);
	Register_TElCustomCertificateRetrieverFactory(TSRMLS_C);
	Register_TElCertificateRetrieverManager(TSRMLS_C);
	Register_SBCertRetriever_Aliases(TSRMLS_C);

	// SBCertValidator unit class registration
	Register_TElX509CertificateValidator(TSRMLS_C);
	Register_TElX509CertificateValidatorLogger(TSRMLS_C);
	Register_TElX509CertificateValidationResult(TSRMLS_C);
	Register_TElX509CachedCertificate(TSRMLS_C);
	Register_TElCacheCertStorage(TSRMLS_C);
	Register_TElX509ChainEntryValidationResult(TSRMLS_C);
	Register_TElX509ChainEntryValidationResultList(TSRMLS_C);
	Register_TElX509CACertificateListEntry(TSRMLS_C);
	Register_TElX509CACertificateList(TSRMLS_C);
	Register_SBCertValidator_Enum_Flags(TSRMLS_C);

	// SBRDN unit class registration
	Register_TElRelativeDistinguishedName(TSRMLS_C);
	Register_TElRDNConverter(TSRMLS_C);
	Register_SBRDN_Aliases(TSRMLS_C);

	// SBCustomCertStorage unit class registration
	Register_TElCustomCertStorage(TSRMLS_C);
	Register_TElCertificateLookup(TSRMLS_C);
	Register_TElMemoryCertStorage(TSRMLS_C);
	Register_TElFileCertStorage(TSRMLS_C);
	Register_SBCustomCertStorage_Enum_Flags(TSRMLS_C);
	Register_SBCustomCertStorage_Aliases(TSRMLS_C);

	// SBMessages unit class registration
	Register_TElMessageProcessor(TSRMLS_C);
	Register_TElMessageEncryptor(TSRMLS_C);
	Register_TElMessageDecryptor(TSRMLS_C);
	Register_TElMessageVerifier(TSRMLS_C);
	Register_TElMessageSigner(TSRMLS_C);
	Register_TElMessageDecompressor(TSRMLS_C);
	Register_TElMessageCompressor(TSRMLS_C);
	Register_TElMessageTimestamper(TSRMLS_C);
	Register_TElMessageTimestampVerifier(TSRMLS_C);
	Register_SBMessages_Enum_Flags(TSRMLS_C);
	Register_SBMessages_Aliases(TSRMLS_C);

	// SBPKCS5 unit class registration
	Register_TElPKCS5PBE(TSRMLS_C);
	Register_SBPKCS5_Enum_Flags(TSRMLS_C);

	// SBPKCS7 unit class registration
	Register_TElPKCS7Recipient(TSRMLS_C);
	Register_TElPKCS7ContentPart(TSRMLS_C);
	Register_TElPKCS7EncryptedContent(TSRMLS_C);
	Register_TElPKCS7Message(TSRMLS_C);
	Register_TElPKCS7EnvelopedData(TSRMLS_C);
	Register_TElPKCS7CompressedData(TSRMLS_C);
	Register_TElPKCS7Signer(TSRMLS_C);
	Register_TElPKCS7SignedData(TSRMLS_C);
	Register_TElPKCS7DigestedData(TSRMLS_C);
	Register_TElPKCS7EncryptedData(TSRMLS_C);
	Register_TElPKCS7SignedAndEnvelopedData(TSRMLS_C);
	Register_TElPKCS7AuthenticatedData(TSRMLS_C);
	Register_TElPKCS7TimestampAndCRL(TSRMLS_C);
	Register_TElPKCS7TimestampedData(TSRMLS_C);
	Register_TElPKCS7AuthEnvelopedData(TSRMLS_C);
	Register_SBPKCS7_Enum_Flags(TSRMLS_C);
	Register_SBPKCS7_Aliases(TSRMLS_C);

	// SBPKCS7Utils unit class registration
	Register_TElPKCS7Attributes(TSRMLS_C);
	Register_TElPKCS7Issuer(TSRMLS_C);
	Register_SBPKCS7Utils_Enum_Flags(TSRMLS_C);

	// SBPKCS8 unit class registration
	Register_TElPKCS8EncryptedPrivateKeyInfo(TSRMLS_C);
	Register_TElPKCS8PrivateKeyInfo(TSRMLS_C);
	Register_TElPKCS8PrivateKey(TSRMLS_C);

	// SBPKCS12 unit class registration
	Register_TElPKCS12Message(TSRMLS_C);
	Register_SBPKCS12_Aliases(TSRMLS_C);

	// SBJKS unit class registration
	Register_TJKSEntry(TSRMLS_C);
	Register_TElJKS(TSRMLS_C);
	Register_SBJKS_Aliases(TSRMLS_C);

#ifdef SB_WINDOWS
	// SBWinCertStorage unit class registration
	Register_TElWinCertStorage(TSRMLS_C);
	Register_SBWinCertStorage_Enum_Flags(TSRMLS_C);
	Register_SBWinCertStorage_Aliases(TSRMLS_C);

	// SBWinCrypt unit class registration
	Register_CRYPTOAPI_BLOB(TSRMLS_C);
	Register_CRYPT_BIT_BLOB(TSRMLS_C);
	Register_CRYPT_ALGORITHM_IDENTIFIER(TSRMLS_C);
	Register_CERT_PUBLIC_KEY_INFO(TSRMLS_C);
	Register_CERT_EXTENSION(TSRMLS_C);
	Register_CERT_INFO(TSRMLS_C);
	Register_CERT_CONTEXT(TSRMLS_C);
	Register_CRYPTUI_VIEWCERTIFICATE_STRUCT(TSRMLS_C);
	Register_CRYPTUI_SELECTCERTIFICATE_STRUCT(TSRMLS_C);
	Register__CERT_SYSTEM_STORE_INFO(TSRMLS_C);
	Register__CRYPT_KEY_PROV_INFO(TSRMLS_C);
	Register__CRYPT_ATTRIBUTE(TSRMLS_C);
	Register__CRYPT_SIGN_MESSAGE_PARA(TSRMLS_C);
	Register__CRYPT_DECRYPT_MESSAGE_PARA(TSRMLS_C);
	Register__PROV_ENUMALGS(TSRMLS_C);
	Register__CRYPT_OID_FUNC_ENTRY(TSRMLS_C);
	Register__CERT_STORE_PROV_INFO(TSRMLS_C);
	Register_CTL_USAGE(TSRMLS_C);
	Register_CTL_ENTRY(TSRMLS_C);
	Register_CRL_ENTRY(TSRMLS_C);
	Register_CTL_INFO(TSRMLS_C);
	Register_CRL_INFO(TSRMLS_C);
	Register_CRL_CONTEXT(TSRMLS_C);
	Register_CTL_CONTEXT(TSRMLS_C);
	Register_CERT_STORE_PROV_FIND_INFO(TSRMLS_C);
	Register_SBWinCrypt__GUID(TSRMLS_C);
	Register_HMAC_INFO(TSRMLS_C);
	Register_NCryptBuffer(TSRMLS_C);
	Register_NCryptBufferDesc(TSRMLS_C);
	Register_NCryptAlgorithmName(TSRMLS_C);
	Register_NCryptKeyName(TSRMLS_C);
	Register_NCryptProviderName(TSRMLS_C);
	Register_BCRYPT_PKCS1_PADDING_INFO(TSRMLS_C);
	Register_SBWinCrypt_Aliases(TSRMLS_C);
#endif

	// SBSMIMESignatures unit class registration
	Register_TElSMIMEMessageSigner(TSRMLS_C);
	Register_TElSMIMEMessageVerifier(TSRMLS_C);
	Register_SBSMIMESignatures_Aliases(TSRMLS_C);

	// SBOCSPCommon unit class registration
	Register_TElOCSPClass(TSRMLS_C);
	Register_SBOCSPCommon_Enum_Flags(TSRMLS_C);
	Register_SBOCSPCommon_Aliases(TSRMLS_C);

	// SBOCSPClient unit class registration
	Register_TElOCSPClient(TSRMLS_C);
	Register_TElOCSPResponderID(TSRMLS_C);
	Register_TElOCSPSingleResponse(TSRMLS_C);
	Register_TElOCSPResponse(TSRMLS_C);
	Register_TElFileOCSPClient(TSRMLS_C);
	Register_TElCustomOCSPClientFactory(TSRMLS_C);
	Register_TElOCSPClientManager(TSRMLS_C);
	Register_SBOCSPClient_Enum_Flags(TSRMLS_C);
	Register_SBOCSPClient_Aliases(TSRMLS_C);

	// SBOCSPStorage unit class registration
	Register_TElOCSPResponseStorage(TSRMLS_C);

	// SBPublicKeyCrypto unit class registration
	Register_TElPublicKeyMaterial(TSRMLS_C);
	Register_TElPublicKeyCrypto(TSRMLS_C);
	Register_TElRSAKeyMaterial(TSRMLS_C);
	Register_TElRSAPublicKeyCrypto(TSRMLS_C);
	Register_TElDSAKeyMaterial(TSRMLS_C);
	Register_TElDSAPublicKeyCrypto(TSRMLS_C);
	Register_TElECKeyMaterial(TSRMLS_C);
	Register_TElECDSAPublicKeyCrypto(TSRMLS_C);
	Register_TElECDHPublicKeyCrypto(TSRMLS_C);
	Register_TElEdDSAKeyMaterial(TSRMLS_C);
	Register_TElEdDSAPublicKeyCrypto(TSRMLS_C);
	Register_TElDHKeyMaterial(TSRMLS_C);
	Register_TElDHPublicKeyCrypto(TSRMLS_C);
	Register_TElElGamalKeyMaterial(TSRMLS_C);
	Register_TElElGamalPublicKeyCrypto(TSRMLS_C);
	Register_TElSRPKeyMaterial(TSRMLS_C);
	Register_TElSRPPublicKeyCrypto(TSRMLS_C);
	Register_TElGOST94KeyMaterial(TSRMLS_C);
	Register_TElGOST94PublicKeyCrypto(TSRMLS_C);
	Register_TElGOST2001KeyMaterial(TSRMLS_C);
	Register_TElGOST2001PublicKeyCrypto(TSRMLS_C);
	Register_TElPublicKeyCryptoFactory(TSRMLS_C);
	Register_TElRemoteSigningParams(TSRMLS_C);
	Register_SBPublicKeyCrypto_Enum_Flags(TSRMLS_C);
	Register_SBPublicKeyCrypto_Aliases(TSRMLS_C);

	// SBSRP unit class registration
	Register_TElSRPCredential(TSRMLS_C);
	Register_TElSRPCredentialStore(TSRMLS_C);
	Register_SBSRP_Enum_Flags(TSRMLS_C);

	// SBSymmetricCrypto unit class registration
	Register_TElSymmetricKeyMaterial(TSRMLS_C);
	Register_TElSymmetricCrypto(TSRMLS_C);
	Register_TElSymmetricCryptoFactory(TSRMLS_C);
	Register_TElAESSymmetricCrypto(TSRMLS_C);
	Register_TElBlowfishSymmetricCrypto(TSRMLS_C);
	Register_TElTwofishSymmetricCrypto(TSRMLS_C);
	Register_TElIDEASymmetricCrypto(TSRMLS_C);
	Register_TElCAST128SymmetricCrypto(TSRMLS_C);
	Register_TElRC2SymmetricCrypto(TSRMLS_C);
	Register_TElRC4SymmetricCrypto(TSRMLS_C);
	Register_TElDESSymmetricCrypto(TSRMLS_C);
	Register_TEl3DESSymmetricCrypto(TSRMLS_C);
	Register_TElCamelliaSymmetricCrypto(TSRMLS_C);
	Register_TElSerpentSymmetricCrypto(TSRMLS_C);
	Register_TElSEEDSymmetricCrypto(TSRMLS_C);
	Register_TElRabbitSymmetricCrypto(TSRMLS_C);
	Register_TElGOST28147SymmetricCrypto(TSRMLS_C);
	Register_TElIdentitySymmetricCrypto(TSRMLS_C);
	Register_TElChaCha20SymmetricCrypto(TSRMLS_C);
	Register_TElAEADChaCha20Poly1305SymmetricCrypto(TSRMLS_C);
	Register_SBSymmetricCrypto_Enum_Flags(TSRMLS_C);
	Register_SBSymmetricCrypto_Aliases(TSRMLS_C);

	// SBPKIAsync unit class registration
	Register_TElPublicKeyAsyncCalculator(TSRMLS_C);
	Register_TElPublicKeyComputationToken(TSRMLS_C);
	Register_SBPKIAsync_Enum_Flags(TSRMLS_C);

	// SBPKICommon unit class registration
	Register_SBPKICommon_Enum_Flags(TSRMLS_C);

	// SBTSPCommon unit class registration
	Register_TElTSPInfo(TSRMLS_C);
	Register_TElTSPClass(TSRMLS_C);
	Register_SBTSPCommon_Aliases(TSRMLS_C);

	// SBTSPClient unit class registration
	Register_TElClientTSPInfo(TSRMLS_C);
	Register_TElCustomTSPClient(TSRMLS_C);
	Register_TElFileTSPClient(TSRMLS_C);
	Register_SBTSPClient_Enum_Flags(TSRMLS_C);
	Register_SBTSPClient_Aliases(TSRMLS_C);

	// SBSocketTSPClient unit class registration
	Register_TElSocketTSPClient(TSRMLS_C);

	// SBECCommon unit class registration
	Register_TElECDomainParameters(TSRMLS_C);

	// SBGSSAPI unit class registration
	Register_gss_OID_desc(TSRMLS_C);
	Register_gss_OID_set_desc(TSRMLS_C);
	Register_gss_buffer_desc(TSRMLS_C);
	Register_gss_channel_bindings_desc_t(TSRMLS_C);
	Register_TElGSSCustomContext(TSRMLS_C);
	Register_TElGSSCustomName(TSRMLS_C);
	Register_TElGSSBaseMechanism(TSRMLS_C);
	Register_TElGSSAPIContext(TSRMLS_C);
	Register_TElGSSAPIName(TSRMLS_C);
	Register_TElGSSAPIMechanism(TSRMLS_C);
	Register_TElGSSMechanismCollection(TSRMLS_C);

#ifdef SB_WINDOWS
	// SBGSSWinAuth unit class registration
	Register_TElGSSWinContext(TSRMLS_C);
	Register_TElGSSWinName(TSRMLS_C);
	Register_TElGSSWinAuthMechanism(TSRMLS_C);
	Register_SBGSSWinAuth_Enum_Flags(TSRMLS_C);
#endif

	// SBDNSSEC unit class registration
	Register_TElDNSQuestion(TSRMLS_C);
	Register_TElDNSQuestionList(TSRMLS_C);
	Register_TElDNSCache(TSRMLS_C);
	Register_TElDNSMessageExtensions(TSRMLS_C);
	Register_TElDNSMessage(TSRMLS_C);
	Register_TElDNSClient(TSRMLS_C);
	Register_TElDNSResolver(TSRMLS_C);

	// SBDNSSECTypes unit class registration
	Register_TElDNSResourceRecord(TSRMLS_C);
	Register_TElDNSIPv4AddressRecord(TSRMLS_C);
	Register_TElDNSNameServerRecord(TSRMLS_C);
	Register_TElDNSCanonicalNameRecord(TSRMLS_C);
	Register_TElDNSStartOfAuthorityRecord(TSRMLS_C);
	Register_TElDNSWellKnownServiceRecord(TSRMLS_C);
	Register_TElDNSDomainNamePointerRecord(TSRMLS_C);
	Register_TElDNSHostInfoRecord(TSRMLS_C);
	Register_TElDNSMailInfoRecord(TSRMLS_C);
	Register_TElDNSMailExchangeRecord(TSRMLS_C);
	Register_TElDNSTextStringsRecord(TSRMLS_C);
	Register_TElDNSIPv6AddressRecord(TSRMLS_C);
	Register_TElDNSServiceLocationRecord(TSRMLS_C);
	Register_TElDNSExtensionsRecord(TSRMLS_C);
	Register_TElDNSPublicKeyRecord(TSRMLS_C);
	Register_TElDNSDelegationSignerRecord(TSRMLS_C);
	Register_TElDNSSignatureRecord(TSRMLS_C);
	Register_TElDNSNextSecureRecord(TSRMLS_C);
	Register_TElDNSNextSecure3Record(TSRMLS_C);
	Register_TElDNSNextSecure3ParamRecord(TSRMLS_C);
	Register_TElDNSResourceRecordSet(TSRMLS_C);
	Register_SBDNSSECTypes_Enum_Flags(TSRMLS_C);

	// SBCustomFSAdapter unit class registration
	Register_TElVFSEntryInformation(TSRMLS_C);
	Register_TElVFSEntryInformationList(TSRMLS_C);
	Register_TElCustomFileSystemAdapter(TSRMLS_C);
	Register_SBCustomFSAdapter_Enum_Flags(TSRMLS_C);
	Register_SBCustomFSAdapter_Aliases(TSRMLS_C);

	// SBDiskFSAdapter unit class registration
	Register_TElDiskFileSystemAdapter(TSRMLS_C);

	// SBHTTPAuth unit class registration
#ifdef SB_WINDOWS
	Register_CredHandle(TSRMLS_C);
	Register_SecBuffer(TSRMLS_C);
	Register_SecBufferDesc(TSRMLS_C);
	Register_SecPkgInfo(TSRMLS_C);
	Register_SBHTTPAuth_SEC_WINNT_AUTH_IDENTITY(TSRMLS_C);
#endif
	Register_AUTH_SEQ(TSRMLS_C);
#ifdef SB_WINDOWS
	Register_secFuncs(TSRMLS_C);
#endif
	Register_SBHTTPAuth_Enum_Flags(TSRMLS_C);
#ifdef SB_WINDOWS
	Register_SBHTTPAuth_Aliases(TSRMLS_C);
#endif

	// SBHTTPSConstants unit class registration
	Register_SBHTTPSConstants_Enum_Flags(TSRMLS_C);

	// SBSASL unit class registration
	Register_TElSASLClient(TSRMLS_C);
	Register_TElSASLPlainClient(TSRMLS_C);
	Register_TElSASLLoginClient(TSRMLS_C);
	Register_TElSASLCRAMMD5Client(TSRMLS_C);
	Register_TElSASLAnonymousClient(TSRMLS_C);
	Register_TElSASLExternalClient(TSRMLS_C);
	Register_TElSASLDigestMD5Client(TSRMLS_C);
#ifdef SB_WINDOWS
	Register_TElSASLNTLMClient(TSRMLS_C);
#endif
	Register_TElSASLXOAuth2Client(TSRMLS_C);
	Register_SBSASL_Enum_Flags(TSRMLS_C);

	// SBComprStream unit class registration
	Register_TElCustomCompressingStream(TSRMLS_C);
	Register_TElCustomDecompressingStream(TSRMLS_C);
	Register_TElZlibCompressingStream(TSRMLS_C);
	Register_TElZlibDecompressingStream(TSRMLS_C);

	// SBDC unit class registration
	Register_TElDCBaseMessage(TSRMLS_C);
	Register_TElDCUnsupportedMessage(TSRMLS_C);
	Register_TElDCMessageMDCMessage(TSRMLS_C);
	Register_TElDCErrorMessage(TSRMLS_C);
	Register_TElDCOperationRequestMessage(TSRMLS_C);
	Register_TElDCOperationResponseMessage(TSRMLS_C);
	Register_TElDCDataMessage(TSRMLS_C);
	Register_TElDCParametersMessage(TSRMLS_C);
	Register_TElDCSignatureMessage(TSRMLS_C);
	Register_TElDCBatchMessage(TSRMLS_C);
	Register_TElDCMessageFactory(TSRMLS_C);
	Register_TElDCAsyncState(TSRMLS_C);
	Register_TElDCAsyncStateCollection(TSRMLS_C);
	Register_SBDC_Enum_Flags(TSRMLS_C);
	Register_SBDC_Aliases(TSRMLS_C);

	// SBDCDef unit class registration
	Register_TElDCPKCS7SignParameters(TSRMLS_C);
	Register_TElDCDefaultRequestFactory(TSRMLS_C);
	Register_SBDCDef_Enum_Flags(TSRMLS_C);

	// SBDCEnc unit class registration
	Register_TElDCEncoding(TSRMLS_C);
	Register_TElDCNode(TSRMLS_C);

	// SBDCASN1Enc unit class registration
	Register_TElDCASN1Encoding(TSRMLS_C);

	// SBDCCanonEnc unit class registration
	Register_TElDCCanonEncoding(TSRMLS_C);

	// SBDCSec unit class registration
	Register_TElDCMDC(TSRMLS_C);
	Register_TElDCParameters(TSRMLS_C);
	Register_TElDCClientRequestSignatureHandler(TSRMLS_C);
	Register_TElDCClientPKCS1RequestSignatureHandler(TSRMLS_C);
	Register_TElDCSecurityParameters(TSRMLS_C);
	Register_SBDCSec_Enum_Flags(TSRMLS_C);

	// SBDCStateStorage unit class registration
	Register_TElCustomDCStateStorage(TSRMLS_C);
	Register_TElFileDCStateStorage(TSRMLS_C);

	// csARMSCII_8 unit class registration
	Register_TPlARMSCII_8(TSRMLS_C);

	// csAtariST unit class registration
	Register_TPlAtariST(TSRMLS_C);

	// csBigFive unit class registration
	Register_TPlBigFive(TSRMLS_C);

	// csCNS_11643_1 unit class registration
	Register_TPlCNS_11643_1(TSRMLS_C);

	// csCNS_11643_2 unit class registration
	Register_TPlCNS_11643_2(TSRMLS_C);

	// csCNS_11643_3 unit class registration
	Register_TPlCNS_11643_3(TSRMLS_C);

	// csCNS_11643_4 unit class registration
	Register_TPlCNS_11643_4(TSRMLS_C);

	// csCNS_11643_5 unit class registration
	Register_TPlCNS_11643_5(TSRMLS_C);

	// csCNS_11643_6 unit class registration
	Register_TPlCNS_11643_6(TSRMLS_C);

	// csCNS_11643_7 unit class registration
	Register_TPlCNS_11643_7(TSRMLS_C);

	// csCNS_11643_F unit class registration
	Register_TPlCNS_11643_F(TSRMLS_C);

	// csCP1006 unit class registration
	Register_TPlCP1006(TSRMLS_C);

	// csCP1131 unit class registration
	Register_TPlCP1131(TSRMLS_C);

	// csCP1133 unit class registration
	Register_TPlCP1133(TSRMLS_C);

	// csCP1250 unit class registration
	Register_TPlCP1250(TSRMLS_C);

	// csCP1251 unit class registration
	Register_TPlCP1251(TSRMLS_C);

	// csCP1252 unit class registration
	Register_TPlCP1252(TSRMLS_C);

	// csCP1253 unit class registration
	Register_TPlCP1253(TSRMLS_C);

	// csCP1254 unit class registration
	Register_TPlCP1254(TSRMLS_C);

	// csCP1255 unit class registration
	Register_TPlCP1255(TSRMLS_C);

	// csCP1256 unit class registration
	Register_TPlCP1256(TSRMLS_C);

	// csCP1257 unit class registration
	Register_TPlCP1257(TSRMLS_C);

	// csCP1258 unit class registration
	Register_TPlCP1258(TSRMLS_C);

	// csCP037 unit class registration
	Register_TPlCP037(TSRMLS_C);

	// csCP424 unit class registration
	Register_TPlCP424(TSRMLS_C);

	// csCP437 unit class registration
	Register_TPlCP437(TSRMLS_C);

	// csCP500 unit class registration
	Register_TPlCP500(TSRMLS_C);

	// csCP737 unit class registration
	Register_TPlCP737(TSRMLS_C);

	// csCP775 unit class registration
	Register_TPlCP775(TSRMLS_C);

	// csCP850 unit class registration
	Register_TPlCP850(TSRMLS_C);

	// csCP852 unit class registration
	Register_TPlCP852(TSRMLS_C);

	// csCP853 unit class registration
	Register_TPlCP853(TSRMLS_C);

	// csCP855 unit class registration
	Register_TPlCP855(TSRMLS_C);

	// csCP856 unit class registration
	Register_TPlCP856(TSRMLS_C);

	// csCP857 unit class registration
	Register_TPlCP857(TSRMLS_C);

	// csCP860 unit class registration
	Register_TPlCP860(TSRMLS_C);

	// csCP861 unit class registration
	Register_TPlCP861(TSRMLS_C);

	// csCP862 unit class registration
	Register_TPlCP862(TSRMLS_C);

	// csCP863 unit class registration
	Register_TPlCP863(TSRMLS_C);

	// csCP864 unit class registration
	Register_TPlCP864(TSRMLS_C);

	// csCP865 unit class registration
	Register_TPlCP865(TSRMLS_C);

	// csCP866 unit class registration
	Register_TPlCP866(TSRMLS_C);

	// csCP869 unit class registration
	Register_TPlCP869(TSRMLS_C);

	// csCP874 unit class registration
	Register_TPlCP874(TSRMLS_C);

	// csCP875 unit class registration
	Register_TPlCP875(TSRMLS_C);

	// csCP950Data unit class registration
	Register_TPlCP950Data(TSRMLS_C);

	// csGB_18030 unit class registration
	Register_TPlGB_18030Data(TSRMLS_C);

	// csGB_2312 unit class registration
	Register_TPlGB_2312(TSRMLS_C);

	// csGBK unit class registration
	Register_TPlGBKData(TSRMLS_C);

	// csGeorgianAcademy unit class registration
	Register_TPlGeorgianAcademy(TSRMLS_C);

	// csGeorgianPS unit class registration
	Register_TPlGeorgianPS(TSRMLS_C);

	// csGEOSTD8 unit class registration
	Register_TPlGEOSTD8(TSRMLS_C);

	// csHKSCS unit class registration
	Register_TPlHKSCSData(TSRMLS_C);

	// csHPRoman8 unit class registration
	Register_TPlHPRoman8(TSRMLS_C);

	// csISO_8859_10 unit class registration
	Register_TPlISO_8859_10(TSRMLS_C);

	// csISO_8859_11 unit class registration
	Register_TPlISO_8859_11(TSRMLS_C);

	// csISO_8859_13 unit class registration
	Register_TPlISO_8859_13(TSRMLS_C);

	// csISO_8859_14 unit class registration
	Register_TPlISO_8859_14(TSRMLS_C);

	// csISO_8859_15 unit class registration
	Register_TPlISO_8859_15(TSRMLS_C);

	// csISO_8859_16 unit class registration
	Register_TPlISO_8859_16(TSRMLS_C);

	// csISO_8859_2 unit class registration
	Register_TPlISO_8859_2(TSRMLS_C);

	// csISO_8859_3 unit class registration
	Register_TPlISO_8859_3(TSRMLS_C);

	// csISO_8859_4 unit class registration
	Register_TPlISO_8859_4(TSRMLS_C);

	// csISO_8859_5 unit class registration
	Register_TPlISO_8859_5(TSRMLS_C);

	// csISO_8859_6 unit class registration
	Register_TPlISO_8859_6(TSRMLS_C);

	// csISO_8859_7 unit class registration
	Register_TPlISO_8859_7(TSRMLS_C);

	// csISO_8859_8 unit class registration
	Register_TPlISO_8859_8(TSRMLS_C);

	// csISO_8859_8i unit class registration
	Register_TPlISO_8859_8i(TSRMLS_C);

	// csISO_8859_9 unit class registration
	Register_TPlISO_8859_9(TSRMLS_C);

	// csISO_IR_165 unit class registration
	Register_TPlISO_IR_165Data(TSRMLS_C);

	// csJIS_0201 unit class registration
	Register_TPlJIS_0201(TSRMLS_C);

	// csJIS_0208 unit class registration
	Register_TPlJIS_0208(TSRMLS_C);

	// csJIS_0212 unit class registration
	Register_TPlJIS_0212(TSRMLS_C);

	// csKOI8R unit class registration
	Register_TPlKOI8R(TSRMLS_C);

	// csKOI8RU unit class registration
	Register_TPlKOI8RU(TSRMLS_C);

	// csKOI8T unit class registration
	Register_TPlKOI8T(TSRMLS_C);

	// csKOI8U unit class registration
	Register_TPlKOI8U(TSRMLS_C);

	// csKS_X_1001 unit class registration
	Register_TPlKS_X_1001(TSRMLS_C);

	// csMacCeltic unit class registration
	Register_TPlMacCeltic(TSRMLS_C);

	// csMacCentralEuropean unit class registration
	Register_TPlMacCentralEuropean(TSRMLS_C);

	// csMacCroatian unit class registration
	Register_TPlMacCroatian(TSRMLS_C);

	// csMacCyrillic unit class registration
	Register_TPlMacCyrillic(TSRMLS_C);

	// csMacGaelic unit class registration
	Register_TPlMacGaelic(TSRMLS_C);

	// csMacGreek unit class registration
	Register_TPlMacGreek(TSRMLS_C);

	// csMacHebrew unit class registration
	Register_TPlMacHebrew(TSRMLS_C);

	// csMacIcelandic unit class registration
	Register_TPlMacIcelandic(TSRMLS_C);

	// csMacRoman unit class registration
	Register_TPlMacRoman(TSRMLS_C);

	// csMacRomanian unit class registration
	Register_TPlMacRomanian(TSRMLS_C);

	// csMacThai unit class registration
	Register_TPlMacThai(TSRMLS_C);

	// csMacTurkish unit class registration
	Register_TPlMacTurkish(TSRMLS_C);

	// csNextStep unit class registration
	Register_TPlNextStep(TSRMLS_C);

	// csShiftJIS unit class registration
	Register_TPlShiftJISData(TSRMLS_C);

	// csUHC unit class registration
	Register_TPlUHC(TSRMLS_C);

	// csVISCII unit class registration
	Register_TPlVISCII(TSRMLS_C);

	// SBChSCJK unit class registration
	Register_TPlCustomEUCCharset(TSRMLS_C);
	Register_TPlCustomISO_2022Charset(TSRMLS_C);
	Register_TPlShiftJISCode(TSRMLS_C);
	Register_TPlShiftJIS(TSRMLS_C);
	Register_TPlEUC_JP(TSRMLS_C);
	Register_TPlISO_2022_JP(TSRMLS_C);
	Register_TPlISO_2022_JP_1(TSRMLS_C);
	Register_TPlISO_2022_JP_2(TSRMLS_C);
	Register_TPlGBK(TSRMLS_C);
	Register_TPlHZ_GB_2312(TSRMLS_C);
	Register_TPlGB_18030Code(TSRMLS_C);
	Register_TPlGB_18030(TSRMLS_C);
	Register_TPlISO_2022_CN(TSRMLS_C);
	Register_TPlISO_2022_CN_EXT(TSRMLS_C);
	Register_TPlBigFiveHKSCS(TSRMLS_C);
	Register_TPlCP950(TSRMLS_C);
	Register_TPlCNS_11643(TSRMLS_C);
	Register_TPlEUC_TW(TSRMLS_C);
	Register_TPlCP949(TSRMLS_C);
	Register_TPlJohabHangul(TSRMLS_C);
	Register_TPlJohabNonHangul(TSRMLS_C);
	Register_TPlJohab(TSRMLS_C);
	Register_TPlEUC_KR(TSRMLS_C);
	Register_TPlISO_2022_KR(TSRMLS_C);

	// SBChSConv unit class registration
	Register_TPlConverter(TSRMLS_C);
	Register_TPlCustomUTF(TSRMLS_C);
	Register_TPlUTF32(TSRMLS_C);
	Register_TPlUTF32BE(TSRMLS_C);
	Register_TPlUTF16(TSRMLS_C);
	Register_TPlUTF16BE(TSRMLS_C);
	Register_TPlUTF8(TSRMLS_C);
	Register_TPlCustomUTF7(TSRMLS_C);
	Register_TPlUTF7(TSRMLS_C);
	Register_TPlUTF7_IMAP(TSRMLS_C);
	Register_TPlConvBuffer(TSRMLS_C);
	Register_TPlCustomStringStream(TSRMLS_C);
	Register_TPlAnsiStringStream(TSRMLS_C);
	Register_TPlWideStringStream(TSRMLS_C);
	Register_TPlByteArrayStream(TSRMLS_C);
	Register_TPlCustomStringStreamPool(TSRMLS_C);
	Register_TPlAnsiStringStreamPool(TSRMLS_C);
	Register_TPlWideStringStreamPool(TSRMLS_C);
	Register_SBChSConv_Enum_Flags(TSRMLS_C);

	// SBChSConvBase unit class registration
	Register_TPlHiBytes(TSRMLS_C);
	Register_TPlChars(TSRMLS_C);
	Register_TPlConversionPage(TSRMLS_C);
	Register_TPlConversionPages(TSRMLS_C);
	Register_TPlUCSToMultiByteItem(TSRMLS_C);
	Register_TPlConversionTable(TSRMLS_C);
	Register_TPlCharset(TSRMLS_C);
	Register_TPlTableCharset(TSRMLS_C);
	Register_TPlMixedCharset(TSRMLS_C);
	Register_TPlConvertingCharset(TSRMLS_C);
	Register_TPlASCII(TSRMLS_C);
	Register_TPlISO_8859_1(TSRMLS_C);
	Register_SBChSConvBase_Aliases(TSRMLS_C);

	// SBChSUnicode unit class registration
	Register_SBChSUnicode_Enum_Flags(TSRMLS_C);

	// SBUnicode unit class registration
	Register_TElUnicodeConverter(TSRMLS_C);

	// SBCryptoProvBuiltInEx unit class registration
	Register_TElBuiltInExtendedCryptoProvider(TSRMLS_C);
	Register_TElBuiltInExtendedSymmetricCryptoFactory(TSRMLS_C);
	Register_TElBuiltInIDEASymmetricCrypto(TSRMLS_C);

	// SBJSON unit class registration
	Register_TElJsonEntity(TSRMLS_C);
	Register_TElJsonArray(TSRMLS_C);
	Register_TElJsonObject(TSRMLS_C);
	Register_TElJsonValue(TSRMLS_C);
	Register_SBJSON_Enum_Flags(TSRMLS_C);

	// SBBCrypt unit class registration
	Register_TElBCrypt(TSRMLS_C);

	// SBDictionary unit class registration
	Register_TElDictionaryEntry(TSRMLS_C);
	Register_TElDictionary(TSRMLS_C);

	// SBDynStruct unit class registration
	Register_TElDynStruct(TSRMLS_C);

	// SBUsers unit class registration
	Register_TElUsers(TSRMLS_C);
	Register_TElCustomUser(TSRMLS_C);
	Register_SBUsers_Aliases(TSRMLS_C);

	// SBUniversalKeyStorage unit class registration
	Register_TElUniversalKeyStorage(TSRMLS_C);

	// SBUniversalCertStorage unit class registration
	Register_TElUniversalCertStorage(TSRMLS_C);

	// SBAttrCert unit class registration
	Register_TElACIssuerSerial(TSRMLS_C);
	Register_TElACObjectDigestInfo(TSRMLS_C);
	Register_TElACAttribute(TSRMLS_C);
	Register_TElACTargets(TSRMLS_C);
	Register_TElACExtension(TSRMLS_C);
	Register_TElACAuditIdentityExtension(TSRMLS_C);
	Register_TElACTargetInformationExtension(TSRMLS_C);
	Register_TElACAuthorityKeyIdentifierExtension(TSRMLS_C);
	Register_TElACAuthorityInformationAccessExtension(TSRMLS_C);
	Register_TElACCRLDistributionPointsExtension(TSRMLS_C);
	Register_TElNoRevocationExtension(TSRMLS_C);
	Register_TElACProxyInfo(TSRMLS_C);
	Register_TElACAttrSpec(TSRMLS_C);
	Register_TElACClearAttrs(TSRMLS_C);
	Register_TElACAAControls(TSRMLS_C);
	Register_TElACSecurityCategory(TSRMLS_C);
	Register_TElACClassList(TSRMLS_C);
	Register_TElACClearance(TSRMLS_C);
	Register_TElACRoleSyntax(TSRMLS_C);
	Register_TElACSvceAuthInfo(TSRMLS_C);
	Register_TElACIetfAttrSyntax(TSRMLS_C);
	Register_TElACTargetCert(TSRMLS_C);
	Register_TElACTarget(TSRMLS_C);
	Register_TElACSvceAuthInfoBasedAttribute(TSRMLS_C);
	Register_TElACAuthenticationInfoAttribute(TSRMLS_C);
	Register_TElACAccessIndentityAttribute(TSRMLS_C);
	Register_TElACIetfAttrSyntaxBasedAttribute(TSRMLS_C);
	Register_TElACChargingIdentityAttribute(TSRMLS_C);
	Register_TElACGroupAttribute(TSRMLS_C);
	Register_TElACRoleAttribute(TSRMLS_C);
	Register_TElACClearanceAttribute(TSRMLS_C);
	Register_TElACValidityPeriod(TSRMLS_C);
	Register_TElACIssuer(TSRMLS_C);
	Register_TElACHolder(TSRMLS_C);
	Register_TElAttributeCertificateInfo(TSRMLS_C);
	Register_TElAttributeCertificate(TSRMLS_C);
	Register_SBAttrCert_Enum_Flags(TSRMLS_C);

	// SBScrypt unit class registration
	Register_TSBSCryptArray(TSRMLS_C);

	// SBDataStorage unit class registration
	Register_TElDSCustomKeyProtectionHandler(TSRMLS_C);
	Register_TElCustomDataStorageEncodingHandler(TSRMLS_C);
	Register_TElDSEnvelopedDataKeyProtectionHandler(TSRMLS_C);
	Register_TElDSEncryptedDataKeyProtectionHandler(TSRMLS_C);
	Register_TElDSPlainKeyProtectionHandler(TSRMLS_C);
	Register_TElDSKeyProtectionHandlersFactory(TSRMLS_C);
	Register_TElCustomDataStorageSecurityHandler(TSRMLS_C);
	Register_TElDataStorageObjectList(TSRMLS_C);
	Register_TElCustomDataStorageObject(TSRMLS_C);
	Register_TElCustomDataStorage(TSRMLS_C);
	Register_TElDefaultDataStorageSecurityHandler(TSRMLS_C);
	Register_TElDataStorageSecurityHandlersFactory(TSRMLS_C);
	Register_TElDataStorageEncodingHandlersFactory(TSRMLS_C);
	Register_SBDataStorage_Enum_Flags(TSRMLS_C);
	Register_SBDataStorage_Aliases(TSRMLS_C);

	// SBAWSDataStorage unit class registration
	Register_TElAWSS3DataStorage(TSRMLS_C);
	Register_TElAWSS3DataStorageObject(TSRMLS_C);
	Register_TElAWSS3DataStorageListState(TSRMLS_C);
	Register_TElAWSS3AccessControlGrant(TSRMLS_C);
	Register_TElAWSS3AccessControlPolicy(TSRMLS_C);
	Register_TElAWSS3DataStorageBucket(TSRMLS_C);
	Register_TElAWSS3DataStorageBucketList(TSRMLS_C);
	Register_SBAWSDataStorage_Enum_Flags(TSRMLS_C);

	// SBFileDataStorage unit class registration
	Register_TElFileDataStorageObject(TSRMLS_C);
	Register_TElFileDataStorage(TSRMLS_C);
	Register_SBFileDataStorage_Enum_Flags(TSRMLS_C);

	// SBEncStream unit class registration
	Register_TElChunkedEncryptingStream(TSRMLS_C);
	Register_TElChunkedDecryptingStream(TSRMLS_C);

	// SBAuthDataStream unit class registration
	Register_TElAuthenticatedDataWriteStream(TSRMLS_C);
	Register_TElAuthenticatedDataReadStream(TSRMLS_C);
	Register_SBAuthDataStream_Enum_Flags(TSRMLS_C);

	// SBWinAzureDataStorage unit class registration
	Register_TElWinAzureDataStorage(TSRMLS_C);
	Register_TElWinAzureDataStorageListState(TSRMLS_C);
	Register_TElWinAzureSingleAccessPolicy(TSRMLS_C);
	Register_TElWinAzureAccessPolicy(TSRMLS_C);
	Register_TElWinAzureDataStorageObject(TSRMLS_C);
	Register_TElWinAzureDataStorageContainer(TSRMLS_C);
	Register_TElWinAzureDataStorageContainerList(TSRMLS_C);
	Register_SBWinAzureDataStorage_Enum_Flags(TSRMLS_C);

	// SBGoogleDriveDataStorage unit class registration
	Register_TElGoogleDriveDataStorage(TSRMLS_C);
	Register_TElGoogleDriveDataStorageObject(TSRMLS_C);
	Register_TElGoogleDriveFolder(TSRMLS_C);
	Register_TElGoogleDriveProperties(TSRMLS_C);
	Register_TElGoogleDriveComment(TSRMLS_C);
	Register_TElGoogleDriveReplies(TSRMLS_C);
	Register_TElGoogleDriveUser(TSRMLS_C);
	Register_TElGoogleDriveAccountInfo(TSRMLS_C);
	Register_TElGoogleDriveComments(TSRMLS_C);
	Register_TElGoogleDriveReply(TSRMLS_C);
	Register_TElGoogleDriveProperty(TSRMLS_C);
	Register_TElGoogleDrivePermission(TSRMLS_C);
	Register_TElGoogleDrivePermissions(TSRMLS_C);
	Register_TElGoogleDriveCustomFile(TSRMLS_C);
	Register_TElGoogleDriveFile(TSRMLS_C);
	Register_TElGoogleDocument(TSRMLS_C);
	Register_SBGoogleDriveDataStorage_Enum_Flags(TSRMLS_C);

	// SBOneDriveDataStorage unit class registration
	Register_TElOneDriveDataStorage(TSRMLS_C);
	Register_TElOneDriveDataStorageObject(TSRMLS_C);
	Register_TElOneDriveFolder(TSRMLS_C);
	Register_TElOneDriveDrive(TSRMLS_C);
	Register_TElOneDriveFile(TSRMLS_C);
	Register_SBOneDriveDataStorage_Enum_Flags(TSRMLS_C);

	// SBOneDriveDataStorageV1 unit class registration
	Register_TElOneDriveDataStorageV1(TSRMLS_C);
	Register_TElOneDriveDataStorageObjectV1(TSRMLS_C);
	Register_TElOneDriveFolderV1(TSRMLS_C);
	Register_TElOneDriveComments(TSRMLS_C);
	Register_TElOneDriveTags(TSRMLS_C);
	Register_TElOneDriveFileV1(TSRMLS_C);
	Register_TElOneDriveFriend(TSRMLS_C);
	Register_TElOneDriveComment(TSRMLS_C);
	Register_TElOneDriveTaggedObject(TSRMLS_C);
	Register_TElOneDriveTag(TSRMLS_C);
	Register_TElOneDriveNotebook(TSRMLS_C);
	Register_TElOneDriveAudio(TSRMLS_C);
	Register_TElOneDrivePhoto(TSRMLS_C);
	Register_TElOneDrivePhotoImage(TSRMLS_C);
	Register_TElOneDrivePhotoImages(TSRMLS_C);
	Register_TElOneDriveVideo(TSRMLS_C);
	Register_TElOneDriveAlbum(TSRMLS_C);
	Register_TElOneDriveUserInfo(TSRMLS_C);

	// SBDataStorageEncodings unit class registration
	Register_TElZlibDataStorageEncodingHandler(TSRMLS_C);

	// SBDataStorageUtils unit class registration
	Register_TElProxyStream(TSRMLS_C);
	Register_TElMetadataCache(TSRMLS_C);
	Register_TElProtectedObjectUploadStream(TSRMLS_C);
	Register_TElProtectedObjectReader(TSRMLS_C);
	Register_TElProtectedObjectDownloadStream(TSRMLS_C);
	Register_SBDataStorageUtils_Enum_Flags(TSRMLS_C);

	// SBDropboxDataStorage unit class registration
	Register_TElDropboxDataStorage(TSRMLS_C);
	Register_TElDropboxAccountInfo(TSRMLS_C);
	Register_TElDropboxTeamMemberInfo(TSRMLS_C);
	Register_TElDropboxSharedFilePermission(TSRMLS_C);
	Register_TElDropboxSharedFilePermissions(TSRMLS_C);
	Register_TElDropboxSharedFolderPermission(TSRMLS_C);
	Register_TElDropboxSharedFolderPermissions(TSRMLS_C);
	Register_TElDropboxUserPermission(TSRMLS_C);
	Register_TElDropboxUserPermissions(TSRMLS_C);
	Register_TElDropboxUserMembershipInfo(TSRMLS_C);
	Register_TElDropboxGroupMembershipInfo(TSRMLS_C);
	Register_TElDropboxInviteeMembershipInfo(TSRMLS_C);
	Register_TElDropboxDataStorageObject(TSRMLS_C);
	Register_TElDropboxDataStorageFileSystemObject(TSRMLS_C);
	Register_TElDropboxDataStorageSharedObject(TSRMLS_C);
	Register_TElDropboxDataStorageSharedFolder(TSRMLS_C);
	Register_TElDropboxDataStorageSharedLink(TSRMLS_C);
	Register_TElDropboxFileSharingInfo(TSRMLS_C);
	Register_TElDropboxFolderSharingInfo(TSRMLS_C);
	Register_TElDropboxMediaInfo(TSRMLS_C);
	Register_TElDropboxDataStorageFolder(TSRMLS_C);
	Register_TElDropboxDataStorageFile(TSRMLS_C);
	Register_TElDropboxDataStorageDeletedObject(TSRMLS_C);
	Register_TElDropboxDataStorageSharedFile(TSRMLS_C);
	Register_SBDropboxDataStorage_Enum_Flags(TSRMLS_C);

	// SBBoxDataStorage unit class registration
	Register_TElBoxDataStorage(TSRMLS_C);
	Register_TElBoxDataStorageObject(TSRMLS_C);
	Register_TElBoxFile(TSRMLS_C);
	Register_TElBoxFolder(TSRMLS_C);
	Register_TElBoxGroupInfo(TSRMLS_C);
	Register_TElBoxUserInfo(TSRMLS_C);
	Register_TElBoxEnterprise(TSRMLS_C);
	Register_TElBoxUserEmailAlias(TSRMLS_C);
	Register_TElBoxUserEmailAliases(TSRMLS_C);
	Register_TElBoxGroupMembership(TSRMLS_C);
	Register_TElBoxGroupMemberships(TSRMLS_C);
	Register_TElBoxUser(TSRMLS_C);
	Register_TElBoxUsers(TSRMLS_C);
	Register_TElBoxGroupMember(TSRMLS_C);
	Register_TElBoxGroupMembers(TSRMLS_C);
	Register_TElBoxGroup(TSRMLS_C);
	Register_TElBoxGroups(TSRMLS_C);
	Register_TElBoxSharedLink(TSRMLS_C);
	Register_TElBoxSharedLinkPermissions(TSRMLS_C);
	Register_TElBoxCollaboration(TSRMLS_C);
	Register_TElBoxCollaborations(TSRMLS_C);
	Register_TElBoxDataStorageObjectPermissions(TSRMLS_C);
	Register_TElBoxComment(TSRMLS_C);
	Register_TElBoxComments(TSRMLS_C);
	Register_SBBoxDataStorage_Enum_Flags(TSRMLS_C);

	// SBHTTPSWebDAVClient unit class registration
	Register_TElHTTPSWebDAVClient(TSRMLS_C);
	Register_SBHTTPSWebDAVClient_Aliases(TSRMLS_C);

	// SBWebDAVClient unit class registration
	Register_TElWebDAVClient(TSRMLS_C);
	Register_TElWebDAVLockList(TSRMLS_C);
	Register_TElWebDAVMultistatusResponse(TSRMLS_C);
	Register_TElWebDAVError(TSRMLS_C);
	Register_TElWebDAVPrivilegeSet(TSRMLS_C);
	Register_TElWebDAVSupportedPrivilege(TSRMLS_C);
	Register_TElWebDAVSupportedPrivilegeSet(TSRMLS_C);
	Register_TElWebDAVPrincipalSearchPropertySetResponse(TSRMLS_C);
	Register_TElWebDAVStorageObject(TSRMLS_C);
	Register_TElWebDAVErrorResponse(TSRMLS_C);
	Register_TElWebDAVObjectList(TSRMLS_C);
	Register_TElWebDAVErrorList(TSRMLS_C);
	Register_SBWebDAVClient_TElWebDAVPrincipal(TSRMLS_C);
	Register_TElWebDAVPrincipalList(TSRMLS_C);
	Register_TElCardDavSupportedAddressData(TSRMLS_C);
	Register_TElCardDavAddressBookInfo(TSRMLS_C);
	Register_TElCardDavReportContext(TSRMLS_C);
	Register_SBWebDAVClient_Enum_Flags(TSRMLS_C);
	Register_SBWebDAVClient_Aliases(TSRMLS_C);

	// SBWebDAVCommon unit class registration
	Register_TElWebDAVPropertyInfo(TSRMLS_C);
	Register_TElWebDAVPropertyInfoList(TSRMLS_C);
	Register_TElWebDAVNamespacePrefixMap(TSRMLS_C);
	Register_TElWebDAVLock(TSRMLS_C);
	Register_TElWebDAVFilter(TSRMLS_C);
	Register_TElWebDAVTextMatchFilter(TSRMLS_C);
	Register_TElCardDavTextMatchFilter(TSRMLS_C);
	Register_TElCardDavPropFilter(TSRMLS_C);
	Register_TElCardDavFilter(TSRMLS_C);
	Register_TElCardDavParamFilter(TSRMLS_C);
	Register_TElWebDAVACE(TSRMLS_C);
	Register_TElWebDAVACL(TSRMLS_C);
	Register_TElWebDAVACLRestrictions(TSRMLS_C);
	Register_SBWebDAVCommon_Enum_Flags(TSRMLS_C);
	Register_SBWebDAVCommon_Aliases(TSRMLS_C);

	// SBVCard unit class registration
	Register_TElDirInfoAttribute(TSRMLS_C);
	Register_TElDirInfoProperty(TSRMLS_C);
	Register_TElDirInfoPropertiesList(TSRMLS_C);
	Register_TElDirInfo(TSRMLS_C);
	Register_TElVCard(TSRMLS_C);
	Register_TElVCalendar(TSRMLS_C);

	// SBWebDAVServer unit class registration
	Register_TElWebDAVServer(TSRMLS_C);
	Register_TElWebDAVTimeRangeBase(TSRMLS_C);
	Register_SBWebDAVServer_TElWebDAVPrincipal(TSRMLS_C);
	Register_TElWebDAVInMemoryPrincipal(TSRMLS_C);
	Register_TElWebDAVPrincipalBackend(TSRMLS_C);
	Register_TElWebDAVPrincipalMemoryBackend(TSRMLS_C);
	Register_TElCalDavTextMatchFilter(TSRMLS_C);
	Register_TElCalDavParamFilter(TSRMLS_C);
	Register_TElWebDAVExpand(TSRMLS_C);
	Register_TElWebDAVTimeRange(TSRMLS_C);
	Register_TElCalDavPropFilter(TSRMLS_C);
	Register_TElCalDAVCompFilter(TSRMLS_C);
	Register_TElWebDAVExtendedRequest(TSRMLS_C);
	Register_TElWebDAVAddressBookRequest(TSRMLS_C);
	Register_TElWebDAVLimitRecurrenceSet(TSRMLS_C);
	Register_TElWebDAVLimitFreeBusySet(TSRMLS_C);
	Register_TElWebDAVComp(TSRMLS_C);
	Register_TElWebDAVCalendarRequest(TSRMLS_C);
	Register_TElWebDAVFreeBusyRequest(TSRMLS_C);
	Register_TElWebDAVProperty(TSRMLS_C);
	Register_TElWebDAVIfState(TSRMLS_C);
	Register_TElWebDAVIfResource(TSRMLS_C);
	Register_TElWebDAVIfHeader(TSRMLS_C);
	Register_TElWebDAVCustomLockList(TSRMLS_C);
	Register_TElWebDAVFindMemoryLockHandle(TSRMLS_C);
	Register_TElWebDAVMemoryLockList(TSRMLS_C);
	Register_TElWebDAVACLOptions(TSRMLS_C);
	Register_TElCardDAVOptions(TSRMLS_C);
	Register_TElCalDAVOptions(TSRMLS_C);
	Register_TElWebDAVCollation(TSRMLS_C);
	Register_TElWebDAVUnicodeCollation(TSRMLS_C);
	Register_TElWebDAVAsciiCollation(TSRMLS_C);
	Register_TElWebDAVOctetCollation(TSRMLS_C);
	Register_SBWebDAVServer_Enum_Flags(TSRMLS_C);
	Register_SBWebDAVServer_Aliases(TSRMLS_C);

	// SBDCXMLEnc unit class registration
	Register_TElDCXMLEncoding(TSRMLS_C);

	// SBDCPKI unit class registration
	Register_TElDCX509SignOperationHandler(TSRMLS_C);

	// SBDCPKCS7 unit class registration
	Register_TElDCPKCS7SignOperationHandler(TSRMLS_C);

	// SBDCServer unit class registration
	Register_TElDCStandardServer(TSRMLS_C);
	Register_TElDCOperationHandler(TSRMLS_C);
	Register_TElDCSignOperationHandler(TSRMLS_C);
	Register_TElDCSingleServerRequest(TSRMLS_C);
	Register_TElDCServerRequest(TSRMLS_C);
	Register_TElDCServerSecurityParameters(TSRMLS_C);
	Register_TElDCServerRequestSignatureHandler(TSRMLS_C);
	Register_TElDCServerPKCS1RequestSignatureHandler(TSRMLS_C);

	// SBDCAuth unit class registration
	Register_TElDCAuthToken(TSRMLS_C);
	Register_TElCustomAuthenticator(TSRMLS_C);
	Register_TElBasicDCAuthToken(TSRMLS_C);
	Register_TElBasicDCAuthenticator(TSRMLS_C);
	Register_SBDCAuth_Enum_Flags(TSRMLS_C);

	// SBJNLP unit class registration
	Register_TElJNLPFile(TSRMLS_C);
	Register_SBJNLP_Enum_Flags(TSRMLS_C);

	// SBSimpleFTPS unit class registration
	Register_TSBFTPFileInfo(TSRMLS_C);
	Register_TElSimpleFTPSClient(TSRMLS_C);
	Register_TElFTPFileInfo(TSRMLS_C);
	Register_TElFTPProxySettings(TSRMLS_C);
	Register_TElFTPSTransferManager(TSRMLS_C);
	Register_TElMultipartStreamAccess(TSRMLS_C);
	Register_TElFTPSTransferChunk(TSRMLS_C);
	Register_TElMultipartStreamPart(TSRMLS_C);
	Register_SBSimpleFTPS_Enum_Flags(TSRMLS_C);
	Register_SBSimpleFTPS_Aliases(TSRMLS_C);

	// SBFTPSServer unit class registration
	Register_TElFTPSServerFileInfo(TSRMLS_C);
	Register_TElFTPSServerMessageTable(TSRMLS_C);
	Register_TElFTPSUser(TSRMLS_C);
	Register_TElFTPSServer(TSRMLS_C);
	Register_SBFTPSServer_Enum_Flags(TSRMLS_C);
	Register_SBFTPSServer_Aliases(TSRMLS_C);

	// SBSimpleFTPSServer unit class registration
	Register_TElSimpleFTPSServerSessionThread(TSRMLS_C);
	Register_TElSimpleFTPSServer(TSRMLS_C);
	Register_TElSimpleFTPSServerListeningThread(TSRMLS_C);
	Register_TElFTPSUsers(TSRMLS_C);
	Register_SBSimpleFTPSServer_Aliases(TSRMLS_C);

	// SBHTTPSCommon unit class registration
	Register_TElHTTPSClientParams(TSRMLS_C);
	Register_TElCustomSAMLAdapter(TSRMLS_C);
	Register_TElHTTPRanges(TSRMLS_C);
	Register_TElHTTPParams(TSRMLS_C);
	Register_TElHTTPCustomRequestParams(TSRMLS_C);
	Register_TElHTTPMultipartPart(TSRMLS_C);
	Register_TElHTTPMultipartList(TSRMLS_C);
	Register_TElHTTPEncodingProcessor(TSRMLS_C);
	Register_TElHTTPChunkedProcessor(TSRMLS_C);
	Register_TElHTTPCompressedProcessor(TSRMLS_C);
	Register_TElHTTPUtils(TSRMLS_C);
	Register_SBHTTPSCommon_Enum_Flags(TSRMLS_C);
	Register_SBHTTPSCommon_Aliases(TSRMLS_C);

	// SBHTTPSClient unit class registration
	Register_TElHTTPRequestParams(TSRMLS_C);
	Register_TElHTTPSClient(TSRMLS_C);
	Register_SBHTTPSClient_TElStringValue(TSRMLS_C);
	Register_SBHTTPSClient_Enum_Flags(TSRMLS_C);
	Register_SBHTTPSClient_Aliases(TSRMLS_C);

	// SBHTTPTSPClient unit class registration
	Register_TElHTTPTSPClient(TSRMLS_C);
	Register_SBHTTPTSPClient_Aliases(TSRMLS_C);

	// SBHTTPOCSPClient unit class registration
	Register_TElHTTPOCSPClient(TSRMLS_C);
	Register_TElHTTPOCSPClientFactory(TSRMLS_C);
	Register_SBHTTPOCSPClient_Aliases(TSRMLS_C);

	// SBHTTPCertRetriever unit class registration
	Register_TElHTTPCertificateRetriever(TSRMLS_C);
	Register_TElHTTPCertificateRetrieverFactory(TSRMLS_C);
	Register_SBHTTPCertRetriever_Aliases(TSRMLS_C);

	// SBHTTPCRL unit class registration
	Register_TElHTTPCRLRetriever(TSRMLS_C);
	Register_TElHTTPCRLRetrieverFactory(TSRMLS_C);

	// SBCookieMgr unit class registration
	Register_TElCookie(TSRMLS_C);
	Register_TElCookieDomain(TSRMLS_C);
	Register_TElCookieManager(TSRMLS_C);
	Register_SBCookieMgr_Aliases(TSRMLS_C);

	// SBOAuth2 unit class registration
	Register_TElOAuth2Request(TSRMLS_C);
	Register_TElOAuth2Client(TSRMLS_C);
	Register_TElOAuth2RedirectReceiver(TSRMLS_C);
	Register_SBOAuth2_Enum_Flags(TSRMLS_C);

	// SBWebSocketCommon unit class registration
	Register_TElWebSocketMessage(TSRMLS_C);
	Register_TElWebSocketOption(TSRMLS_C);
	Register_TElWebSocketExtension(TSRMLS_C);
	Register_TElWebSocketBase(TSRMLS_C);
	Register_TElWebSocketSubProtocol(TSRMLS_C);
	Register_TElWebSocketExtensions(TSRMLS_C);
	Register_TElWebSocketSubProtocols(TSRMLS_C);
	Register_SBWebSocketCommon_Enum_Flags(TSRMLS_C);

	// SBWebSocketClient unit class registration
	Register_TElWebSocketClient(TSRMLS_C);

	// SBRESTClient unit class registration
	Register_TElRESTClient(TSRMLS_C);
	Register_SBRESTClient_Enum_Flags(TSRMLS_C);
	Register_SBRESTClient_Aliases(TSRMLS_C);

	// SBSimpleOAuth2 unit class registration
	Register_TElSimpleOAuth2Client(TSRMLS_C);

	// SBHTTPSServer unit class registration
	Register_TElHTTPSession(TSRMLS_C);
	Register_TElHTTPServerRequestParams(TSRMLS_C);
	Register_TElHTTPOAuth2ApplicationInfo(TSRMLS_C);
	Register_TElHTTPOAuth2CustomApplicationStorage(TSRMLS_C);
	Register_TElHTTPOAuth2MemoryApplicationStorage(TSRMLS_C);
	Register_TElHTTPCustomSessionManager(TSRMLS_C);
	Register_TElHTTPMemorySessionManager(TSRMLS_C);
	Register_TElHTTPServerResponseParams(TSRMLS_C);
	Register_TElMultipartFormData(TSRMLS_C);
	Register_TElMultipartFormList(TSRMLS_C);
	Register_TElHTTPSServer(TSRMLS_C);
	Register_TElDigestAuth(TSRMLS_C);
	Register_SBHTTPSServer_Enum_Flags(TSRMLS_C);
	Register_SBHTTPSServer_Aliases(TSRMLS_C);

	// SBWebSocketServer unit class registration
	Register_TElWebSocketServer(TSRMLS_C);

	// SBLDAPCertStorage unit class registration
	Register_TElLDAPCertStorage(TSRMLS_C);
	Register_SBLDAPCertStorage_Aliases(TSRMLS_C);

	// SBLDAPCertRetriever unit class registration
	Register_TElLDAPCertificateRetriever(TSRMLS_C);
	Register_TElLDAPCertificateRetrieverFactory(TSRMLS_C);
	Register_SBLDAPCertRetriever_Aliases(TSRMLS_C);

	// SBLDAPCRL unit class registration
	Register_TElLDAPCRLRetriever(TSRMLS_C);
	Register_TElLDAPCRLRetrieverFactory(TSRMLS_C);

	// SBLDAPSClient unit class registration
	Register_TElLDAPSSearchFilter(TSRMLS_C);
	Register_TElLDAPResponse(TSRMLS_C);
	Register_TElLDAPURL(TSRMLS_C);
	Register_TElLDAPSClient(TSRMLS_C);
	Register_SBLDAPSClient_Enum_Flags(TSRMLS_C);
	Register_SBLDAPSClient_Aliases(TSRMLS_C);

	// SBLDAPSCore unit class registration
	Register_TElLDAPMessage(TSRMLS_C);
	Register_TElLDAPSimpleBindMessage(TSRMLS_C);
	Register_TElLDAPSASLBindMessage(TSRMLS_C);
	Register_TElLDAPUnbindMessage(TSRMLS_C);
	Register_TElLDAPResult(TSRMLS_C);
	Register_TElLDAPResultMessage(TSRMLS_C);
	Register_TElLDAPBindResponseMessage(TSRMLS_C);
	Register_TElLDAPSearchMessage(TSRMLS_C);
	Register_TElLDAPAttributeValue(TSRMLS_C);
	Register_TElLDAPPartialAttribute(TSRMLS_C);
	Register_TElLDAPSearchEntryMessage(TSRMLS_C);
	Register_TElLDAPSearchReferenceMessage(TSRMLS_C);
	Register_TElLDAPDeleteMessage(TSRMLS_C);
	Register_TElLDAPModifyMessage(TSRMLS_C);
	Register_SBLDAPSCore_Enum_Flags(TSRMLS_C);
	Register_SBLDAPSCore_Aliases(TSRMLS_C);

	// SBSMTPClient unit class registration
	Register_TElSMTPClient(TSRMLS_C);
	Register_SBSMTPClient_Enum_Flags(TSRMLS_C);
	Register_SBSMTPClient_Aliases(TSRMLS_C);

	// SBPOP3Client unit class registration
	Register_TSBPOP3MessageID(TSRMLS_C);
	Register_TSBPOP3MessageSize(TSRMLS_C);
	Register_TElPOP3Client(TSRMLS_C);
	Register_SBPOP3Client_Enum_Flags(TSRMLS_C);
	Register_SBPOP3Client_Aliases(TSRMLS_C);

	// SBIMAPClient unit class registration
	Register_TElIMAPLiteralContext(TSRMLS_C);
	Register_TElIMAPMailBoxState(TSRMLS_C);
	Register_TElIMAPMailBoxInfo(TSRMLS_C);
	Register_TElIMAPMailBoxesList(TSRMLS_C);
	Register_TElIMAPFetchResponseItem(TSRMLS_C);
	Register_TElIMAPFetchResponseLine(TSRMLS_C);
	Register_TElIMAPFetchResponse(TSRMLS_C);
	Register_TElIMAPAppendResult(TSRMLS_C);
	Register_TElIMAPCopyResult(TSRMLS_C);
	Register_TElIMAPIdleUpdate(TSRMLS_C);
	Register_TElIMAPIdleThread(TSRMLS_C);
	Register_TElIMAPTimeoutThread(TSRMLS_C);
	Register_TElIMAPClient(TSRMLS_C);
	Register_SBIMAPClient_Enum_Flags(TSRMLS_C);
	Register_SBIMAPClient_Aliases(TSRMLS_C);

	// SBIMAPUtils unit class registration
	Register_TElIMAPParser(TSRMLS_C);

	// SBDomainKeys unit class registration
	Register_TElDKPublicKey(TSRMLS_C);
	Register_TElDKRSAPublicKey(TSRMLS_C);
	Register_TElDKDNSRecord(TSRMLS_C);
	Register_TElDomainKeysClass(TSRMLS_C);
	Register_TElDomainKeysSigner(TSRMLS_C);
	Register_TElDomainKeysVerifier(TSRMLS_C);
	Register_TElDKSignature(TSRMLS_C);
	Register_SBDomainKeys_Enum_Flags(TSRMLS_C);
	Register_SBDomainKeys_Aliases(TSRMLS_C);

	// SBMIME unit class registration
	Register_TElParseContext(TSRMLS_C);
	Register_TElFieldParam(TSRMLS_C);
	Register_TElMessage(TSRMLS_C);
	Register_TElMessageHeader(TSRMLS_C);
	Register_TElMessageHeaderField(TSRMLS_C);
	Register_TElMailAddressGroup(TSRMLS_C);
	Register_TElMailAddressList(TSRMLS_C);
	Register_TElMailAddress(TSRMLS_C);
	Register_TElMessagePart(TSRMLS_C);
	Register_TElMultiPartList(TSRMLS_C);
	Register_TElPlainTextPart(TSRMLS_C);
	Register_TElMessagePartHandler(TSRMLS_C);
	Register_TElConverter(TSRMLS_C);
	Register_TElRegisteredMessagePartHandlers(TSRMLS_C);
	Register_TElXmlPart(TSRMLS_C);
	Register_SBMIME_Enum_Flags(TSRMLS_C);
	Register_SBMIME_Aliases(TSRMLS_C);

	// SBMIMEEnc unit class registration
	Register_TElMimeEncodingStream(TSRMLS_C);
	Register_TElBase64Stream(TSRMLS_C);
	Register_TElQuotedPrintableStream(TSRMLS_C);
	Register_TEl7BitStream(TSRMLS_C);
	Register_TEl8BitStream(TSRMLS_C);
	Register_TElBinaryStream(TSRMLS_C);
	Register_SBMIMEEnc_Enum_Flags(TSRMLS_C);
	Register_SBMIMEEnc_Aliases(TSRMLS_C);

	// SBMIMEStream unit class registration
	Register_TElCustomMIMEStream(TSRMLS_C);
	Register_TNullMIMEStream(TSRMLS_C);
	Register_TElCustomMemoryMIMEStream(TSRMLS_C);
	Register_TElMemoryMIMEStream(TSRMLS_C);
	Register_TAnsiStringMIMEStream(TSRMLS_C);
	Register_TWideStringMIMEStream(TSRMLS_C);
	Register_SBMIMEStream_Aliases(TSRMLS_C);

	// SBSimpleMIME unit class registration
	Register_TElSimpleMIMEAttachment(TSRMLS_C);
	Register_TElSimpleMIMEMessage(TSRMLS_C);
	Register_SBSimpleMIME_Aliases(TSRMLS_C);

	// SBCompoundFile unit class registration
	Register_TElCompoundFileStorage(TSRMLS_C);
	Register_TElCompoundFileCustomEntry(TSRMLS_C);
	Register_TElCompoundFileStorageEntry(TSRMLS_C);
	Register_TElCompoundFileVirtualStream(TSRMLS_C);
	Register_TElCompoundFileTableStream(TSRMLS_C);
	Register_TElCompoundFileDirectoryStream(TSRMLS_C);
	Register_TElCompoundFileStreamEntry(TSRMLS_C);

	// SBCompoundFileBase unit class registration
	Register_TSBCompoundFileHeader(TSRMLS_C);
	Register_TSBCompoundFileDirectoryEntry(TSRMLS_C);

	// SBOffice unit class registration
	Register_TElOfficeOpenXMLSignatureView(TSRMLS_C);
	Register_TElOfficeCustomSecurityHandler(TSRMLS_C);
	Register_TElOfficeCustomEncryptionHandler(TSRMLS_C);
	Register_TElOfficeBinaryCustomEncryptionHandler(TSRMLS_C);
	Register_TElOfficeOpenXMLCustomEncryptionHandler(TSRMLS_C);
	Register_TElOpenOfficeCustomEncryptionHandler(TSRMLS_C);
	Register_TElOfficeCustomSignatureHandler(TSRMLS_C);
	Register_TElOfficeBinaryCustomSignatureHandler(TSRMLS_C);
	Register_TElOfficeBinaryUnsupportedSignatureHandler(TSRMLS_C);
	Register_TElOfficeBinaryInvalidSignatureHandler(TSRMLS_C);
	Register_TElOfficeOpenXMLCustomSignatureHandler(TSRMLS_C);
	Register_TElOfficeOpenXMLUnsupportedSignatureHandler(TSRMLS_C);
	Register_TElOfficeOpenXMLInvalidSignatureHandler(TSRMLS_C);
	Register_TElOpenOfficeCustomSignatureHandler(TSRMLS_C);
	Register_TElOpenOfficeUnsupportedSignatureHandler(TSRMLS_C);
	Register_TElOpenOfficeInvalidSignatureHandler(TSRMLS_C);
	Register_TElOfficeBinaryDocument(TSRMLS_C);
	Register_TElOfficeOpenXMLPackage(TSRMLS_C);
	Register_TElOfficeOpenXMLSignatureLine(TSRMLS_C);
	Register_TElOfficeOpenXMLDocument(TSRMLS_C);
	Register_TElOfficeOpenXPSSignatureDefinition(TSRMLS_C);
	Register_TElOfficeOpenXPSPageContent(TSRMLS_C);
	Register_TElOfficeOpenXPSFixedDocument(TSRMLS_C);
	Register_TElOfficeOpenXPSDocument(TSRMLS_C);
	Register_TElOpenOfficeDocument(TSRMLS_C);
	Register_TElOfficeDocument(TSRMLS_C);
	Register_SBOffice_Enum_Flags(TSRMLS_C);
	Register_SBOffice_Aliases(TSRMLS_C);

	// SBOfficeBinaryCore unit class registration
	Register_TElOfficeBinaryObject(TSRMLS_C);
	Register_TElOfficeDataSpaceVersionInfo(TSRMLS_C);
	Register_TElOfficeDataSpaceReferenceComponent(TSRMLS_C);
	Register_TElOfficeDataSpaceMapEntry(TSRMLS_C);
	Register_TElOfficeDataSpaceMap(TSRMLS_C);
	Register_TElOfficeDataSpaceDefinition(TSRMLS_C);
	Register_TElOfficeTransformInfoHeader(TSRMLS_C);
	Register_TElOfficeEncryptionTransformInfo(TSRMLS_C);
	Register_TElOfficeExtensibilityHeader(TSRMLS_C);
	Register_TElOfficeIRMDSTransformInfo(TSRMLS_C);
	Register_TElOfficeEndUserLicenseHeader(TSRMLS_C);
	Register_TElOfficeEncryptionHeader(TSRMLS_C);
	Register_TElOfficeEncryptionVerifier(TSRMLS_C);
	Register_TElOfficeEncryptionInfo(TSRMLS_C);
	Register_TElOfficeEncryptionInfoV1(TSRMLS_C);
	Register_TElOfficeEncryptionInfoV2(TSRMLS_C);
	Register_TElOfficeEncryptionInfoV3(TSRMLS_C);
	Register_TElOfficeEncryptionInfoV4(TSRMLS_C);
	Register_TElOfficeXORObfuscation(TSRMLS_C);
	Register_TElOfficeEncryptedStreamDescriptor(TSRMLS_C);
	Register_TElOfficeCertificateInfo(TSRMLS_C);
	Register_TElOfficeCertStoreCertificateGroup(TSRMLS_C);
	Register_TElOfficeDocSigSerializedCertStore(TSRMLS_C);
	Register_TElOfficeCryptoAPIDigitalSignature(TSRMLS_C);
	Register_TElOfficeWordFIBBase(TSRMLS_C);
	Register_TElOfficeWordFIBRgFcLcb(TSRMLS_C);
	Register_TElOfficeWordFIB(TSRMLS_C);
	Register_TElOfficeWorkbookRecordInfo(TSRMLS_C);
	Register_TElOfficeWorkbookBOF(TSRMLS_C);
	Register_TElOfficeWorkbookFilePass(TSRMLS_C);
	Register_TElOfficePowerPointRecordHeader(TSRMLS_C);
	Register_TElOfficePowerPointUserEditAtom(TSRMLS_C);
	Register_TElOfficePowerPointPersistDirectoryEntry(TSRMLS_C);
	Register_TElOfficePowerPointPersistDirectoryAtom(TSRMLS_C);
	Register_SBOfficeBinaryCore_Aliases(TSRMLS_C);

	// SBOfficeCommon unit class registration
	Register_TSBOfficeVersion(TSRMLS_C);
	Register_SBOfficeCommon_Enum_Flags(TSRMLS_C);

	// SBOfficePackage unit class registration
	Register_TElOfficePackagePart(TSRMLS_C);
	Register_TElOfficePackage(TSRMLS_C);
	Register_TElOfficeZipPackage(TSRMLS_C);
	Register_TElOpenOfficePackage(TSRMLS_C);

	// SBOfficeSecurity unit class registration
	Register_TElOfficeOpenXMLStandardEncryptionHandler(TSRMLS_C);
	Register_TElOfficeOpenXMLAgileEncryptionHandler(TSRMLS_C);
	Register_TElOfficeOpenXMLKeyEncryptor(TSRMLS_C);
	Register_TElOfficeOpenXMLPasswordKeyEncryptor(TSRMLS_C);
	Register_TElOpenOfficeEncryptionHandler(TSRMLS_C);
	Register_TElOfficeBinaryRC4EncryptionHandler(TSRMLS_C);
	Register_TElOfficeBinaryRC4CryptoAPIEncryptionHandler(TSRMLS_C);
	Register_TElOfficeBinaryCryptoAPISignatureHandler(TSRMLS_C);
	Register_TElOfficeBinarySignedEntry(TSRMLS_C);
	Register_TElOfficeBinaryXMLSignatureHandler(TSRMLS_C);
	Register_TElOfficeOpenXMLSignedPart(TSRMLS_C);
	Register_TElOfficeOpenXMLSignedRelationshipPart(TSRMLS_C);
	Register_TElOfficeOpenXMLBaseSignatureHandler(TSRMLS_C);
	Register_TElOfficeOpenXMLSignatureHandler(TSRMLS_C);
	Register_TElOfficeOpenXPSSignatureHandler(TSRMLS_C);
	Register_TElOpenOfficeSignedEntry(TSRMLS_C);
	Register_TElOpenOfficeSignatureHandler(TSRMLS_C);
	Register_SBOfficeSecurity_Enum_Flags(TSRMLS_C);

	// SBOfficeXMLCore unit class registration
	Register_TElOfficeOpenXMLElement(TSRMLS_C);
	Register_TElOfficeOpenXMLRelationship(TSRMLS_C);
	Register_TElOfficeOpenXMLRelationships(TSRMLS_C);
	Register_TElOfficeOpenXMLDefault(TSRMLS_C);
	Register_TElOfficeOpenXMLDefaultList(TSRMLS_C);
	Register_TElOfficeOpenXMLOverride(TSRMLS_C);
	Register_TElOfficeOpenXMLOverrideList(TSRMLS_C);
	Register_TElOfficeOpenXMLContentTypes(TSRMLS_C);
	Register_TElOfficeXMLDCSimpleLiteral(TSRMLS_C);
	Register_TElOfficeXMLDCDate(TSRMLS_C);
	Register_TElOfficeOpenXMLCoreProperties(TSRMLS_C);
	Register_TElOfficeXMLKeyData(TSRMLS_C);
	Register_TElOfficeXMLDataIntegrity(TSRMLS_C);
	Register_TElOfficeXMLKeyEncryptor(TSRMLS_C);
	Register_TElOfficeXMLKeyEncryptors(TSRMLS_C);
	Register_TElOfficeXMLPasswordKeyEncryptor(TSRMLS_C);
	Register_TElOfficeXMLEncryption(TSRMLS_C);
	Register_TElOfficeXMLSignatureTime(TSRMLS_C);
	Register_TElOfficeOpenXMLRelationshipTransform(TSRMLS_C);
	Register_TElOfficeXMLSignatureInfoV1(TSRMLS_C);
	Register_TElOfficeXMLSpotLocation(TSRMLS_C);
	Register_TElOfficeXMLSignatureDefinition(TSRMLS_C);
	Register_TElOfficeXMLFixedDocumentSequence(TSRMLS_C);
	Register_TElOfficeXMLPageContent(TSRMLS_C);
	Register_TElOfficeXMLFixedDocument(TSRMLS_C);
	Register_TElOpenOfficeXMLManifestAlgorithm(TSRMLS_C);
	Register_TElOpenOfficeXMLManifestKeyDerivation(TSRMLS_C);
	Register_TElOpenOfficeXMLManifestStartKeyGeneration(TSRMLS_C);
	Register_TElOpenOfficeXMLManifestEncryptionData(TSRMLS_C);
	Register_TElOpenOfficeXMLManifestFileEntry(TSRMLS_C);
	Register_TElOpenOfficeXMLManifest(TSRMLS_C);
	Register_SBOfficeXMLCore_Enum_Flags(TSRMLS_C);

	// SBPDF unit class registration
	Register_TElPDFDocument(TSRMLS_C);
	Register_TElPDFSignature(TSRMLS_C);
	Register_TElPDFURProperties(TSRMLS_C);
	Register_TElPDFSigRefEntry(TSRMLS_C);
	Register_TElPDFSecurityHandler(TSRMLS_C);
	Register_TElPDFByteRange(TSRMLS_C);
	Register_TElPDFImage(TSRMLS_C);
	Register_TElPDFCustomFontObject(TSRMLS_C);
	Register_TElPDFEncoding(TSRMLS_C);
	Register_TElPDFFontDescriptor(TSRMLS_C);
	Register_TElPDFCIDFontDescriptor(TSRMLS_C);
	Register_TElPDFCIDSystemInfo(TSRMLS_C);
	Register_TElPDFCustomFont(TSRMLS_C);
	Register_TElPDFSimpleFont(TSRMLS_C);
	Register_TElPDFCompositeFont(TSRMLS_C);
	Register_TElPDFMetricW(TSRMLS_C);
	Register_TElPDFMetricW2(TSRMLS_C);
	Register_TElPDFCIDFont(TSRMLS_C);
	Register_TElPDFSignatureWidgetText(TSRMLS_C);
	Register_TElPDFSignatureWidgetTextList(TSRMLS_C);
	Register_TElPDFSignatureWidgetProps(TSRMLS_C);
	Register_TElPDFSignatureInfo(TSRMLS_C);
	Register_TElPDFEncodingHandler(TSRMLS_C);
	Register_TElPDFRequirementHandler(TSRMLS_C);
	Register_TElPDFRequirement(TSRMLS_C);
	Register_TElPDFPageInfo(TSRMLS_C);
	Register_TElPDFFileAttachment(TSRMLS_C);
	Register_TElPDFLegalContentAttestation(TSRMLS_C);
	Register_TElPDFPublicKeyRevocationInfo(TSRMLS_C);
	Register_SBPDF_Enum_Flags(TSRMLS_C);
	Register_SBPDF_Aliases(TSRMLS_C);

	// SBPDFCore unit class registration
	Register_TElPDFObject(TSRMLS_C);
	Register_TElPDFFile(TSRMLS_C);
	Register_TElPDFNull(TSRMLS_C);
	Register_TElPDFBoolean(TSRMLS_C);
	Register_TElPDFReal(TSRMLS_C);
	Register_TElPDFString(TSRMLS_C);
	Register_TElPDFComment(TSRMLS_C);
	Register_TElPDFName(TSRMLS_C);
	Register_TElPDFCpxObj(TSRMLS_C);
	Register_TElPDFArray(TSRMLS_C);
	Register_TElPDFDictionary(TSRMLS_C);
	Register_TElPDFStream(TSRMLS_C);
	Register_TElPDFIndirect(TSRMLS_C);
	Register_TElPDFRef(TSRMLS_C);
	Register_TElPDFXRef(TSRMLS_C);
	Register_TElPDFXrefEntry(TSRMLS_C);
	Register_TElPDFXRefs(TSRMLS_C);
	Register_SBPDFCore_Enum_Flags(TSRMLS_C);
	Register_SBPDFCore_Aliases(TSRMLS_C);

	// SBPDFSecurity unit class registration
	Register_TElPDFPasswordSecurityHandler(TSRMLS_C);
	Register_TElPDFPublicKeySecurityHandler(TSRMLS_C);
	Register_TElPDFPublicKeyRecipientGroup(TSRMLS_C);
	Register_SBPDFSecurity_Enum_Flags(TSRMLS_C);
	Register_SBPDFSecurity_Aliases(TSRMLS_C);

	// SBPDFUtils unit class registration
	Register_TElPDFPermissions(TSRMLS_C);
	Register_SBPDFUtils_Aliases(TSRMLS_C);

	// SBPAdES unit class registration
	Register_TElPDFAdvancedPublicKeySecurityHandler(TSRMLS_C);
	Register_SBPAdES_Enum_Flags(TSRMLS_C);

	// SBPGP unit class registration
	Register_TElPGPWriter(TSRMLS_C);
	Register_TElPGPProcessingUnit(TSRMLS_C);
	Register_TElPGPReader(TSRMLS_C);
	Register_SBPGP_Enum_Flags(TSRMLS_C);
	Register_SBPGP_Aliases(TSRMLS_C);

	// SBPGPConstants unit class registration
	Register_SBPGPConstants_Enum_Flags(TSRMLS_C);

	// SBPGPEntities unit class registration
	Register_TElPGPEntity(TSRMLS_C);
	Register_TElPGPPublicKeyEntity(TSRMLS_C);
	Register_TElPGPS2K(TSRMLS_C);
	Register_TElPGPUserIDEntity(TSRMLS_C);
	Register_TElPGPUserAttrSubpacket(TSRMLS_C);
	Register_TElPGPUserAttrImageSubpacket(TSRMLS_C);
	Register_TElPGPUserAttrEntity(TSRMLS_C);
	Register_TElPGPSignatureEntity(TSRMLS_C);
	Register_TElPGPSignatureSubpacket(TSRMLS_C);
	Register_TElPGPCreationTimeSignatureSubpacket(TSRMLS_C);
	Register_TElPGPExpirationTimeSignatureSubpacket(TSRMLS_C);
	Register_TElPGPEmbeddedSignatureSignatureSubpacket(TSRMLS_C);
	Register_TElPGPExportableCertificationSignatureSubpacket(TSRMLS_C);
	Register_TElPGPTrustSignatureSubpacket(TSRMLS_C);
	Register_TElPGPRegularExpressionSignatureSubpacket(TSRMLS_C);
	Register_TElPGPRevocableSignatureSubpacket(TSRMLS_C);
	Register_TElPGPKeyExpirationTimeSignatureSubpacket(TSRMLS_C);
	Register_TElPGPPreferredSymmetricAlgorithmsSignatureSubpacket(TSRMLS_C);
	Register_TElPGPRevocationKeySignatureSubpacket(TSRMLS_C);
	Register_TElPGPIssuerKeyIDSignatureSubpacket(TSRMLS_C);
	Register_TElPGPNotationDataSignatureSubpacket(TSRMLS_C);
	Register_TElPGPPreferredHashAlgorithmsSignatureSubpacket(TSRMLS_C);
	Register_TElPGPPreferredCompressionAlgorithmsSignatureSubpacket(TSRMLS_C);
	Register_TElPGPKeyServerPreferencesSignatureSubpacket(TSRMLS_C);
	Register_TElPGPPreferredKeyServerSignatureSubpacket(TSRMLS_C);
	Register_TElPGPPrimaryUserIDSignatureSubpacket(TSRMLS_C);
	Register_TElPGPPolicyURLSignatureSubpacket(TSRMLS_C);
	Register_TElPGPKeyFlagsSignatureSubpacket(TSRMLS_C);
	Register_TElPGPSignersUserIDSignatureSubpacket(TSRMLS_C);
	Register_TElPGPReasonForRevocationSignatureSubpacket(TSRMLS_C);
	Register_TElPGPFeaturesSignatureSubpacket(TSRMLS_C);
	Register_TElPGPTargetSignatureSubpacket(TSRMLS_C);
	Register_TElPGPX509SignatureSubpacket(TSRMLS_C);
	Register_TElPGPSignatureSubpackets(TSRMLS_C);
	Register_TElPGPTrustEntity(TSRMLS_C);
	Register_TElPGPPublicKeyEncryptedSessionKeyEntity(TSRMLS_C);
	Register_TElPGPSymmetricKeyEncryptedSessionKeyEntity(TSRMLS_C);
	Register_TElPGPOnePassSignatureEntity(TSRMLS_C);
	Register_TElPGPSecretKeyEntity(TSRMLS_C);
	Register_TElPGPStreamingEntity(TSRMLS_C);
	Register_TElPGPLiteral(TSRMLS_C);
	Register_TElPGPSymmetricallyEncrypted(TSRMLS_C);
	Register_TElPGPCompressed(TSRMLS_C);
	Register_TElPGPStreamProcessor(TSRMLS_C);
	Register_TElPGPStubEntity(TSRMLS_C);
	Register_TElPGPStreamIO(TSRMLS_C);
	Register_SBPGPEntities_Enum_Flags(TSRMLS_C);
	Register_SBPGPEntities_Aliases(TSRMLS_C);

	// SBPGPKeys unit class registration
	Register_TElPGPCustomPublicKey(TSRMLS_C);
	Register_TElPGPPublicSubkey(TSRMLS_C);
	Register_TElPGPPublicKey(TSRMLS_C);
	Register_TElPGPCustomSecretKey(TSRMLS_C);
	Register_TElPGPSecretSubkey(TSRMLS_C);
	Register_TElPGPSecretKey(TSRMLS_C);
	Register_TElPGPTrust(TSRMLS_C);
	Register_TElPGPSignature(TSRMLS_C);
	Register_TElPGPCustomUser(TSRMLS_C);
	Register_TElPGPUserID(TSRMLS_C);
	Register_TElPGPUserAttr(TSRMLS_C);
	Register_TElPGPKeyring(TSRMLS_C);
	Register_TElPGPJpegImage(TSRMLS_C);
	Register_SBPGPKeys_Enum_Flags(TSRMLS_C);
	Register_SBPGPKeys_Aliases(TSRMLS_C);

	// SBPGPMD unit class registration
	Register_TElPGPHashingPool(TSRMLS_C);

	// SBPGPStreams unit class registration
	Register_TElPGPStream(TSRMLS_C);
	Register_TElPGPArmoringStream(TSRMLS_C);
	Register_TElPGPDearmoringStream(TSRMLS_C);
	Register_TElPGPEnvelopingStream(TSRMLS_C);
	Register_TElPGPUnenvelopingStream(TSRMLS_C);
	Register_TElPGPEncryptingStream(TSRMLS_C);
	Register_TElPGPDecryptingStream(TSRMLS_C);
	Register_TElPGPCompressingStream(TSRMLS_C);
	Register_TElPGPDecompressingStream(TSRMLS_C);
	Register_TElPGPSigningStream(TSRMLS_C);
	Register_TElPGPClearTextVerifyingStream(TSRMLS_C);
	Register_TElPGPEntityStream(TSRMLS_C);
	Register_SBPGPStreams_Enum_Flags(TSRMLS_C);
	Register_SBPGPStreams_Aliases(TSRMLS_C);

	// SBPGPUtils unit class registration
	Register_TSBKeyID(TSRMLS_C);
	Register_TSBPGPSignatureMaterial(TSRMLS_C);
	Register_TSBPGPEncryptedSymmetricKey(TSRMLS_C);
	Register_SBPGPUtils_Enum_Flags(TSRMLS_C);

#ifdef SB_WINDOWS
	// SBPGPSFX unit class registration
	Register_SBPGPSFX__IMAGE_DATA_DIRECTORY(TSRMLS_C);
	Register_SBPGPSFX__IMAGE_OPTIONAL_HEADER(TSRMLS_C);
	Register_SBPGPSFX__IMAGE_DOS_HEADER(TSRMLS_C);
	Register_SBPGPSFX__IMAGE_FILE_HEADER(TSRMLS_C);
	Register_SBPGPSFX__IMAGE_NT_HEADERS(TSRMLS_C);
	Register_TISHMisc(TSRMLS_C);
	Register_SBPGPSFX__IMAGE_SECTION_HEADER(TSRMLS_C);
	Register_TElPGPSFXStub(TSRMLS_C);
	Register_TElPGPSFXMaker(TSRMLS_C);
	Register_SBPGPSFX_Enum_Flags(TSRMLS_C);
	Register_SBPGPSFX_Aliases(TSRMLS_C);
#else
	// SBLDAPSKeyserverClient unit class registration
	Register_TElLDAPSKeyserverSearchFilter(TSRMLS_C);
	Register_TElLDAPSKeyserverClient(TSRMLS_C);
	Register_SBLDAPSKeyserverClient_Enum_Flags(TSRMLS_C);
	Register_SBLDAPSKeyserverClient_Aliases(TSRMLS_C);
#endif

#ifdef SB_WINDOWS
	// SBLDAPSKeyserverClient unit class registration
	Register_TElLDAPSKeyserverSearchFilter(TSRMLS_C);
	Register_TElLDAPSKeyserverClient(TSRMLS_C);
	Register_SBLDAPSKeyserverClient_Enum_Flags(TSRMLS_C);
	Register_SBLDAPSKeyserverClient_Aliases(TSRMLS_C);

	// SBPGPMIME unit class registration
	Register_TElMessagePartHandlerPGPMime(TSRMLS_C);
	Register_TElMessagePartHandlerPGPKeys(TSRMLS_C);
	Register_TElSimplePGPMIMEOptions(TSRMLS_C);
	Register_TElSimplePGPMIMEMessage(TSRMLS_C);
	Register_SBPGPMIME_Enum_Flags(TSRMLS_C);
	Register_SBPGPMIME_Aliases(TSRMLS_C);

	// SBPGPSSH unit class registration
	Register_TElSSHPGPKey(TSRMLS_C);
	Register_TElSSHPGPAuthHandler(TSRMLS_C);
	Register_SBPGPSSH_Aliases(TSRMLS_C);

	// SBPGPTLS unit class registration
	Register_TElSSLPGPCertificateTypeHandler(TSRMLS_C);
	Register_TElSSLClientPGPCertificateTypeHandler(TSRMLS_C);
	Register_TElSSLServerPGPCertificateTypeHandler(TSRMLS_C);
	Register_SBPGPTLS_Enum_Flags(TSRMLS_C);

	// SBCMS unit class registration
	Register_TElASN1DirectoryString(TSRMLS_C);
	Register_TElCMSProperty(TSRMLS_C);
	Register_TElCMSHash(TSRMLS_C);
	Register_TElCMSSignerIdentifier(TSRMLS_C);
	Register_TElCMSCertificateRefs(TSRMLS_C);
	Register_TElCMSCRLIdentifier(TSRMLS_C);
	Register_TElCMSCRLValidatedID(TSRMLS_C);
	Register_TElCMSOCSPIdentifier(TSRMLS_C);
	Register_TElCMSOCSPResponsesID(TSRMLS_C);
	Register_TElCMSRevocationRef(TSRMLS_C);
	Register_TElCMSRevocationRefs(TSRMLS_C);
	Register_TElCMSRevocationValues(TSRMLS_C);
	Register_TElCMSContent(TSRMLS_C);
	Register_TElCMSSigPolicyQualifier(TSRMLS_C);
	Register_TElCMSSignaturePolicy(TSRMLS_C);
	Register_TElCMSContentHints(TSRMLS_C);
	Register_TElCMSContentReference(TSRMLS_C);
	Register_TElCMSCommitmentTypeIndication(TSRMLS_C);
	Register_TElCMSSignerLocation(TSRMLS_C);
	Register_TElCMSSigningCertificate(TSRMLS_C);
	Register_TElCMSSignerAttributes(TSRMLS_C);
	Register_TElCMSSignaturePolicyStore(TSRMLS_C);
	Register_TElCMSSignature(TSRMLS_C);
	Register_TElCMSTimestamp(TSRMLS_C);
	Register_TElATSHashIndexProcessor(TSRMLS_C);
	Register_TElCMSMessage(TSRMLS_C);
	Register_TElCMSContentHash(TSRMLS_C);
	Register_TElSignedCMSMessage(TSRMLS_C);
	Register_TElSignedAndEnvelopedCMSMessage(TSRMLS_C);
	Register_SBCMS_Enum_Flags(TSRMLS_C);

	// SBCryptoProvPKCS11 unit class registration
	Register_TElPKCS11CryptoProviderOptions(TSRMLS_C);
	Register_TElPKCS11CryptoProvider(TSRMLS_C);
	Register_TElPKCS11CryptoKeyContainer(TSRMLS_C);
	Register_TElPKCS11CryptoObject(TSRMLS_C);
	Register_TElPKCS11CryptoKey(TSRMLS_C);
	Register_TElPKCS11CryptoContext(TSRMLS_C);
	Register_TElPKCS11ECParamsDirectory(TSRMLS_C);
	Register_SBCryptoProvPKCS11_Enum_Flags(TSRMLS_C);

	// SBPKCS11Common unit class registration
	Register_TPKCS11FuncArray(TSRMLS_C);
	Register_SB_CK_SLOT_ID_ARRAY(TSRMLS_C);
	Register_SB_CK_OBJECT_HANDLE_ARRAY(TSRMLS_C);
	Register_TPKCS11Version(TSRMLS_C);
	Register_TPKCS11FunctionList(TSRMLS_C);
	Register_TPKCS11InitializeArgs(TSRMLS_C);
	Register_TPKCS11InitializeArgsNSS(TSRMLS_C);
	Register_TPKCS11Info(TSRMLS_C);
	Register_TPKCS11SlotInfo(TSRMLS_C);
	Register_TPKCS11TokenInfo(TSRMLS_C);
	Register_TPKCS11SessionInfo(TSRMLS_C);
	Register_TPKCS11Attribute(TSRMLS_C);
	Register_SB_CK_MECHANISM(TSRMLS_C);
	Register_TPKCS11MechanismInfo(TSRMLS_C);
	Register_SBPKCS11Common_Aliases(TSRMLS_C);

	// SBPKCS11Base unit class registration
	Register_TElPKCS11Module(TSRMLS_C);
	Register_TElPKCS11SlotInfo(TSRMLS_C);
	Register_TElPKCS11SessionInfo(TSRMLS_C);
	Register_TElPKCS11Consumer(TSRMLS_C);
	Register_TElPKCS11AttributeList(TSRMLS_C);
	Register_TElPKCS11Object(TSRMLS_C);
	Register_TElPKCS11DataObject(TSRMLS_C);
	Register_TElPKCS11CertificateObject(TSRMLS_C);
	Register_TElPKCS11X509CertificateObject(TSRMLS_C);
	Register_TElPKCS11WTLSCertificateObject(TSRMLS_C);
	Register_TElPKCS11X509AttributeCertificateObject(TSRMLS_C);
	Register_TElPKCS11KeyObject(TSRMLS_C);
	Register_TElPKCS11PublicKeyObject(TSRMLS_C);
	Register_TElPKCS11PrivateKeyObject(TSRMLS_C);
	Register_TElPKCS11SecretKeyObject(TSRMLS_C);
	Register_TElPKCS11DomainParametersObject(TSRMLS_C);
	Register_TElPKCS11Utils(TSRMLS_C);
	Register_TElPKCS11NSSParams(TSRMLS_C);
	Register_TElPKCS11ModuleList(TSRMLS_C);
	Register_TElPKCS11AlgorithmInfo(TSRMLS_C);
	Register_TElPKCS11AlgorithmConverter(TSRMLS_C);
	Register_TElSlotEventMonitoringThread(TSRMLS_C);
	Register_TElAttributes(TSRMLS_C);
	Register_SBPKCS11Base_Enum_Flags(TSRMLS_C);
	Register_SBPKCS11Base_Aliases(TSRMLS_C);

	// SBPKCS11Manager unit class registration
	Register_TElPKCS11Manager(TSRMLS_C);
	Register_TElPKCS11ManagerObject(TSRMLS_C);
	Register_TElPKCS11ManagerDataObject(TSRMLS_C);
	Register_TElPKCS11ManagerCertificateObject(TSRMLS_C);
	Register_TElPKCS11ManagerKeyObject(TSRMLS_C);
	Register_TElPKCS11ManagerPublicKeyObject(TSRMLS_C);
	Register_TElPKCS11ManagerPrivateKeyObject(TSRMLS_C);
	Register_TElPKCS11ManagerSecretKeyObject(TSRMLS_C);
	Register_TElPKCS11ConsumerManager(TSRMLS_C);
	Register_SBPKCS11Manager_Aliases(TSRMLS_C);

	// SBPKCS11CertStorage unit class registration
	Register_TElPKCS11CertStorage(TSRMLS_C);
	Register_TElPKCS11StgCtx(TSRMLS_C);
	Register_TElPKCS11ConsumerCertStorage(TSRMLS_C);
	Register_SBPKCS11CertStorage_Enum_Flags(TSRMLS_C);
	Register_SBPKCS11CertStorage_Aliases(TSRMLS_C);

	// SBPKCS10 unit class registration
	Register_TElCertificateRequest(TSRMLS_C);
	Register_SBPKCS10_Enum_Flags(TSRMLS_C);
	Register_SBPKCS10_Aliases(TSRMLS_C);

	// SBOCSPServer unit class registration
	Register_TElOCSPServer(TSRMLS_C);
	Register_SBOCSPServer_Enum_Flags(TSRMLS_C);
	Register_SBOCSPServer_Aliases(TSRMLS_C);

	// SBTSPServer unit class registration
	Register_TElServerTSPInfo(TSRMLS_C);
	Register_TElCustomTSPServer(TSRMLS_C);
	Register_TElFileTSPServer(TSRMLS_C);
	Register_SBTSPServer_Aliases(TSRMLS_C);

	// SBAuthenticode unit class registration
	Register_TElAuthenticodeChecksum(TSRMLS_C);
	Register_TElAuthenticodeManager(TSRMLS_C);
	Register_TElAuthenticodeSignature(TSRMLS_C);
	Register_TElAuthenticodeTimestamp(TSRMLS_C);
	Register_SBAuthenticode_Enum_Flags(TSRMLS_C);
	Register_SBAuthenticode_Aliases(TSRMLS_C);

	// SBCRLEx unit class registration
	Register_TElCertificateRevocationListEx(TSRMLS_C);

	// SBX509Ex unit class registration
	Register_TElX509CertificateEx(TSRMLS_C);

	// SBSSHPKCS11KeyStorage unit class registration
	Register_TElSSHPKCS11KeyStorage(TSRMLS_C);
	Register_TElSSHPKCS11ConsumerKeyStorage(TSRMLS_C);
	Register_TElPKCS11SSHKey(TSRMLS_C);

	// SBCAdES unit class registration
	Register_TElCAdESRevocationInfo(TSRMLS_C);
	Register_TElCAdESSignatureProcessor(TSRMLS_C);
	Register_SBCAdES_Enum_Flags(TSRMLS_C);

	// SBCMC unit class registration
	Register_TElAttributeValue(TSRMLS_C);
	Register_TElTaggedAttribute(TSRMLS_C);
	Register_TElTaggedCertificationRequest(TSRMLS_C);
	Register_TElExternallyDefinedCertificationRequest(TSRMLS_C);
	Register_TElTaggedRequest(TSRMLS_C);
	Register_TElContentInfo(TSRMLS_C);
	Register_TElTaggedContentInfo(TSRMLS_C);
	Register_TElOtherMsg(TSRMLS_C);
	Register_TElPKIData(TSRMLS_C);
	Register_TElPKIResponse(TSRMLS_C);
	Register_TElControlAttribute(TSRMLS_C);
	Register_TElIdentificationAttribute(TSRMLS_C);
	Register_TElPendInfo(TSRMLS_C);
	Register_TElCMCStatusInfoAttribute(TSRMLS_C);
	Register_TElBodyPartReference(TSRMLS_C);
	Register_TElBodyPartID(TSRMLS_C);
	Register_TElBodyPartPath(TSRMLS_C);
	Register_TElExtendedFailInfo(TSRMLS_C);
	Register_TElCMCStatusInfoV2Attribute(TSRMLS_C);
	Register_TElAddExtensionsAttribute(TSRMLS_C);
	Register_TElIdentityProofV2Attribute(TSRMLS_C);
	Register_TElIdentityProofAttribute(TSRMLS_C);
	Register_TElPopLinkWitnessV2Attribute(TSRMLS_C);
	Register_TElPopLinkWitnessAttribute(TSRMLS_C);
	Register_TElDataReturnAttribute(TSRMLS_C);
	Register_TElTransactionIdentifierAttribute(TSRMLS_C);
	Register_TElSenderNonceAttribute(TSRMLS_C);
	Register_TElRecipientNonceAttribute(TSRMLS_C);
	Register_TElEncryptedPopAttribute(TSRMLS_C);
	Register_TElDecryptedPopAttribute(TSRMLS_C);
	Register_TElLraPopWitnessAttribute(TSRMLS_C);
	Register_TElGetCertificateAttribute(TSRMLS_C);
	Register_TElGetCRLAttribute(TSRMLS_C);
	Register_TElRevocationRequestAttribute(TSRMLS_C);
	Register_TElRegistrationInformationAttribute(TSRMLS_C);
	Register_TElResponseInformationAttribute(TSRMLS_C);
	Register_TElQueryPendingAttribute(TSRMLS_C);
	Register_TElConfirmCertAcceptanceAttribute(TSRMLS_C);
	Register_TElPublishTrustAnchorsAttribute(TSRMLS_C);
	Register_TElAuthenticatedDataAttribute(TSRMLS_C);
	Register_TElBatchRequestsAttribute(TSRMLS_C);
	Register_TElBatchResponsesAttribute(TSRMLS_C);
	Register_TElPopLinkRandomAttribute(TSRMLS_C);
	Register_TElSinglePubInfo(TSRMLS_C);
	Register_TElPKIPublicationInfo(TSRMLS_C);
	Register_TElPublicationInformationAttribute(TSRMLS_C);
	Register_TElControlProcessedAttribute(TSRMLS_C);
	Register_TElOptionalValidity(TSRMLS_C);
	Register_TElPublicKeyInfo(TSRMLS_C);
	Register_TElCertTemplate(TSRMLS_C);
	Register_TElModCertificationRequestAttribute(TSRMLS_C);
	Register_TElFullPKIRequest(TSRMLS_C);
	Register_TElFullPKIResponse(TSRMLS_C);
	Register_SBCMC_Enum_Flags(TSRMLS_C);
	Register_SBCMC_Aliases(TSRMLS_C);

	// SBOTPCommon unit class registration
	Register_TElOTPClass(TSRMLS_C);
	Register_TElHOTPPasswordGenerator(TSRMLS_C);
	Register_TElTOTPPasswordGenerator(TSRMLS_C);
	Register_SBOTPCommon_Aliases(TSRMLS_C);

	// SBOTPClient unit class registration
	Register_TElOTPClient(TSRMLS_C);
	Register_TElHOTPClient(TSRMLS_C);
	Register_TElTOTPClient(TSRMLS_C);
	Register_SBOTPClient_Aliases(TSRMLS_C);

	// SBOTPServer unit class registration
	Register_TElOTPUser(TSRMLS_C);
	Register_TElHOTPUser(TSRMLS_C);
	Register_TElTOTPUser(TSRMLS_C);
	Register_TElOTPUserFactory(TSRMLS_C);
	Register_TElOTPUserStorage(TSRMLS_C);
	Register_TElOTPServer(TSRMLS_C);
	Register_TElHOTPServer(TSRMLS_C);
	Register_TElTOTPServer(TSRMLS_C);
	Register_SBOTPServer_Aliases(TSRMLS_C);

	// SBECIESCrypto unit class registration
	Register_TElECIESCrypto(TSRMLS_C);
	Register_SBECIESCrypto_Enum_Flags(TSRMLS_C);
	Register_SBECIESCrypto_Aliases(TSRMLS_C);

	// SBJWCrypto unit class registration
	Register_TElJWToken(TSRMLS_C);
	Register_TElJWKey(TSRMLS_C);
	Register_TElJWKeySet(TSRMLS_C);
	Register_TElJWCryptoBase(TSRMLS_C);
	Register_TElJWTokenClaims(TSRMLS_C);
	Register_TElJWSignature(TSRMLS_C);
	Register_TElJWEncryption(TSRMLS_C);
	Register_SBJWCrypto_Enum_Flags(TSRMLS_C);

	// SBUniversalCertStorageEx unit class registration
	Register_TElUniversalCertStorageEx(TSRMLS_C);

	// SBAttrCertEx unit class registration
	Register_TElAttributeCertificateEx(TSRMLS_C);

	// SBHID unit class registration
	Register_TElHIDDeviceInfo(TSRMLS_C);
	Register_TElHIDDeviceInfoList(TSRMLS_C);
	Register_TElHIDDevice(TSRMLS_C);
	Register_SBHID_Aliases(TSRMLS_C);

#else
	// SBPGPMIME unit class registration
	Register_TElMessagePartHandlerPGPMime(TSRMLS_C);
	Register_TElMessagePartHandlerPGPKeys(TSRMLS_C);
	Register_TElSimplePGPMIMEOptions(TSRMLS_C);
	Register_TElSimplePGPMIMEMessage(TSRMLS_C);
	Register_SBPGPMIME_Enum_Flags(TSRMLS_C);
	Register_SBPGPMIME_Aliases(TSRMLS_C);

	// SBPGPSSH unit class registration
	Register_TElSSHPGPKey(TSRMLS_C);
	Register_TElSSHPGPAuthHandler(TSRMLS_C);
	Register_SBPGPSSH_Aliases(TSRMLS_C);

	// SBPGPTLS unit class registration
	Register_TElSSLPGPCertificateTypeHandler(TSRMLS_C);
	Register_TElSSLClientPGPCertificateTypeHandler(TSRMLS_C);
	Register_TElSSLServerPGPCertificateTypeHandler(TSRMLS_C);
	Register_SBPGPTLS_Enum_Flags(TSRMLS_C);

	// SBCMS unit class registration
	Register_TElASN1DirectoryString(TSRMLS_C);
	Register_TElCMSProperty(TSRMLS_C);
	Register_TElCMSHash(TSRMLS_C);
	Register_TElCMSSignerIdentifier(TSRMLS_C);
	Register_TElCMSCertificateRefs(TSRMLS_C);
	Register_TElCMSCRLIdentifier(TSRMLS_C);
	Register_TElCMSCRLValidatedID(TSRMLS_C);
	Register_TElCMSOCSPIdentifier(TSRMLS_C);
	Register_TElCMSOCSPResponsesID(TSRMLS_C);
	Register_TElCMSRevocationRef(TSRMLS_C);
	Register_TElCMSRevocationRefs(TSRMLS_C);
	Register_TElCMSRevocationValues(TSRMLS_C);
	Register_TElCMSContent(TSRMLS_C);
	Register_TElCMSSigPolicyQualifier(TSRMLS_C);
	Register_TElCMSSignaturePolicy(TSRMLS_C);
	Register_TElCMSContentHints(TSRMLS_C);
	Register_TElCMSContentReference(TSRMLS_C);
	Register_TElCMSCommitmentTypeIndication(TSRMLS_C);
	Register_TElCMSSignerLocation(TSRMLS_C);
	Register_TElCMSSigningCertificate(TSRMLS_C);
	Register_TElCMSSignerAttributes(TSRMLS_C);
	Register_TElCMSSignaturePolicyStore(TSRMLS_C);
	Register_TElCMSSignature(TSRMLS_C);
	Register_TElCMSTimestamp(TSRMLS_C);
	Register_TElATSHashIndexProcessor(TSRMLS_C);
	Register_TElCMSMessage(TSRMLS_C);
	Register_TElCMSContentHash(TSRMLS_C);
	Register_TElSignedCMSMessage(TSRMLS_C);
	Register_TElSignedAndEnvelopedCMSMessage(TSRMLS_C);
	Register_SBCMS_Enum_Flags(TSRMLS_C);

	// SBCryptoProvPKCS11 unit class registration
	Register_TElPKCS11CryptoProviderOptions(TSRMLS_C);
	Register_TElPKCS11CryptoProvider(TSRMLS_C);
	Register_TElPKCS11CryptoKeyContainer(TSRMLS_C);
	Register_TElPKCS11CryptoObject(TSRMLS_C);
	Register_TElPKCS11CryptoKey(TSRMLS_C);
	Register_TElPKCS11CryptoContext(TSRMLS_C);
	Register_TElPKCS11ECParamsDirectory(TSRMLS_C);
	Register_SBCryptoProvPKCS11_Enum_Flags(TSRMLS_C);

	// SBPKCS11Common unit class registration
	Register_TPKCS11FuncArray(TSRMLS_C);
	Register_SB_CK_SLOT_ID_ARRAY(TSRMLS_C);
	Register_SB_CK_OBJECT_HANDLE_ARRAY(TSRMLS_C);
	Register_TPKCS11Version(TSRMLS_C);
	Register_TPKCS11FunctionList(TSRMLS_C);
	Register_TPKCS11InitializeArgs(TSRMLS_C);
	Register_TPKCS11InitializeArgsNSS(TSRMLS_C);
	Register_TPKCS11Info(TSRMLS_C);
	Register_TPKCS11SlotInfo(TSRMLS_C);
	Register_TPKCS11TokenInfo(TSRMLS_C);
	Register_TPKCS11SessionInfo(TSRMLS_C);
	Register_TPKCS11Attribute(TSRMLS_C);
	Register_SB_CK_MECHANISM(TSRMLS_C);
	Register_TPKCS11MechanismInfo(TSRMLS_C);
	Register_SBPKCS11Common_Aliases(TSRMLS_C);

	// SBPKCS11Base unit class registration
	Register_TElPKCS11Module(TSRMLS_C);
	Register_TElPKCS11SlotInfo(TSRMLS_C);
	Register_TElPKCS11SessionInfo(TSRMLS_C);
	Register_TElPKCS11Consumer(TSRMLS_C);
	Register_TElPKCS11AttributeList(TSRMLS_C);
	Register_TElPKCS11Object(TSRMLS_C);
	Register_TElPKCS11DataObject(TSRMLS_C);
	Register_TElPKCS11CertificateObject(TSRMLS_C);
	Register_TElPKCS11X509CertificateObject(TSRMLS_C);
	Register_TElPKCS11WTLSCertificateObject(TSRMLS_C);
	Register_TElPKCS11X509AttributeCertificateObject(TSRMLS_C);
	Register_TElPKCS11KeyObject(TSRMLS_C);
	Register_TElPKCS11PublicKeyObject(TSRMLS_C);
	Register_TElPKCS11PrivateKeyObject(TSRMLS_C);
	Register_TElPKCS11SecretKeyObject(TSRMLS_C);
	Register_TElPKCS11DomainParametersObject(TSRMLS_C);
	Register_TElPKCS11Utils(TSRMLS_C);
	Register_TElPKCS11NSSParams(TSRMLS_C);
	Register_TElPKCS11ModuleList(TSRMLS_C);
	Register_TElPKCS11AlgorithmInfo(TSRMLS_C);
	Register_TElPKCS11AlgorithmConverter(TSRMLS_C);
	Register_TElSlotEventMonitoringThread(TSRMLS_C);
	Register_TElAttributes(TSRMLS_C);
	Register_SBPKCS11Base_Enum_Flags(TSRMLS_C);
	Register_SBPKCS11Base_Aliases(TSRMLS_C);

	// SBPKCS11Manager unit class registration
	Register_TElPKCS11Manager(TSRMLS_C);
	Register_TElPKCS11ManagerObject(TSRMLS_C);
	Register_TElPKCS11ManagerDataObject(TSRMLS_C);
	Register_TElPKCS11ManagerCertificateObject(TSRMLS_C);
	Register_TElPKCS11ManagerKeyObject(TSRMLS_C);
	Register_TElPKCS11ManagerPublicKeyObject(TSRMLS_C);
	Register_TElPKCS11ManagerPrivateKeyObject(TSRMLS_C);
	Register_TElPKCS11ManagerSecretKeyObject(TSRMLS_C);
	Register_TElPKCS11ConsumerManager(TSRMLS_C);
	Register_SBPKCS11Manager_Aliases(TSRMLS_C);

	// SBPKCS11CertStorage unit class registration
	Register_TElPKCS11CertStorage(TSRMLS_C);
	Register_TElPKCS11StgCtx(TSRMLS_C);
	Register_TElPKCS11ConsumerCertStorage(TSRMLS_C);
	Register_SBPKCS11CertStorage_Enum_Flags(TSRMLS_C);
	Register_SBPKCS11CertStorage_Aliases(TSRMLS_C);

	// SBPKCS10 unit class registration
	Register_TElCertificateRequest(TSRMLS_C);
	Register_SBPKCS10_Enum_Flags(TSRMLS_C);
	Register_SBPKCS10_Aliases(TSRMLS_C);

	// SBOCSPServer unit class registration
	Register_TElOCSPServer(TSRMLS_C);
	Register_SBOCSPServer_Enum_Flags(TSRMLS_C);
	Register_SBOCSPServer_Aliases(TSRMLS_C);

	// SBTSPServer unit class registration
	Register_TElServerTSPInfo(TSRMLS_C);
	Register_TElCustomTSPServer(TSRMLS_C);
	Register_TElFileTSPServer(TSRMLS_C);
	Register_SBTSPServer_Aliases(TSRMLS_C);

	// SBAuthenticode unit class registration
	Register_TElAuthenticodeChecksum(TSRMLS_C);
	Register_TElAuthenticodeManager(TSRMLS_C);
	Register_TElAuthenticodeSignature(TSRMLS_C);
	Register_TElAuthenticodeTimestamp(TSRMLS_C);
	Register_SBAuthenticode_Enum_Flags(TSRMLS_C);
	Register_SBAuthenticode_Aliases(TSRMLS_C);

	// SBCRLEx unit class registration
	Register_TElCertificateRevocationListEx(TSRMLS_C);

	// SBX509Ex unit class registration
	Register_TElX509CertificateEx(TSRMLS_C);

	// SBSSHPKCS11KeyStorage unit class registration
	Register_TElSSHPKCS11KeyStorage(TSRMLS_C);
	Register_TElSSHPKCS11ConsumerKeyStorage(TSRMLS_C);
	Register_TElPKCS11SSHKey(TSRMLS_C);

	// SBCAdES unit class registration
	Register_TElCAdESRevocationInfo(TSRMLS_C);
	Register_TElCAdESSignatureProcessor(TSRMLS_C);
	Register_SBCAdES_Enum_Flags(TSRMLS_C);

	// SBCMC unit class registration
	Register_TElAttributeValue(TSRMLS_C);
	Register_TElTaggedAttribute(TSRMLS_C);
	Register_TElTaggedCertificationRequest(TSRMLS_C);
	Register_TElExternallyDefinedCertificationRequest(TSRMLS_C);
	Register_TElTaggedRequest(TSRMLS_C);
	Register_TElContentInfo(TSRMLS_C);
	Register_TElTaggedContentInfo(TSRMLS_C);
	Register_TElOtherMsg(TSRMLS_C);
	Register_TElPKIData(TSRMLS_C);
	Register_TElPKIResponse(TSRMLS_C);
	Register_TElControlAttribute(TSRMLS_C);
	Register_TElIdentificationAttribute(TSRMLS_C);
	Register_TElPendInfo(TSRMLS_C);
	Register_TElCMCStatusInfoAttribute(TSRMLS_C);
	Register_TElBodyPartReference(TSRMLS_C);
	Register_TElBodyPartID(TSRMLS_C);
	Register_TElBodyPartPath(TSRMLS_C);
	Register_TElExtendedFailInfo(TSRMLS_C);
	Register_TElCMCStatusInfoV2Attribute(TSRMLS_C);
	Register_TElAddExtensionsAttribute(TSRMLS_C);
	Register_TElIdentityProofV2Attribute(TSRMLS_C);
	Register_TElIdentityProofAttribute(TSRMLS_C);
	Register_TElPopLinkWitnessV2Attribute(TSRMLS_C);
	Register_TElPopLinkWitnessAttribute(TSRMLS_C);
	Register_TElDataReturnAttribute(TSRMLS_C);
	Register_TElTransactionIdentifierAttribute(TSRMLS_C);
	Register_TElSenderNonceAttribute(TSRMLS_C);
	Register_TElRecipientNonceAttribute(TSRMLS_C);
	Register_TElEncryptedPopAttribute(TSRMLS_C);
	Register_TElDecryptedPopAttribute(TSRMLS_C);
	Register_TElLraPopWitnessAttribute(TSRMLS_C);
	Register_TElGetCertificateAttribute(TSRMLS_C);
	Register_TElGetCRLAttribute(TSRMLS_C);
	Register_TElRevocationRequestAttribute(TSRMLS_C);
	Register_TElRegistrationInformationAttribute(TSRMLS_C);
	Register_TElResponseInformationAttribute(TSRMLS_C);
	Register_TElQueryPendingAttribute(TSRMLS_C);
	Register_TElConfirmCertAcceptanceAttribute(TSRMLS_C);
	Register_TElPublishTrustAnchorsAttribute(TSRMLS_C);
	Register_TElAuthenticatedDataAttribute(TSRMLS_C);
	Register_TElBatchRequestsAttribute(TSRMLS_C);
	Register_TElBatchResponsesAttribute(TSRMLS_C);
	Register_TElPopLinkRandomAttribute(TSRMLS_C);
	Register_TElSinglePubInfo(TSRMLS_C);
	Register_TElPKIPublicationInfo(TSRMLS_C);
	Register_TElPublicationInformationAttribute(TSRMLS_C);
	Register_TElControlProcessedAttribute(TSRMLS_C);
	Register_TElOptionalValidity(TSRMLS_C);
	Register_TElPublicKeyInfo(TSRMLS_C);
	Register_TElCertTemplate(TSRMLS_C);
	Register_TElModCertificationRequestAttribute(TSRMLS_C);
	Register_TElFullPKIRequest(TSRMLS_C);
	Register_TElFullPKIResponse(TSRMLS_C);
	Register_SBCMC_Enum_Flags(TSRMLS_C);
	Register_SBCMC_Aliases(TSRMLS_C);

	// SBOTPCommon unit class registration
	Register_TElOTPClass(TSRMLS_C);
	Register_TElHOTPPasswordGenerator(TSRMLS_C);
	Register_TElTOTPPasswordGenerator(TSRMLS_C);
	Register_SBOTPCommon_Aliases(TSRMLS_C);

	// SBOTPClient unit class registration
	Register_TElOTPClient(TSRMLS_C);
	Register_TElHOTPClient(TSRMLS_C);
	Register_TElTOTPClient(TSRMLS_C);
	Register_SBOTPClient_Aliases(TSRMLS_C);

	// SBOTPServer unit class registration
	Register_TElOTPUser(TSRMLS_C);
	Register_TElHOTPUser(TSRMLS_C);
	Register_TElTOTPUser(TSRMLS_C);
	Register_TElOTPUserFactory(TSRMLS_C);
	Register_TElOTPUserStorage(TSRMLS_C);
	Register_TElOTPServer(TSRMLS_C);
	Register_TElHOTPServer(TSRMLS_C);
	Register_TElTOTPServer(TSRMLS_C);
	Register_SBOTPServer_Aliases(TSRMLS_C);

	// SBECIESCrypto unit class registration
	Register_TElECIESCrypto(TSRMLS_C);
	Register_SBECIESCrypto_Enum_Flags(TSRMLS_C);
	Register_SBECIESCrypto_Aliases(TSRMLS_C);

	// SBJWCrypto unit class registration
	Register_TElJWToken(TSRMLS_C);
	Register_TElJWKey(TSRMLS_C);
	Register_TElJWKeySet(TSRMLS_C);
	Register_TElJWCryptoBase(TSRMLS_C);
	Register_TElJWTokenClaims(TSRMLS_C);
	Register_TElJWSignature(TSRMLS_C);
	Register_TElJWEncryption(TSRMLS_C);
	Register_SBJWCrypto_Enum_Flags(TSRMLS_C);

	// SBUniversalCertStorageEx unit class registration
	Register_TElUniversalCertStorageEx(TSRMLS_C);

	// SBAttrCertEx unit class registration
	Register_TElAttributeCertificateEx(TSRMLS_C);

	// SBHID unit class registration
	Register_TElHIDDeviceInfo(TSRMLS_C);
	Register_TElHIDDeviceInfoList(TSRMLS_C);
	Register_TElHIDDevice(TSRMLS_C);
	Register_SBHID_Aliases(TSRMLS_C);

#ifdef LINUX
	// SBHIDLinux unit class registration
	Register_SBHIDLinux_Enum_Flags(TSRMLS_C);
#endif
#endif

	// SBU2FCommon unit class registration
	Register_TElU2FUsers(TSRMLS_C);
	Register_TElU2FUserKey(TSRMLS_C);
	Register_TElU2FUserKeys(TSRMLS_C);
	Register_TElU2FUser(TSRMLS_C);
	Register_TElU2FJSRegisterRequest(TSRMLS_C);
	Register_TElU2FJSRegisterRequests(TSRMLS_C);
	Register_TElU2FJSSignRequest(TSRMLS_C);
	Register_TElU2FJwkKey(TSRMLS_C);
	Register_SBU2FCommon_Enum_Flags(TSRMLS_C);

	// SBU2FClient unit class registration
	Register_TElU2FDevice(TSRMLS_C);
	Register_TElU2FHIDDevice(TSRMLS_C);
	Register_TElU2FClient(TSRMLS_C);

	// SBU2FServer unit class registration
	Register_TElU2FServer(TSRMLS_C);
	Register_SBU2FServer_Aliases(TSRMLS_C);

	// SBCryptoProvCard unit class registration
	Register_TElSmartCardCryptoKeyContainer(TSRMLS_C);
	Register_TElSmartCardCryptoKey(TSRMLS_C);
	Register_TElSmartCardCryptoObject(TSRMLS_C);
	Register_TElSmartCardCryptoContext(TSRMLS_C);
	Register_TElSmartCardCryptoProviderOptions(TSRMLS_C);
	Register_TElSmartCardCryptoProvider(TSRMLS_C);
	Register_SBCryptoProvCard_Enum_Flags(TSRMLS_C);

#ifdef SB_WINDOWS
	// SBCryptoProvCardPIV unit class registration
	Register_TElPIVCardCryptoProviderOptions(TSRMLS_C);
	Register_TElPIVCardCryptoProvider(TSRMLS_C);
	Register_TElPIVCardCryptoKeyContainer(TSRMLS_C);
	Register_TElPIVCardCryptoContext(TSRMLS_C);
	Register_TElPIVCardCryptoKey(TSRMLS_C);
	Register_TElPIVCardCryptoObject(TSRMLS_C);
#endif

	// SBCardCommon unit class registration
	Register_TElSmartCardObject(TSRMLS_C);
	Register_SBCardCommon_Enum_Flags(TSRMLS_C);

#ifdef SB_WINDOWS
	// SBCardManager unit class registration
	Register_TElCryptoCardManager(TSRMLS_C);
	Register_TElCryptoCardReader(TSRMLS_C);

	// SBSCWin unit class registration
	Register_SCARD_IO_REQUEST(TSRMLS_C);
	Register_SCARD_READERSTATE(TSRMLS_C);
	Register_SBSCWin_Aliases(TSRMLS_C);
#endif

	// SBSftp unit class registration
	Register_TElSftpStream(TSRMLS_C);
	Register_TElSftpClient(TSRMLS_C);
	Register_SBSftp_Aliases(TSRMLS_C);

	// SBSftpCommon unit class registration
	Register_TSBSftpRequestInfo(TSRMLS_C);
	Register_TSBSftpDataRequestInfo(TSRMLS_C);
	Register_TSBSftpExtendedAttribute(TSRMLS_C);
	Register_TElSftpExtendedReply(TSRMLS_C);
	Register_TElSftpNewlineExtension(TSRMLS_C);
	Register_TElSftpVersionsExtension(TSRMLS_C);
	Register_TElSftpFilenameTranslationExtension(TSRMLS_C);
	Register_TElSftpFilenameCharsetExtension(TSRMLS_C);
	Register_TElSftpVersionSelectExtension(TSRMLS_C);
	Register_TElSftpSupportedExtension(TSRMLS_C);
	Register_TElSftpVendorIDExtension(TSRMLS_C);
	Register_TElSftpCheckFileExtension(TSRMLS_C);
	Register_TElSftpStatvfsExtension(TSRMLS_C);
	Register_TElSftpSpaceAvailableExtension(TSRMLS_C);
	Register_TElSftpHomeDirectoryExtension(TSRMLS_C);
	Register_TElSftpCopyFileExtension(TSRMLS_C);
	Register_TElSftpCopyDataExtension(TSRMLS_C);
	Register_TElSftpCheckFileReply(TSRMLS_C);
	Register_TElSftpSpaceAvailableReply(TSRMLS_C);
	Register_TElSftpStatVFSReply(TSRMLS_C);
	Register_TSBSftpACE(TSRMLS_C);
	Register_TElSftpExtendedProperties(TSRMLS_C);
	Register_TElSftpFileAttributes(TSRMLS_C);
	Register_TElSftpFileInfo(TSRMLS_C);
	Register_TSBSftpOpenRequestInfo(TSRMLS_C);
	Register_TSBSftpTextHandleInfo(TSRMLS_C);
	Register_TElSftpTransferBlock(TSRMLS_C);
	Register_TElSftpTransferManager(TSRMLS_C);
	Register_TElSftpRemovalTarget(TSRMLS_C);
	Register_TElSftpRemovalManager(TSRMLS_C);
	Register_SBSftpCommon_Enum_Flags(TSRMLS_C);
	Register_SBSftpCommon_Aliases(TSRMLS_C);

	// SBSimpleSftp unit class registration
	Register_TElSimpleSFTPClient(TSRMLS_C);
	Register_SBSimpleSftp_Aliases(TSRMLS_C);

	// SBSftpHandler unit class registration
	Register_TElSFTPSSHSubsystemHandler(TSRMLS_C);
	Register_SBSftpHandler_Aliases(TSRMLS_C);

	// SBSftpServer unit class registration
	Register_TSBSftpHandle(TSRMLS_C);
	Register_TElSFTPServer(TSRMLS_C);
	Register_SBSftpServer_Aliases(TSRMLS_C);

	// SBSimpleSFTPServer unit class registration
	Register_TElSimpleSFTPServer(TSRMLS_C);
	Register_TElSimpleSSHsftpSearchRec(TSRMLS_C);
	Register_TElSimpleSFTPServerSessionThread(TSRMLS_C);

	// SBSMIMECore unit class registration
	Register_TElMessagePartHandlerSMime(TSRMLS_C);
	Register_TElSimpleSMIMEMessage(TSRMLS_C);
	Register_TElSimpleSMIMEOptions(TSRMLS_C);
	Register_SBSMIMECore_Enum_Flags(TSRMLS_C);
	Register_SBSMIMECore_Aliases(TSRMLS_C);

	// SBSMIMECAdES unit class registration
	Register_TElMessagePartHandlerSMimeCAdES(TSRMLS_C);

	// SBSSHKeyStorage unit class registration
	Register_TElSSHKey(TSRMLS_C);
	Register_TElSSHCustomKeyStorage(TSRMLS_C);
	Register_TElSSHMemoryKeyStorage(TSRMLS_C);
	Register_SBSSHKeyStorage_Enum_Flags(TSRMLS_C);
	Register_SBSSHKeyStorage_Aliases(TSRMLS_C);

	// SBSSHTerm unit class registration
	Register_TSBChangeNotification(TSRMLS_C);
	Register_TElTerminalInfo(TSRMLS_C);
	Register_SBSSHTerm_Aliases(TSRMLS_C);

	// SBSSHClient unit class registration
	Register_TElSSHClient(TSRMLS_C);
	Register_TElSSHClientTunnelList(TSRMLS_C);
	Register_TElSSHClientTunnelConnection(TSRMLS_C);
	Register_SBSSHClient_Enum_Flags(TSRMLS_C);
	Register_SBSSHClient_Aliases(TSRMLS_C);

	// SBSSHCommon unit class registration
	Register_TDHParams(TSRMLS_C);
	Register_TECDHParams(TSRMLS_C);
	Register_TC25519Params(TSRMLS_C);
	Register_TC448Params(TSRMLS_C);
	Register_TRSAParams(TSRMLS_C);
	Register_THandshakeParams(TSRMLS_C);
	Register_TSSH1Params(TSRMLS_C);
	Register_TSSH2Params(TSRMLS_C);
	Register_TElSSHClass(TSRMLS_C);
	Register_TElSSHTunnelList(TSRMLS_C);
	Register_TElCustomSSHTunnel(TSRMLS_C);
	Register_TElSSHTunnelConnection(TSRMLS_C);
	Register_TElCustomSSHTunnelParams(TSRMLS_C);
	Register_TElShellSSHTunnel(TSRMLS_C);
	Register_TElCommandSSHTunnel(TSRMLS_C);
	Register_TElSubsystemSSHTunnel(TSRMLS_C);
	Register_TElRemotePortForwardSSHTunnel(TSRMLS_C);
	Register_TElLocalPortForwardSSHTunnel(TSRMLS_C);
	Register_TElLocalPortForwardSSHTunnelParams(TSRMLS_C);
	Register_TElX11ForwardSSHTunnel(TSRMLS_C);
	Register_TElAuthenticationAgentSSHTunnel(TSRMLS_C);
	Register_TElSSHAuthHandler(TSRMLS_C);
	Register_SBSSHCommon_Enum_Flags(TSRMLS_C);
	Register_SBSSHCommon_Aliases(TSRMLS_C);

	// SBSimpleSSH unit class registration
	Register_TElSimpleSSHClient(TSRMLS_C);
	Register_SBSimpleSSH_Aliases(TSRMLS_C);

	// SBSSHForwarding unit class registration
	Register_TElSSHForwardedConnection(TSRMLS_C);
	Register_TElSSHForwardingTunnel(TSRMLS_C);
	Register_TElSSHForwardingSession(TSRMLS_C);
	Register_TElSSHCustomForwarding(TSRMLS_C);
	Register_TElSSHForwardingIntercept(TSRMLS_C);
	Register_TElSSHLocalPortForwarding(TSRMLS_C);
	Register_TElSSHRemotePortForwarding(TSRMLS_C);
	Register_TElSSHTunnelState(TSRMLS_C);
	Register_TElSSHLPFListeningThread(TSRMLS_C);
	Register_TElSSHLocalTunnelState(TSRMLS_C);
	Register_TElSSHRemoteTunnelState(TSRMLS_C);
	Register_TElSSHLocalPortForwardingSession(TSRMLS_C);
	Register_TElSSHRemotePortForwardingSession(TSRMLS_C);
	Register_TElSSHScheduledSpecialMessage(TSRMLS_C);
	Register_SBSSHForwarding_Enum_Flags(TSRMLS_C);
	Register_SBSSHForwarding_Aliases(TSRMLS_C);

	// SBSSHPubKeyCommon unit class registration
	Register_TElSSHPublicKeyAttributes(TSRMLS_C);
	Register_SBSSHPubKeyCommon_Aliases(TSRMLS_C);

	// SBSSHPubKeyClient unit class registration
	Register_TElSSHPublicKeyClient(TSRMLS_C);
	Register_SBSSHPubKeyClient_Aliases(TSRMLS_C);

	// SBSSHAuthAgent unit class registration
	Register_TElSSHAuthAgentSSH2Key(TSRMLS_C);
	Register_TElSSHAuthAgent(TSRMLS_C);
#ifdef SB_WINDOWS
	Register_TElPageantAuthAgent(TSRMLS_C);
#endif
	Register_TElOpenSSHAuthAgent(TSRMLS_C);

	// SBSSHServer unit class registration
	Register_TElSSHUser(TSRMLS_C);
	Register_TElSSHServerTunnelConnection(TSRMLS_C);
	Register_TElSSHServerAdditionalSettings(TSRMLS_C);
	Register_TElSSHServer(TSRMLS_C);
	Register_SBSSHServer_Enum_Flags(TSRMLS_C);
	Register_SBSSHServer_Aliases(TSRMLS_C);

	// SBSSHHandlers unit class registration
	Register_TElCustomSSHSubsystemHandler(TSRMLS_C);
#ifdef SB_WINDOWS
	Register_TElShellSSHSubsystemHandler(TSRMLS_C);
#endif
	Register_TElCustomSocketForwardingSSHSubsystemHandler(TSRMLS_C);
	Register_TElSSHSubsystemThread(TSRMLS_C);
	Register_SBSSHHandlers_Enum_Flags(TSRMLS_C);
	Register_SBSSHHandlers_Aliases(TSRMLS_C);

	// SBSSHForwardingHandlers unit class registration
	Register_TElTCPForwardingSSHSubsystemHandler(TSRMLS_C);
	Register_TElClientTCPForwardingSSHSubsystemHandler(TSRMLS_C);
	Register_TElServerTCPForwardingSSHSubsystemHandler(TSRMLS_C);
	Register_TElBuiltinTCPForwardingSSHSubsystemHandler(TSRMLS_C);
	Register_TElBuiltinClientTCPForwardingSSHSubsystemHandler(TSRMLS_C);
	Register_TElBuiltinServerTCPForwardingSSHSubsystemHandler(TSRMLS_C);
	Register_SBSSHForwardingHandlers_Aliases(TSRMLS_C);

	// SBSSHConnectionHandler unit class registration
	Register_TElSSHConnectionHandler(TSRMLS_C);
	Register_SBSSHConnectionHandler_Aliases(TSRMLS_C);

	// SBSSHPubKeyServer unit class registration
	Register_TElSSHPublicKeyServer(TSRMLS_C);
	Register_SBSSHPubKeyServer_Aliases(TSRMLS_C);

	// SBSSHPubKeyHandler unit class registration
	Register_TElPublicKeySSHSubsystemHandler(TSRMLS_C);
	Register_SBSSHPubKeyHandler_Aliases(TSRMLS_C);

	// SBSimpleSSHServer unit class registration
	Register_TElSimpleSSHServer(TSRMLS_C);
	Register_TElSSHUsers(TSRMLS_C);
	Register_TElCustomSessionThread(TSRMLS_C);
	Register_TElSimpleSSHServerListeningThread(TSRMLS_C);
	Register_TElSimpleSSHServerSessionThread(TSRMLS_C);
	Register_TElSimpleSSHServerForwardingListeningThread(TSRMLS_C);
	Register_TElSimpleSSHServerForwardingSessionThread(TSRMLS_C);

	// SBSSLClient unit class registration
	Register_TSSL2CipherSuite(TSRMLS_C);
	Register_TSSL3CipherSuite(TSRMLS_C);
	Register_TClientCertificate(TSRMLS_C);
	Register_TElClientSSLConnectionInfo(TSRMLS_C);
	Register_TElSSLClient(TSRMLS_C);
	Register_TElClientSSLConnectionSettings(TSRMLS_C);
	Register_SBSSLClient_Enum_Flags(TSRMLS_C);
	Register_SBSSLClient_Aliases(TSRMLS_C);

	// SBSimpleSSL unit class registration
	Register_TElCustomSimpleSSLClient(TSRMLS_C);
	Register_TElSimpleSSLClient(TSRMLS_C);
	Register_SBSimpleSSL_Aliases(TSRMLS_C);

	// SBSSLCommon unit class registration
	Register_TElSSLCertificateTypeHandler(TSRMLS_C);
	Register_TElCustomSSLExtension(TSRMLS_C);
	Register_TElSSLClass(TSRMLS_C);
	Register_TElSSLConnectionInfo(TSRMLS_C);
	Register_TElSSLServerName(TSRMLS_C);
	Register_TElHeartbeatHelloSSLExtension(TSRMLS_C);
	Register_TElServerNameSSLExtension(TSRMLS_C);
	Register_TElUserNameSSLExtension(TSRMLS_C);
	Register_TElECCurveSSLExtension(TSRMLS_C);
	Register_TElECPointSSLExtension(TSRMLS_C);
	Register_TElCertificateTypeResponse(TSRMLS_C);
	Register_TElCertificateTypeRequest(TSRMLS_C);
	Register_TElExtendedMasterSecretExtension(TSRMLS_C);
	Register_TElMaxFragmentLengthSSLExtension(TSRMLS_C);
	Register_TElSSLCertURL(TSRMLS_C);
	Register_TElClientCertURLsSSLExtension(TSRMLS_C);
	Register_TElSSLTrustedCA(TSRMLS_C);
	Register_TElTrustedCAsSSLExtension(TSRMLS_C);
	Register_TElTruncatedHMACSSLExtension(TSRMLS_C);
	Register_TElSSLOCSPStatusRequest(TSRMLS_C);
	Register_TElCertificateStatusSSLExtension(TSRMLS_C);
	Register_TElSessionTicketSSLExtension(TSRMLS_C);
	Register_TElCertHashTypesSSLExtension(TSRMLS_C);
	Register_TElRenegotiationInfoSSLExtension(TSRMLS_C);
	Register_TElSignatureAlgorithmsSSLExtension(TSRMLS_C);
	Register_TElSRPSSLExtension(TSRMLS_C);
	Register_TElCustomSSLExtensions(TSRMLS_C);
	Register_TElClientSSLExtensions(TSRMLS_C);
	Register_TElServerSSLExtensions(TSRMLS_C);
	Register_TElSSLRetransmissionTimer(TSRMLS_C);
	Register_TElSSLX509CertificateTypeHandler(TSRMLS_C);
	Register_TElSSLRawKeyCertificateTypeHandler(TSRMLS_C);
	Register_TElDTLSFlightItem(TSRMLS_C);
	Register_SBSSLCommon_Enum_Flags(TSRMLS_C);
	Register_SBSSLCommon_Aliases(TSRMLS_C);

	// SBSSLConstants unit class registration
	Register_TSSLVersion(TSRMLS_C);
	Register_SBSSLConstants_Enum_Flags(TSRMLS_C);

	// SBCmdSSLClient unit class registration
	Register_TElCommandSSLClient(TSRMLS_C);
	Register_SBCmdSSLClient_Aliases(TSRMLS_C);

	// SBDTLSClient unit class registration
	Register_TElDTLSClient(TSRMLS_C);
	Register_SBDTLSClient_Aliases(TSRMLS_C);

	// SBSSLServer unit class registration
	Register_TSSLCipherSuite(TSRMLS_C);
	Register_TSSL2SecureParams(TSRMLS_C);
	Register_TSSL3SecureParams(TSRMLS_C);
	Register_TElServerSSLConnectionInfo(TSRMLS_C);
	Register_TElSSLServer(TSRMLS_C);
	Register_TElSSLServerEnvironment(TSRMLS_C);
	Register_SBSSLServer_Enum_Flags(TSRMLS_C);
	Register_SBSSLServer_Aliases(TSRMLS_C);

	// SBSessionPool unit class registration
	Register_TSBSessionContext(TSRMLS_C);
	Register_TElSessionPool(TSRMLS_C);
	Register_SBSessionPool_Aliases(TSRMLS_C);

	// SBDTLSServer unit class registration
	Register_TElDTLSServer(TSRMLS_C);
	Register_TElDTLSServerFactory(TSRMLS_C);
	Register_SBDTLSServer_Aliases(TSRMLS_C);

	// SBXMLCharsets unit class registration
	Register_TElXMLBufferingStream(TSRMLS_C);
	Register_TElXMLCodec(TSRMLS_C);
	Register_TElXML8BitCodec(TSRMLS_C);
	Register_TElXMLUTF8Codec(TSRMLS_C);
	Register_TElXMLUnicodeCodec(TSRMLS_C);
	Register_TElXMLStringCodec(TSRMLS_C);
	Register_SBXMLCharsets_Aliases(TSRMLS_C);

	// SBXMLCore unit class registration
	Register_TElXMLDOMImplementation(TSRMLS_C);
	Register_TElXMLDOMNode(TSRMLS_C);
	Register_TElXMLDOMDocument(TSRMLS_C);
	Register_TElXMLDOMDocumentFragment(TSRMLS_C);
	Register_TElXMLNodeSet(TSRMLS_C);
	Register_TElXMLDOMNodeList(TSRMLS_C);
	Register_TElXMLDOMNamedNodeMap(TSRMLS_C);
	Register_TElXMLDOMCharacterData(TSRMLS_C);
	Register_TElXMLDOMAttr(TSRMLS_C);
	Register_TElXMLDOMElement(TSRMLS_C);
	Register_TElXMLDOMText(TSRMLS_C);
	Register_TElXMLDOMComment(TSRMLS_C);
	Register_TElXMLDOMCDATASection(TSRMLS_C);
	Register_TElXMLDOMDocumentType(TSRMLS_C);
	Register_TElXMLDOMNotation(TSRMLS_C);
	Register_TElXMLDOMEntity(TSRMLS_C);
	Register_TElXMLDOMEntityReference(TSRMLS_C);
	Register_TElXMLDOMProcessingInstruction(TSRMLS_C);
	Register_TElXMLParser(TSRMLS_C);
	Register_TElXMLNamespaceMap(TSRMLS_C);
	Register_TElXMLCustomFormatter(TSRMLS_C);
	Register_TElXMLCustomElement(TSRMLS_C);
	Register_SBXMLCore_Enum_Flags(TSRMLS_C);
	Register_SBXMLCore_Aliases(TSRMLS_C);

	// SBXMLDefs unit class registration
	Register_TElVersionURI(TSRMLS_C);
	Register_SBXMLDefs_Enum_Flags(TSRMLS_C);
	Register_SBXMLDefs_Aliases(TSRMLS_C);

	// SBXMLPath unit class registration
	Register_TElXPath(TSRMLS_C);
	Register_TElNumber(TSRMLS_C);
	Register_TElBoolean(TSRMLS_C);
	Register_TElString(TSRMLS_C);
	Register_TElXMLVarMap(TSRMLS_C);
	Register_TElXPathNode(TSRMLS_C);
	Register_TElUnionExprNode(TSRMLS_C);
	Register_TElPathExprNode(TSRMLS_C);
	Register_TElLocationPathNode(TSRMLS_C);
	Register_TElAbsoluteLocationPathNode(TSRMLS_C);
	Register_TElRelativeLocationPathNode(TSRMLS_C);
	Register_TElStepNode(TSRMLS_C);
	Register_TElPredicateNode(TSRMLS_C);
	Register_TElOrExprNode(TSRMLS_C);
	Register_TElAndExprNode(TSRMLS_C);
	Register_TElEqualityExprNode(TSRMLS_C);
	Register_TElRelationalExprNode(TSRMLS_C);
	Register_TElAdditiveExprNode(TSRMLS_C);
	Register_TElMultiplicativeExprNode(TSRMLS_C);
	Register_TElUnaryExprNode(TSRMLS_C);
	Register_TElFilterExprNode(TSRMLS_C);
	Register_TElPrimaryExprNode(TSRMLS_C);
	Register_TElVariableReferenceNode(TSRMLS_C);
	Register_TElLiteralNode(TSRMLS_C);
	Register_TElNumberNode(TSRMLS_C);
	Register_TElFunctionCallNode(TSRMLS_C);
	Register_SBXMLPath_Enum_Flags(TSRMLS_C);
	Register_SBXMLPath_Aliases(TSRMLS_C);

	// SBXMLUtils unit class registration
	Register_SBXMLUtils_Enum_Flags(TSRMLS_C);

	// SBXMLAdES unit class registration
	Register_TElXMLAdESElement(TSRMLS_C);
	Register_TElXMLAnyType(TSRMLS_C);
	Register_TElXMLAnyTypeList(TSRMLS_C);
	Register_TElXMLObjectIdentifier(TSRMLS_C);
	Register_TElXMLEncapsulatedPKIData(TSRMLS_C);
	Register_TElXMLEncapsulatedPKIDataList(TSRMLS_C);
	Register_TElXMLHashDataInfo(TSRMLS_C);
	Register_TElXMLHashDataInfoList(TSRMLS_C);
	Register_TElXMLCustomTimestamp(TSRMLS_C);
	Register_TElXMLCustomTimestampList(TSRMLS_C);
	Register_TElXMLTimestamp(TSRMLS_C);
	Register_TElXMLTimestampList(TSRMLS_C);
	Register_TElXMLInclude(TSRMLS_C);
	Register_TElXMLIncludeList(TSRMLS_C);
	Register_TElXMLTimestamp_v1_2_2(TSRMLS_C);
	Register_TElXMLTimestampList_v1_2_2(TSRMLS_C);
	Register_TElCustomTSPClientList(TSRMLS_C);
	Register_TElXMLGenericTimestamp(TSRMLS_C);
	Register_TElXMLGenericTimestampList(TSRMLS_C);
	Register_TElXMLDigestAlgAndValue(TSRMLS_C);
	Register_TElXMLCertID(TSRMLS_C);
	Register_TElXMLCertIDList(TSRMLS_C);
	Register_TElXMLCertIDV2(TSRMLS_C);
	Register_TElXMLCertIDListV2(TSRMLS_C);
	Register_TElXMLNoticeReference(TSRMLS_C);
	Register_TElXMLSPUserNotice(TSRMLS_C);
	Register_TElXMLSPURI(TSRMLS_C);
	Register_TElXMLSigPolicyQualifier(TSRMLS_C);
	Register_TElXMLSignaturePolicyId(TSRMLS_C);
	Register_TElXMLSignaturePolicyIdentifier(TSRMLS_C);
	Register_TElXMLCounterSignature(TSRMLS_C);
	Register_TElXMLCounterSignatureList(TSRMLS_C);
	Register_TElXMLDataObjectFormat(TSRMLS_C);
	Register_TElXMLDataObjectFormatList(TSRMLS_C);
	Register_TElXMLCommitmentTypeQualifier(TSRMLS_C);
	Register_TElXMLCommitmentTypeIndication(TSRMLS_C);
	Register_TElXMLCommitmentTypeIndicationList(TSRMLS_C);
	Register_TElXMLSignatureProductionPlace(TSRMLS_C);
	Register_TElXMLSignatureProductionPlaceV2(TSRMLS_C);
	Register_TElXMLEncapsulatedX509Certificates(TSRMLS_C);
	Register_TElXMLCertifiedRole(TSRMLS_C);
	Register_TElXMLCertifiedRolesList(TSRMLS_C);
	Register_TElXMLCertifiedRoleV2(TSRMLS_C);
	Register_TElXMLCertifiedRolesListV2(TSRMLS_C);
	Register_TElXMLClaimedRole(TSRMLS_C);
	Register_TElXMLClaimedRolesList(TSRMLS_C);
	Register_TElXMLSignedAssertion(TSRMLS_C);
	Register_TElXMLSignedAssertionsList(TSRMLS_C);
	Register_TElXMLSignerRole(TSRMLS_C);
	Register_TElXMLSignerRoleV2(TSRMLS_C);
	Register_TElXMLCompleteCertificateRefs(TSRMLS_C);
	Register_TElXMLCRLIdentifier(TSRMLS_C);
	Register_TElXMLCRLRef(TSRMLS_C);
	Register_TElXMLCRLRefs(TSRMLS_C);
	Register_TElXMLOCSPIdentifier(TSRMLS_C);
	Register_TElXMLOCSPRef(TSRMLS_C);
	Register_TElXMLOCSPRefs(TSRMLS_C);
	Register_TElXMLOtherRef(TSRMLS_C);
	Register_TElXMLCompleteRevocationRefs(TSRMLS_C);
	Register_TElXMLCertificateValues(TSRMLS_C);
	Register_TElXMLEncapsulatedCRLValue(TSRMLS_C);
	Register_TElXMLCRLValues(TSRMLS_C);
	Register_TElXMLEncapsulatedOCSPValue(TSRMLS_C);
	Register_TElXMLOCSPValues(TSRMLS_C);
	Register_TElXMLRevocationValues(TSRMLS_C);
	Register_TElXMLTimeStampValidationData(TSRMLS_C);
	Register_TElXMLTimeStampValidationDataList(TSRMLS_C);
	Register_TElXMLSignedDataObjectProperties(TSRMLS_C);
	Register_TElXMLUnsignedDataObjectProperty(TSRMLS_C);
	Register_TElXMLSignedSignatureProperties(TSRMLS_C);
	Register_TElXMLUnsignedSignatureProperties(TSRMLS_C);
	Register_TElXMLSignedProperties(TSRMLS_C);
	Register_TElXMLUnsignedProperties(TSRMLS_C);
	Register_TElXMLQualifyingProperties(TSRMLS_C);
	Register_TElXMLQualifyingPropertiesReference(TSRMLS_C);
	Register_TElXMLQualifyingPropertiesReferenceList(TSRMLS_C);
	Register_SBXMLAdES_Enum_Flags(TSRMLS_C);
	Register_SBXMLAdES_Aliases(TSRMLS_C);

	// SBXMLAdESIntf unit class registration
	Register_TElXAdESProcessor(TSRMLS_C);
	Register_TElXAdESSigner(TSRMLS_C);
	Register_TElXAdESVerifier(TSRMLS_C);
	Register_SBXMLAdESIntf_Enum_Flags(TSRMLS_C);
	Register_SBXMLAdESIntf_Aliases(TSRMLS_C);

	// SBXMLEnc unit class registration
	Register_TElXMLEncryptedType(TSRMLS_C);
	Register_TElXMLEncProcessor(TSRMLS_C);
	Register_TElXMLEncryptor(TSRMLS_C);
	Register_TElXMLDecryptor(TSRMLS_C);
	Register_TElXMLCipherReference(TSRMLS_C);
	Register_TElXMLCipherData(TSRMLS_C);
	Register_TElXMLEncryptionMethodType(TSRMLS_C);
	Register_TElXMLEncryptionProperties(TSRMLS_C);
	Register_TElXMLEncryptedData(TSRMLS_C);
	Register_TElXMLEncryptedKey(TSRMLS_C);
	Register_TElXMLDecryptionExcept(TSRMLS_C);
	Register_TElXMLCustomDecryptionTransform(TSRMLS_C);
	Register_TElXMLDecryptionTransform(TSRMLS_C);
	Register_TElXMLBinaryDecryptionTransform(TSRMLS_C);
	Register_SBXMLEnc_Aliases(TSRMLS_C);

	// SBXMLSec unit class registration
	Register_TElXMLKeyInfo(TSRMLS_C);
	Register_TElXMLAlgorithmParameters(TSRMLS_C);
	Register_TElXMLReference(TSRMLS_C);
	Register_TElXMLReferenceList(TSRMLS_C);
	Register_TElXMLGOSTR3411Parameters(TSRMLS_C);
	Register_TElXMLRSAPSSParameters(TSRMLS_C);
	Register_TElXMLKeyInfoItem(TSRMLS_C);
	Register_TElXMLKeyInfoData(TSRMLS_C);
	Register_TElXMLKeyInfoHMACData(TSRMLS_C);
	Register_TElXMLKeyInfoSymmetricData(TSRMLS_C);
	Register_TElXMLKeyInfoKeyDerivationMethod(TSRMLS_C);
	Register_TElXMLKeyInfoPBKDF2DerivationMethod(TSRMLS_C);
	Register_TElXMLKeyInfoConcatKDFDerivationMethod(TSRMLS_C);
	Register_TElXMLPBKDF2Salt(TSRMLS_C);
	Register_TElXMLPRFAlgorithmIdentifierType(TSRMLS_C);
	Register_TElXMLKeyInfoDerivedKeyData(TSRMLS_C);
	Register_TElXMLKeyInfoAsymmetricData(TSRMLS_C);
	Register_TElXMLKeyInfoRSAData(TSRMLS_C);
	Register_TElXMLKeyInfoDSAData(TSRMLS_C);
	Register_TElXMLKeyInfoDHData(TSRMLS_C);
	Register_TElXMLKeyInfoGOST2001Data(TSRMLS_C);
	Register_TElXMLKeyInfoPGPData(TSRMLS_C);
	Register_TElXMLKeyInfoECData(TSRMLS_C);
	Register_TElXMLIssuerSerial(TSRMLS_C);
	Register_TElXMLKeyInfoX509Data(TSRMLS_C);
	Register_TElXMLKeyInfoNode(TSRMLS_C);
	Register_TElXMLKeyInfoRetrievalMethod(TSRMLS_C);
	Register_TElXMLKeyInfoAgreementMethod(TSRMLS_C);
	Register_TElXMLProperty(TSRMLS_C);
	Register_TElXMLProperties(TSRMLS_C);
	Register_TElXMLProcessor(TSRMLS_C);
	Register_TElXMLFormatter(TSRMLS_C);
	Register_TElXMLDescriptorMap(TSRMLS_C);
	Register_SBXMLSec_Enum_Flags(TSRMLS_C);
	Register_SBXMLSec_Aliases(TSRMLS_C);

	// SBXMLSig unit class registration
	Register_TElXMLSignature(TSRMLS_C);
	Register_TElXMLSigProcessor(TSRMLS_C);
	Register_TElXMLSigner(TSRMLS_C);
	Register_TElXMLVerifier(TSRMLS_C);
	Register_TElXMLSignatureMethodType(TSRMLS_C);
	Register_TElXMLSignedInfo(TSRMLS_C);
	Register_TElXMLManifest(TSRMLS_C);
	Register_TElXMLSignatureProperties(TSRMLS_C);
	Register_TElXMLObject(TSRMLS_C);
	Register_TElXMLObjectList(TSRMLS_C);
	Register_TElXMLSignatureValue(TSRMLS_C);
	Register_SBXMLSig_Aliases(TSRMLS_C);

	// SBXMLTransform unit class registration
	Register_TElXMLTransform(TSRMLS_C);
	Register_TElXMLNullTransform(TSRMLS_C);
	Register_TElXMLBase64Transform(TSRMLS_C);
	Register_TElXMLC14NTransform(TSRMLS_C);
	Register_TElXMLEnvelopedSignatureTransform(TSRMLS_C);
	Register_TElXMLXPathTransform(TSRMLS_C);
	Register_TElXMLXPathFilterItem(TSRMLS_C);
	Register_TElXMLXPathFilter2Transform(TSRMLS_C);
	Register_TElXMLTransformChain(TSRMLS_C);
	Register_TElXMLUnsupportedTransform(TSRMLS_C);
	Register_SBXMLTransform_Enum_Flags(TSRMLS_C);
	Register_SBXMLTransform_Aliases(TSRMLS_C);

	// SBXMLSOAPCore unit class registration
	Register_TElXMLSOAPElement(TSRMLS_C);
	Register_TElXMLSOAPHeaderBlock(TSRMLS_C);
	Register_TElXMLSOAPHeader(TSRMLS_C);
	Register_TElXMLSOAPBodyEntry(TSRMLS_C);
	Register_TElXMLSOAPBody(TSRMLS_C);
	Register_TElXMLSOAPEnvelope(TSRMLS_C);
	Register_SBXMLSOAPCore_Enum_Flags(TSRMLS_C);

	// SBXMLWSSCore unit class registration
	Register_TElXMLWSSEElement(TSRMLS_C);
	Register_TElXMLWSSEBaseToken(TSRMLS_C);
	Register_TElXMLWSSETextElement(TSRMLS_C);
	Register_TElXMLWSSEPassword(TSRMLS_C);
	Register_TElXMLWSSENonce(TSRMLS_C);
	Register_TElXMLWSUDateTime(TSRMLS_C);
	Register_TElXMLWSSEUsernameToken(TSRMLS_C);
	Register_TElXMLWSUTimestamp(TSRMLS_C);
	Register_TElXMLWSSEBinarySecurityToken(TSRMLS_C);
	Register_TElXMLWSSESecurity(TSRMLS_C);
	Register_TElXMLWSSEReference(TSRMLS_C);
	Register_TElXMLWSSEKeyIdentifier(TSRMLS_C);
	Register_TElXMLWSSESecurityTokenReference(TSRMLS_C);
	Register_SBXMLWSSCore_Enum_Flags(TSRMLS_C);

	// SBXMLSOAP unit class registration
	Register_TElXMLSOAPMessage(TSRMLS_C);
	Register_TElXMLSOAPCustomSignatureHandler(TSRMLS_C);
	Register_TElXMLSOAPBaseSignatureHandler(TSRMLS_C);
	Register_SBXMLSOAP_Enum_Flags(TSRMLS_C);
	Register_SBXMLSOAP_Aliases(TSRMLS_C);

	// SBXMLSOAPSecurity unit class registration
	Register_TElXMLSOAPSignatureHandler(TSRMLS_C);
	Register_TElXMLWSSSignatureHandler(TSRMLS_C);
	Register_SBXMLSOAPSecurity_Enum_Flags(TSRMLS_C);

	// SBXMLSOAPClient unit class registration
	Register_TElXMLSOAPClient(TSRMLS_C);
	Register_TElXMLSOAPParameterAttribute(TSRMLS_C);
	Register_TElXMLSOAPCustomParameter(TSRMLS_C);
	Register_TElXMLSOAPBaseParameter(TSRMLS_C);
	Register_TElXMLSOAPStringParameter(TSRMLS_C);
	Register_TElXMLSOAPBooleanParameter(TSRMLS_C);
	Register_TElXMLSOAPIntegerParameter(TSRMLS_C);
	Register_TElXMLSOAPInt64Parameter(TSRMLS_C);
	Register_TElXMLSOAPDoubleParameter(TSRMLS_C);
	Register_TElXMLSOAPDateTimeParameter(TSRMLS_C);
	Register_TElXMLSOAPBase64BinaryParameter(TSRMLS_C);
	Register_TElXMLSOAPCompoundParameter(TSRMLS_C);
	Register_TElXMLSOAPParametersManager(TSRMLS_C);
	Register_TElXMLSOAPFault(TSRMLS_C);
	Register_SBXMLSOAPClient_Enum_Flags(TSRMLS_C);
	Register_SBXMLSOAPClient_Aliases(TSRMLS_C);

	// SBArcBase unit class registration
	Register_TElBaseArchive(TSRMLS_C);
	Register_TElArchiveDirectoryEntry(TSRMLS_C);
	Register_TElArcProcessingUnit(TSRMLS_C);
	Register_SBArcBase_Enum_Flags(TSRMLS_C);

	// SBArcZip unit class registration
	Register_TElZipArchiveDirectoryEntry(TSRMLS_C);
	Register_TElZipDosFileAttributes(TSRMLS_C);
	Register_TElZipUnixFileAttributes(TSRMLS_C);
	Register_TElZipStrongEncryptionInfo(TSRMLS_C);
	Register_TElZipStrongEncryptionSignatureInfo(TSRMLS_C);
	Register_TElZipProcessingUnit(TSRMLS_C);
	Register_TElZipStoredProcessingUnit(TSRMLS_C);
	Register_TElZipDeflateDecompressingUnit(TSRMLS_C);
	Register_TElZipDeflateCompressingUnit(TSRMLS_C);
#ifdef SB_WINDOWS
	Register_TElZipLzmaDecompressingUnit(TSRMLS_C);
	Register_TElZipLzmaCompressingUnit(TSRMLS_C);
#endif
	Register_TElZipBZip2DecompressingUnit(TSRMLS_C);
	Register_TElZipBZip2CompressingUnit(TSRMLS_C);
	Register_TElZipOldStyleEncryptingUnit(TSRMLS_C);
	Register_TElZipOldStyleDecryptingUnit(TSRMLS_C);
	Register_TElZipStrongEncryptionBaseUnit(TSRMLS_C);
	Register_TElZipStrongEncryptionEncryptingUnit(TSRMLS_C);
	Register_TElZipStrongEncryptionDecryptingUnit(TSRMLS_C);
	Register_TElZipStrongEncryptionHashingUnit(TSRMLS_C);
	Register_TElZipWinZipAesBaseUnit(TSRMLS_C);
	Register_TElZipWinZipAesDecryptingUnit(TSRMLS_C);
	Register_TElZipWinZipAesEncryptingUnit(TSRMLS_C);
	Register_TElZipReader(TSRMLS_C);
	Register_TElZipWriter(TSRMLS_C);
	Register_SBArcZip_Enum_Flags(TSRMLS_C);
	Register_SBArcZip_Aliases(TSRMLS_C);

	// SBZipEntities unit class registration
	Register_TElZipEntity(TSRMLS_C);
	Register_TElZipLocalFileHeader(TSRMLS_C);
	Register_TElZipCentralFileHeader(TSRMLS_C);
	Register_TElZipDataDescriptor(TSRMLS_C);
	Register_TElZipEntityExtensions(TSRMLS_C);
	Register_TElZipEntityExtension(TSRMLS_C);
	Register_TElZipCentralDirectorySignature(TSRMLS_C);
	Register_TElZip64EndOfCentralDirectory(TSRMLS_C);
	Register_TElZip64EndOfCentralDirectoryLocator(TSRMLS_C);
	Register_TElZipEndOfCentralDirectory(TSRMLS_C);
	Register_TElZipArchiveExtraData(TSRMLS_C);
	Register_TElZipProcessor(TSRMLS_C);
	Register_TElZipEntityNTFSExtension(TSRMLS_C);
	Register_TElZipEntityCustomExtension(TSRMLS_C);
	Register_TElZipEntityZip64InfoExtension(TSRMLS_C);
	Register_TElZipEntityStrongEncryptionExtension(TSRMLS_C);
	Register_TElZipEntityWinZipAESExtension(TSRMLS_C);
	Register_TElZipEntityCertificateStoreExtension(TSRMLS_C);
	Register_TElZipEntitySignatureExtension(TSRMLS_C);
	Register_TElZipEntityUTF8FileNameExtension(TSRMLS_C);
	Register_TElZipEntityCentralDirSignatureExtension(TSRMLS_C);
	Register_TElZipEntityUnix1Extension(TSRMLS_C);
	Register_TElZipEntityUnix2Extension(TSRMLS_C);
	Register_TElZipEntityExtendedTimestampExtension(TSRMLS_C);
	Register_TElZipEntityUIDAndGIDExtension(TSRMLS_C);
	Register_TElZipNTFSTag(TSRMLS_C);
	Register_TElZipNTFSCustomTag(TSRMLS_C);
	Register_TElZipNTFSTag1(TSRMLS_C);

	// SBZipUtils unit class registration
	Register_TSBZIPEncryptionContext(TSRMLS_C);

	// SBArcTar unit class registration
	Register_TElTarArchiveDirectoryEntry(TSRMLS_C);
	Register_TElTarFileAttributes(TSRMLS_C);
	Register_TElTarProcessingUnit(TSRMLS_C);
	Register_TElTarReader(TSRMLS_C);
	Register_TElTarWriter(TSRMLS_C);
	Register_SBArcTar_Enum_Flags(TSRMLS_C);
	Register_SBArcTar_Aliases(TSRMLS_C);

	// SBTarEntities unit class registration
	Register_TElUStarTarHeader(TSRMLS_C);

	// SBArcGZip unit class registration
	Register_TElGZipDecompressingUnit(TSRMLS_C);
	Register_TElGZipCompressingUnit(TSRMLS_C);
	Register_TElGZipFileAttributes(TSRMLS_C);
	Register_TElGZipReader(TSRMLS_C);
	Register_TElGZipWriter(TSRMLS_C);
	Register_SBArcGZip_Enum_Flags(TSRMLS_C);
	Register_SBArcGZip_Aliases(TSRMLS_C);

	// SBArcBZip2 unit class registration
	Register_TElBZip2DecompressingUnit(TSRMLS_C);
	Register_TElBZip2CompressingUnit(TSRMLS_C);
	Register_TElBZip2Reader(TSRMLS_C);
	Register_TElBZip2Writer(TSRMLS_C);
	Register_SBArcBZip2_Aliases(TSRMLS_C);

#ifdef SB_WINDOWS
	// SBZIPSFX unit class registration
	Register_TElZIPSFXStub(TSRMLS_C);
	Register_SBZIPSFX_Enum_Flags(TSRMLS_C);
#else
	// SBXMLSAMLBind unit class registration
	Register_TElSAMLBinding(TSRMLS_C);
	Register_TElSAMLSOAPBinding(TSRMLS_C);
	Register_TElSAMLCompressedProcessor(TSRMLS_C);
	Register_TElSAMLRedirectBinding(TSRMLS_C);
	Register_TElSAMLPOSTBinding(TSRMLS_C);
	Register_TElSAMLArtifact(TSRMLS_C);
	Register_SBXMLSAMLBind_Enum_Flags(TSRMLS_C);
#endif

#ifdef SB_WINDOWS
	// SBXMLSAMLBind unit class registration
	Register_TElSAMLBinding(TSRMLS_C);
	Register_TElSAMLSOAPBinding(TSRMLS_C);
	Register_TElSAMLCompressedProcessor(TSRMLS_C);
	Register_TElSAMLRedirectBinding(TSRMLS_C);
	Register_TElSAMLPOSTBinding(TSRMLS_C);
	Register_TElSAMLArtifact(TSRMLS_C);
	Register_SBXMLSAMLBind_Enum_Flags(TSRMLS_C);

	// SBXMLSAMLCommon unit class registration
	Register_TElSAMLClientSettings(TSRMLS_C);
	Register_TElSAMLSession(TSRMLS_C);
	Register_TElCustomSessionManager(TSRMLS_C);
	Register_TElMemorySessionManager(TSRMLS_C);
	Register_SBXMLSAMLCommon_TElStringValue(TSRMLS_C);
	Register_TElCustomArtifactStorage(TSRMLS_C);
	Register_TElMemoryArtifactStorage(TSRMLS_C);
	Register_TElSAMLAdapter(TSRMLS_C);
	Register_SBXMLSAMLCommon_Enum_Flags(TSRMLS_C);

	// SBXMLSAMLCore unit class registration
	Register_TElSAMLElement(TSRMLS_C);
	Register_TElSAMLConditionsElement(TSRMLS_C);
	Register_TElSAMLAdviceElement(TSRMLS_C);
	Register_TElSAMLSubjectConfirmationDataElement(TSRMLS_C);
	Register_TElSAMLStatementAbstractType(TSRMLS_C);
	Register_TElSAMLSubjectConfirmationElement(TSRMLS_C);
	Register_TElSAMLSecurityHandler(TSRMLS_C);
	Register_TElSAMLSignatureHandler(TSRMLS_C);
	Register_TElSAMLEncryptionHandler(TSRMLS_C);
	Register_TElSAMLSubjectElement(TSRMLS_C);
	Register_TElSAMLID(TSRMLS_C);
	Register_TElSAMLBaseIDElement(TSRMLS_C);
	Register_TElSAMLNameIDElement(TSRMLS_C);
	Register_TElSAMLEncryptedElement(TSRMLS_C);
	Register_TElSAMLEncryptedIDElement(TSRMLS_C);
	Register_TElSAMLIssuerElement(TSRMLS_C);
	Register_TElSAMLAssertionType(TSRMLS_C);
	Register_TElSAMLAssertionIDRefElement(TSRMLS_C);
	Register_TElSAMLAssertionURIRefElement(TSRMLS_C);
	Register_TElSAMLAssertionElement(TSRMLS_C);
	Register_TElSAMLEncryptedAssertionElement(TSRMLS_C);
	Register_TElSAMLConditionAbstractType(TSRMLS_C);
	Register_TElSAMLAudienceElement(TSRMLS_C);
	Register_TElSAMLAudienceRestrictionElement(TSRMLS_C);
	Register_TElSAMLOneTimeUseElement(TSRMLS_C);
	Register_TElSAMLProxyRestrictionElement(TSRMLS_C);
	Register_TElSAMLSubjectLocalityElement(TSRMLS_C);
	Register_TElSAMLAuthnContextElement(TSRMLS_C);
	Register_TElSAMLAuthnStatementElement(TSRMLS_C);
	Register_TElSAMLAttributeType(TSRMLS_C);
	Register_TElSAMLAttributeValue(TSRMLS_C);
	Register_TElSAMLAttributeElement(TSRMLS_C);
	Register_TElSAMLEncryptedAttributeElement(TSRMLS_C);
	Register_TElSAMLAttributeStatementElement(TSRMLS_C);
	Register_TElSAMLActionElement(TSRMLS_C);
	Register_TElSAMLEvidenceElement(TSRMLS_C);
	Register_TElSAMLAuthzDecisionStatementElement(TSRMLS_C);
	Register_SBXMLSAMLCore_Enum_Flags(TSRMLS_C);
	Register_SBXMLSAMLCore_Aliases(TSRMLS_C);

	// SBXMLSAMLMetadata unit class registration
	Register_TElSAMLMetadataRootElement(TSRMLS_C);
	Register_TElSAMLLocalizedNameType(TSRMLS_C);
	Register_TElSAMLLocalizedURIType(TSRMLS_C);
	Register_TElSAMLEndpointType(TSRMLS_C);
	Register_TElSAMLIndexedEndpointType(TSRMLS_C);
	Register_TElSAMLEntityDescriptorElement(TSRMLS_C);
	Register_TElSAMLEntitiesDescriptorElement(TSRMLS_C);
	Register_TElSAMLKeyDescriptorElement(TSRMLS_C);
	Register_TElSAMLOrganizationElement(TSRMLS_C);
	Register_TElSAMLContactPersonElement(TSRMLS_C);
	Register_TElSAMLRoleDescriptorElement(TSRMLS_C);
	Register_TElSAMLAuthnQueryServiceElement(TSRMLS_C);
	Register_TElSAMLAssertionIDRequestServiceElement(TSRMLS_C);
	Register_TElSAMLAuthnAuthorityDescriptorElement(TSRMLS_C);
	Register_TElSAMLAttributeServiceElement(TSRMLS_C);
	Register_TElSAMLAttributeAuthorityDescriptorElement(TSRMLS_C);
	Register_TElSAMLAuthzServiceElement(TSRMLS_C);
	Register_TElSAMLPDPDescriptorElement(TSRMLS_C);
	Register_TElSAMLAffiliationDescriptorElement(TSRMLS_C);
	Register_TElSAMLOrganizationNameElement(TSRMLS_C);
	Register_TElSAMLOrganizationDisplayNameElement(TSRMLS_C);
	Register_TElSAMLOrganizationURLElement(TSRMLS_C);
	Register_TElSAMLAdditionalMetadataLocationElement(TSRMLS_C);
	Register_TElSAMLArtifactResolutionServiceElement(TSRMLS_C);
	Register_TElSAMLSingleLogoutServiceElement(TSRMLS_C);
	Register_TElSAMLManageNameIDServiceElement(TSRMLS_C);
	Register_TElSAMLSingleSignOnServiceElement(TSRMLS_C);
	Register_TElSAMLNameIDMappingServiceElement(TSRMLS_C);
	Register_TElSAMLSSODescriptorType(TSRMLS_C);
	Register_TElSAMLIDPSSODescriptorElement(TSRMLS_C);
	Register_TElSAMLAssertionConsumerServiceElement(TSRMLS_C);
	Register_TElSAMLRequestedAttributeElement(TSRMLS_C);
	Register_TElSAMLServiceNameElement(TSRMLS_C);
	Register_TElSAMLServiceDescriptionElement(TSRMLS_C);
	Register_TElSAMLAttributeConsumingServiceElement(TSRMLS_C);
	Register_TElSAMLSPSSODescriptorElement(TSRMLS_C);
	Register_TElSAMLEncryptionMethodType(TSRMLS_C);
	Register_TElSAMLMetadata(TSRMLS_C);
	Register_TElSAMLEndpoint(TSRMLS_C);
	Register_SBXMLSAMLMetadata_Enum_Flags(TSRMLS_C);

	// SBXMLSAMLProtocol unit class registration
	Register_TElSAMLExtensionsElement(TSRMLS_C);
	Register_TElSAMLRequestAbstractType(TSRMLS_C);
	Register_TElSAMLStatusCodeElement(TSRMLS_C);
	Register_TElSAMLStatusMessageElement(TSRMLS_C);
	Register_TElSAMLStatusDetailElement(TSRMLS_C);
	Register_TElSAMLStatusElement(TSRMLS_C);
	Register_TElSAMLStatusResponseType(TSRMLS_C);
	Register_TElSAMLAssertionIDRequestElement(TSRMLS_C);
	Register_TElSAMLSubjectQueryAbstractType(TSRMLS_C);
	Register_TElSAMLSubjectQueryElement(TSRMLS_C);
	Register_TElSAMLRequestedAuthnContextElement(TSRMLS_C);
	Register_TElSAMLAuthnQueryElement(TSRMLS_C);
	Register_TElSAMLAttributeQueryElement(TSRMLS_C);
	Register_TElSAMLAuthzDecisionQueryElement(TSRMLS_C);
	Register_TElSAMLResponseElement(TSRMLS_C);
	Register_TElSAMLNameIDPolicyElement(TSRMLS_C);
	Register_TElSAMLIDPEntryElement(TSRMLS_C);
	Register_TElSAMLIDPListElement(TSRMLS_C);
	Register_TElSAMLScopingElement(TSRMLS_C);
	Register_TElSAMLAuthnRequestElement(TSRMLS_C);
	Register_TElSAMLArtifactResolveElement(TSRMLS_C);
	Register_TElSAMLArtifactResponseElement(TSRMLS_C);
	Register_TElSAMLManageNameIDRequestElement(TSRMLS_C);
	Register_TElSAMLManageNameIDResponseElement(TSRMLS_C);
	Register_TElSAMLLogoutRequestElement(TSRMLS_C);
	Register_TElSAMLLogoutResponseElement(TSRMLS_C);
	Register_TElSAMLNameIDMappingRequestElement(TSRMLS_C);
	Register_TElSAMLNameIDMappingResponseElement(TSRMLS_C);
	Register_SBXMLSAMLProtocol_Enum_Flags(TSRMLS_C);

	// SBSAMLIdentityProvider unit class registration
	Register_TElSAMLIDPSession(TSRMLS_C);
	Register_TElSAMLServiceProviderInfo(TSRMLS_C);
	Register_TElSAMLSPData(TSRMLS_C);
	Register_TElSAMLIDPCustomAuthSource(TSRMLS_C);
	Register_TElSAMLIDRecord(TSRMLS_C);
	Register_TElSAMLIDPPasswordMemoryAuthSource(TSRMLS_C);
	Register_TElSAMLIdPSSOLink(TSRMLS_C);
	Register_TElSAMLIdentityProvider(TSRMLS_C);
	Register_SBSAMLIdentityProvider_Enum_Flags(TSRMLS_C);

	// SBSAMLServiceProvider unit class registration
	Register_TElSAMLSPSession(TSRMLS_C);
	Register_TElSAMLRequestResult(TSRMLS_C);
	Register_TElSAMLOneTimeUseRecord(TSRMLS_C);
	Register_TElSAMLCustomOneTimeUseCache(TSRMLS_C);
	Register_TElSAMLMemoryOneTimeUseCache(TSRMLS_C);
	Register_TElSAMLServiceProvider(TSRMLS_C);
	Register_SBSAMLServiceProvider_Enum_Flags(TSRMLS_C);

	// SBDCCMS unit class registration
	Register_TElDCCMSSignOperationHandler(TSRMLS_C);
	Register_TElDCServerCMSRequestSignatureHandler(TSRMLS_C);

	// SBDCCMSClient unit class registration
	Register_TElDCClientCMSRequestSignatureHandler(TSRMLS_C);

	// SBASiCContainer unit class registration
	Register_TElASiCSignature(TSRMLS_C);
	Register_TElASiCContainer(TSRMLS_C);
	Register_TElASiCEntryHashInfo(TSRMLS_C);
	Register_TElASiCDataObjectReference(TSRMLS_C);
	Register_TElASiCManifest(TSRMLS_C);
	Register_TElASiCTimestamp(TSRMLS_C);
	Register_TElASiCCAdESSignatureEntry(TSRMLS_C);
	Register_TElASiCCAdESSignature(TSRMLS_C);
	Register_TElASiCXAdESSignatureEntry(TSRMLS_C);
	Register_TElASiCXAdESSignature(TSRMLS_C);
	Register_TElOpenDocumentXMLElement(TSRMLS_C);
	Register_TElOpenDocumentXMLManifestFileEntry(TSRMLS_C);
	Register_TElOpenDocumentXMLManifest(TSRMLS_C);
	Register_TElASiCHashingUnit(TSRMLS_C);
	Register_SBASiCContainer_Enum_Flags(TSRMLS_C);
	Register_SBASiCContainer_Aliases(TSRMLS_C);

	SB_OUTPUT_DEBUG("Module init end")
	return SUCCESS;
}

PHP_MSHUTDOWN_FUNCTION(sbb)
{
	SBCleanupEvents();
	SB_OUTPUT_DEBUG("Module shutdown")
	UNREGISTER_INI_ENTRIES();

	return SUCCESS;
}

PHP_RINIT_FUNCTION(sbb)
{
	SB_OUTPUT_DEBUG("Request init")
	return SUCCESS;
}

PHP_RSHUTDOWN_FUNCTION(sbb)
{
	SBCleanupEvents();
	SB_OUTPUT_DEBUG("Request shutdown")
	return SUCCESS;
}

PHP_MINFO_FUNCTION(sbb)
{
	SB_OUTPUT_DEBUG("Module info")
	php_info_print_table_start();
	php_info_print_table_header(2, "SecureBlackbox support", "enabled");
	php_info_print_table_row(2, "SecureBlackbox library version", SBB_VERSION_NUMBER);
	php_info_print_table_end();
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_BytesOfString, 0, 0, 1)
	ZEND_ARG_INFO(0, str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_StringOfBytes, 0, 0, 1)
	ZEND_ARG_ARRAY_INFO(0, buffer, 0)
ZEND_END_ARG_INFO()

// SBConstants unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetPBEAlgorithmByOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetOIDByPBEAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetPKAlgorithmByOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetOIDByPKAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetSigAlgorithmByOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetOIDBySigAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetHashAlgorithmByOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetOIDByHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetAlgorithmByOID, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
	ZEND_ARG_INFO(0, UseCryptoProvConstants)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetOIDByAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetAlgorithmNameByAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetAlgorithmNameByOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetHashAlgorithmBySigAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetHMACAlgorithmByHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetHashAlgorithmByHMACAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetSigAlgorithmByHashAlgorithm, 0, 0, 2)
	ZEND_ARG_INFO(0, BasePKAlg)
	ZEND_ARG_INFO(0, HashAlg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetCertAlgorithmFromNormalizedAlgorithms, 0, 0, 2)
	ZEND_ARG_INFO(0, PKAlg)
	ZEND_ARG_INFO(0, HashAlg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetKeyAlgorithmBySigAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, SigAlg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetSigAlgorithmByKeyAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, KeyAlg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_IsSymmetricKeyAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_IsHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_IsMACAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_IsPublicKeyAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_IsAEADAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_NormalizeAlgorithmConstant, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_MGF1AlgorithmByHash, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_HashAlgorithmByMGF1, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

// SBASN1 unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_asn1ParseStream, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Stream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, CallBack, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_asn1AddTypeEqu, 0, 0, 4)
	ZEND_ARG_INFO(0, TagType1)
	ZEND_ARG_TYPE_INFO(0, Tag1, 0, 1)
	ZEND_ARG_INFO(0, TagSize1)
	ZEND_ARG_INFO(0, TagType2_or_Tag2)
	ZEND_ARG_TYPE_INFO(0, Tag2, 0, 1)
	ZEND_ARG_INFO(0, TagSize2)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteListSequence, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Strings, TElByteArrayList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WritePrimitiveListSeq, 0, 0, 2)
	ZEND_ARG_INFO(0, Tag)
	ZEND_ARG_OBJ_INFO(0, Strings, TElByteArrayList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteExplicit, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteInteger, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data_or_Number, 0, 1)
	ZEND_ARG_INFO(0, TagID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WritePrintableString, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteUTF8String, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteIA5String, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteUTCTime, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteGeneralizedTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, T, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteBitString, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteOctetString, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteVisibleString, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteBoolean, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteNULL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WritePrimitive, 0, 0, 2)
	ZEND_ARG_INFO(0, Tag)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteStringPrimitive, 0, 0, 2)
	ZEND_ARG_INFO(0, Tag)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_ASN1ParserFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBASN1Tree unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_asymWriteInteger, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1SimpleTag, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1ReadInteger, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1SimpleTag, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1ReadInteger64, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1SimpleTag, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1WriteInteger, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1SimpleTag, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1WriteInteger64, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1SimpleTag, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1ReadSimpleValue, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(1, TagID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1WriteTagAndLength, 0, 0, 2)
	ZEND_ARG_INFO(0, Tag)
	ZEND_ARG_INFO(0, Len)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1ReadBoolean, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1SimpleTag, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1WriteBoolean, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1SimpleTag, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1ReadString, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, TagId)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1ReadStringAnsi, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, TagId)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_FormatAttributeValue, 0, 0, 2)
	ZEND_ARG_INFO(0, TagID)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_UnformatAttributeValue, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
	ZEND_ARG_INFO(1, TagID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_GetTagDisplayName, 0, 0, 1)
	ZEND_ARG_INFO(0, TagID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_GetTagByDisplayName, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_GetMaxASN1TreeDepth, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_SetMaxASN1TreeDepth, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_GetMaxASN1BufferLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_SetMaxASN1BufferLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_GetASN1CopyBuffers, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_SetASN1CopyBuffers, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1TagInfoFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBMSKeyBlob unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMSKeyBlob_WriteMSPublicKeyBlob, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, BlobType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMSKeyBlob_WriteMSDSSPublicKeyBlob, 0, 0, 10)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(0, PSize)
	ZEND_ARG_TYPE_INFO(0, Q, 0, 1)
	ZEND_ARG_INFO(0, QSize)
	ZEND_ARG_TYPE_INFO(0, G, 0, 1)
	ZEND_ARG_INFO(0, GSize)
	ZEND_ARG_TYPE_INFO(0, Y, 0, 1)
	ZEND_ARG_INFO(0, YSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMSKeyBlob_ParseMSKeyBlob, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(1, BlobType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMSKeyBlob_WriteMSKeyBlob, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, BlobType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMSKeyBlob_WriteMSKeyBlobEx, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_OBJ_INFO(0, Algorithm, TElAlgorithmIdentifier, 1)
ZEND_END_ARG_INFO()

// SBPEM unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPEM_Encode, 0, 0, 7)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, Header)
	ZEND_ARG_INFO(0, Encrypt)
	ZEND_ARG_INFO(0, PassPhrase)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPEM_EncodeEx, 0, 0, 7)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, Header)
	ZEND_ARG_INFO(0, EncryptionAlgorithm)
	ZEND_ARG_INFO(0, PassPhrase_or_EncryptionMode)
	ZEND_ARG_INFO(0, PassPhrase)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPEM_Decode, 0, 0, 6)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(0, PassPhrase)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(1, Header)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPEM_IsBase64UnicodeSequence, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPEM_IsBase64Sequence, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPEM_IsPEMSequence, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPEM_RaisePEMError, 0, 0, 1)
	ZEND_ARG_INFO(0, ErrorCode)
ZEND_END_ARG_INFO()

// SBRandom unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndTimeSeed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndInit, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndInitOnDemand, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndCreate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndDestroy, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndSeed, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Salt_or_Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndSeedTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndGenerate, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer_or_UpperBound, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndGenerateLInt, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, A, TLInt, 1)
	ZEND_ARG_INFO(0, Bytes)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndRandomize, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Seed, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndString, 0, 0, 1)
	ZEND_ARG_INFO(0, Len)
	ZEND_ARG_INFO(0, Alphabet)
ZEND_END_ARG_INFO()

// SBUtils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToStr, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Digest, 0, 0)
	ZEND_ARG_INFO(0, LowerCase)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_StrToDigest, 0, 0, 2)
	ZEND_ARG_INFO(0, DigestStr)
	ZEND_ARG_TYPE_INFO(1, Digest, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToBinary, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Digest, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_BinaryToDigest, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_TYPE_INFO(1, Digest, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToByteArray128, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Digest, TMessageDigest128, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToByteArray160, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Digest, TMessageDigest160, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToByteArray224, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Digest, TMessageDigest224, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToByteArray256, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Digest, TMessageDigest256, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToByteArray320, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Digest, TMessageDigest320, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToByteArray384, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Digest, TMessageDigest384, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToByteArray512, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Digest, TMessageDigest512, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayToDigest128, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_OBJ_INFO(1, Digest, TMessageDigest128, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayToDigest160, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_OBJ_INFO(1, Digest, TMessageDigest160, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayToDigest224, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_OBJ_INFO(1, Digest, TMessageDigest224, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayToDigest256, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_OBJ_INFO(1, Digest, TMessageDigest256, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayToDigest320, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_OBJ_INFO(1, Digest, TMessageDigest320, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayToDigest384, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_OBJ_INFO(1, Digest, TMessageDigest384, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayToDigest512, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_OBJ_INFO(1, Digest, TMessageDigest512, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SBIncPtr, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Ptr, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SBDecPtr, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Ptr, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_PointerToLIntP, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(1, B, TLInt, 0)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_PointerToLInt, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(1, B, TLInt, 0)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_LIntToPointerP, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, B, TLInt, 1)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_LIntToPointer, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, B, TLInt, 1)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_LIntToPointerTrunc, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, B, TLInt, 1)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_BufferBitCount, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_BeautifyBinaryString, 0, 0, 2)
	ZEND_ARG_INFO(0, Str)
	ZEND_ARG_INFO(0, Separator)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SwapUInt16, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Value_or_Buffer, 0, 1)
	ZEND_ARG_INFO(1, Buffer_or_Offset)
	ZEND_ARG_INFO(1, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SwapInt32, 0, 0, 1)
	ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SwapUInt32, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value_or_Buffer_or_value, 0, 1)
	ZEND_ARG_INFO(1, Buffer_or_Offset)
	ZEND_ARG_INFO(1, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SwapInt64, 0, 0, 1)
	ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SwapSomeInt, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_RotateInteger, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_TrimZeros, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SubArray, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Arr, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SwapBigEndianWords, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SwapBigEndianDWords, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_IsEmptyDateTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_EmptyDateTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayFromPtr, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_TrimLeadingZeros, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, V, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_TrimTrailingZeros, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, V, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_PrefixByteArray, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SuffixByteArray, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_FillByteArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, SrcOffset_or_Value)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetBytes64, 0, 0, 1)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetBytes32, 0, 0, 1)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetBytes16, 0, 0, 1)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetBytes8, 0, 0, 1)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_LocalDateTimeToSystemDateTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ADateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SystemDateTimeToLocalDateTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ADateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeAddMillis, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
	ZEND_ARG_INFO(0, Millis)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeAddDays, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
	ZEND_ARG_INFO(0, Days)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeAddHours, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
	ZEND_ARG_INFO(0, Hours)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeAddMinutes, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
	ZEND_ARG_INFO(0, Minutes)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeAddSeconds, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
	ZEND_ARG_INFO(0, Seconds)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeAddYears, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
	ZEND_ARG_INFO(0, Years)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeAfter, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DT1, DateTime, 0)
	ZEND_ARG_OBJ_INFO(0, DT2, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeBefore, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DT1, DateTime, 0)
	ZEND_ARG_OBJ_INFO(0, DT2, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeClone, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeCompare, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DT1, DateTime, 0)
	ZEND_ARG_OBJ_INFO(0, DT2, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeEquals, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DT1, DateTime, 0)
	ZEND_ARG_OBJ_INFO(0, DT2, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeGetMonth, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeGetYear, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeIsLeapYear, 0, 0, 1)
	ZEND_ARG_INFO(0, Year_or_DT)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeNow, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeToString, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeUtcNow, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeGetHour, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeGetMinute, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMem, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Mem1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Mem2_or_Offset1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Mem2_or_Size, 0, 1)
	ZEND_ARG_INFO(0, Offset2)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareBuffers, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buf1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf2, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMD128, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, M1, TMessageDigest128, 0)
	ZEND_ARG_OBJ_INFO(0, M2, TMessageDigest128, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMD160, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, M1, TMessageDigest160, 0)
	ZEND_ARG_OBJ_INFO(0, M2, TMessageDigest160, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMD224, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, M1, TMessageDigest224, 0)
	ZEND_ARG_OBJ_INFO(0, M2, TMessageDigest224, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMD256, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, M1, TMessageDigest256, 0)
	ZEND_ARG_OBJ_INFO(0, M2, TMessageDigest256, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMD320, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, M1, TMessageDigest320, 0)
	ZEND_ARG_OBJ_INFO(0, M2, TMessageDigest320, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMD384, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, M1, TMessageDigest384, 0)
	ZEND_ARG_OBJ_INFO(0, M2, TMessageDigest384, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMD512, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, M1, TMessageDigest512, 0)
	ZEND_ARG_OBJ_INFO(0, M2, TMessageDigest512, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareHashes, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Hash1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Hash2_or_StartIndex1_or_Len1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Count1_or_Hash2, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Hash2_or_Len2, 0, 1)
	ZEND_ARG_INFO(0, StartIndex2)
	ZEND_ARG_INFO(0, Count2)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_FreeAndNil, 0, 0, 1)
	ZEND_ARG_INFO(1, Obj)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetDigestSizeBits, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_EncodeDSASignature, 0, 0, 6)
	ZEND_ARG_TYPE_INFO(0, R, 0, 1)
	ZEND_ARG_INFO(0, RSize)
	ZEND_ARG_TYPE_INFO(0, S, 0, 1)
	ZEND_ARG_INFO(0, SSize)
	ZEND_ARG_TYPE_INFO(0, Blob, 0, 1)
	ZEND_ARG_INFO(1, BlobSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DecodeDSASignature, 0, 0, 6)
	ZEND_ARG_TYPE_INFO(0, Blob, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, R, 0, 1)
	ZEND_ARG_INFO(1, RSize)
	ZEND_ARG_TYPE_INFO(0, S, 0, 1)
	ZEND_ARG_INFO(1, SSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareAnsiStr, 0, 0, 2)
	ZEND_ARG_INFO(0, Content)
	ZEND_ARG_INFO(0, OID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ChangeByteOrder, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_BinaryToString, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Start_or_BufSize)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_StringToBinary, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareGUID, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Guid1, TGuid, 0)
	ZEND_ARG_OBJ_INFO(0, Guid2, TGuid, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_AnsiStringOfBytes, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Src, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ArrayStartsWith, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, SubP, 0, 1)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareArrays, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buf1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf2, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CreateByteArrayConst, 0, 0, 1)
	ZEND_ARG_INFO(0, Src)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_AnsiStringOfString, 0, 0, 1)
	ZEND_ARG_INFO(0, Source)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_StringOfAnsiString, 0, 0, 1)
	ZEND_ARG_INFO(0, Source)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_BytesOfAnsiString, 0, 0, 1)
	ZEND_ARG_INFO(0, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromByte, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_TYPE_INFO(0, Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromBytes, 0, 0, 2)
	ZEND_ARG_INFO(0, Value1)
	ZEND_ARG_INFO(0, Value2)
	ZEND_ARG_TYPE_INFO(0, Dest_or_Value3, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Position_or_Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromWordLE, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_TYPE_INFO(0, Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromWordBE, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_TYPE_INFO(0, Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromDWordLE, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_TYPE_INFO(0, Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromDWordBE, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_TYPE_INFO(0, Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromInt64LE, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_TYPE_INFO(0, Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromInt64BE, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_TYPE_INFO(0, Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetWordLEFromByteArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetWordBEFromByteArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetDWordLEFromByteArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetDWordBEFromByteArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetInt64LEFromByteArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetInt64BEFromByteArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SBBoolToStr, 0, 0, 1)
	ZEND_ARG_INFO(0, B)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SBStrToBool, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_WideStringOf, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_WideBytesOf, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SBConcatArrays, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buf1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf2, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf3, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ArrayEndsWith, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Substr, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateStrToDate, 0, 0, 2)
	ZEND_ARG_INFO(0, Time)
	ZEND_ARG_OBJ_INFO(1, ADateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ParseRFC822TimeString, 0, 0, 2)
	ZEND_ARG_INFO(0, RFC822TimeString)
	ZEND_ARG_OBJ_INFO(1, ADateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_RFC822TimeToDateTime, 0, 0, 1)
	ZEND_ARG_INFO(0, RFC822Time)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_UTCTimeToDate, 0, 0, 2)
	ZEND_ARG_INFO(0, UTCTime)
	ZEND_ARG_INFO(0, FourDigitYear)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_UTCTimeToTime, 0, 0, 2)
	ZEND_ARG_INFO(0, UTCTime)
	ZEND_ARG_INFO(0, FourDigitYear)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_UTCTimeToDateTime, 0, 0, 2)
	ZEND_ARG_INFO(0, UTCTime)
	ZEND_ARG_INFO(0, FourDigitYear)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GeneralizedTimeToDate, 0, 0, 1)
	ZEND_ARG_INFO(0, GenTime)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GeneralizedTimeToTime, 0, 0, 1)
	ZEND_ARG_INFO(0, GenTime)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GeneralizedTimeToDateTime, 0, 0, 1)
	ZEND_ARG_INFO(0, GenTime)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeToUTCTime, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, ADateTime, DateTime, 0)
	ZEND_ARG_INFO(0, FourDigitYear)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeToGeneralizedTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ADateTime, DateTime, 0)
	ZEND_ARG_INFO(0, DateTimeSplitPtn)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_UniversalDateTimeToRFC822DateTimeString, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_RFC822TimeStringToUniversalTime, 0, 0, 2)
	ZEND_ARG_INFO(0, TS)
	ZEND_ARG_OBJ_INFO(1, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_LocalDateTimeToRFC822DateTimeString, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ADateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SystemDateTimeToRFC822DateTimeString, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ADateTime, DateTime, 0)
ZEND_END_ARG_INFO()

#else
	// SBXMLSAMLCommon unit class registration
	Register_TElSAMLClientSettings(TSRMLS_C);
	Register_TElSAMLSession(TSRMLS_C);
	Register_TElCustomSessionManager(TSRMLS_C);
	Register_TElMemorySessionManager(TSRMLS_C);
	Register_SBXMLSAMLCommon_TElStringValue(TSRMLS_C);
	Register_TElCustomArtifactStorage(TSRMLS_C);
	Register_TElMemoryArtifactStorage(TSRMLS_C);
	Register_TElSAMLAdapter(TSRMLS_C);
	Register_SBXMLSAMLCommon_Enum_Flags(TSRMLS_C);

	// SBXMLSAMLCore unit class registration
	Register_TElSAMLElement(TSRMLS_C);
	Register_TElSAMLConditionsElement(TSRMLS_C);
	Register_TElSAMLAdviceElement(TSRMLS_C);
	Register_TElSAMLSubjectConfirmationDataElement(TSRMLS_C);
	Register_TElSAMLStatementAbstractType(TSRMLS_C);
	Register_TElSAMLSubjectConfirmationElement(TSRMLS_C);
	Register_TElSAMLSecurityHandler(TSRMLS_C);
	Register_TElSAMLSignatureHandler(TSRMLS_C);
	Register_TElSAMLEncryptionHandler(TSRMLS_C);
	Register_TElSAMLSubjectElement(TSRMLS_C);
	Register_TElSAMLID(TSRMLS_C);
	Register_TElSAMLBaseIDElement(TSRMLS_C);
	Register_TElSAMLNameIDElement(TSRMLS_C);
	Register_TElSAMLEncryptedElement(TSRMLS_C);
	Register_TElSAMLEncryptedIDElement(TSRMLS_C);
	Register_TElSAMLIssuerElement(TSRMLS_C);
	Register_TElSAMLAssertionType(TSRMLS_C);
	Register_TElSAMLAssertionIDRefElement(TSRMLS_C);
	Register_TElSAMLAssertionURIRefElement(TSRMLS_C);
	Register_TElSAMLAssertionElement(TSRMLS_C);
	Register_TElSAMLEncryptedAssertionElement(TSRMLS_C);
	Register_TElSAMLConditionAbstractType(TSRMLS_C);
	Register_TElSAMLAudienceElement(TSRMLS_C);
	Register_TElSAMLAudienceRestrictionElement(TSRMLS_C);
	Register_TElSAMLOneTimeUseElement(TSRMLS_C);
	Register_TElSAMLProxyRestrictionElement(TSRMLS_C);
	Register_TElSAMLSubjectLocalityElement(TSRMLS_C);
	Register_TElSAMLAuthnContextElement(TSRMLS_C);
	Register_TElSAMLAuthnStatementElement(TSRMLS_C);
	Register_TElSAMLAttributeType(TSRMLS_C);
	Register_TElSAMLAttributeValue(TSRMLS_C);
	Register_TElSAMLAttributeElement(TSRMLS_C);
	Register_TElSAMLEncryptedAttributeElement(TSRMLS_C);
	Register_TElSAMLAttributeStatementElement(TSRMLS_C);
	Register_TElSAMLActionElement(TSRMLS_C);
	Register_TElSAMLEvidenceElement(TSRMLS_C);
	Register_TElSAMLAuthzDecisionStatementElement(TSRMLS_C);
	Register_SBXMLSAMLCore_Enum_Flags(TSRMLS_C);
	Register_SBXMLSAMLCore_Aliases(TSRMLS_C);

	// SBXMLSAMLMetadata unit class registration
	Register_TElSAMLMetadataRootElement(TSRMLS_C);
	Register_TElSAMLLocalizedNameType(TSRMLS_C);
	Register_TElSAMLLocalizedURIType(TSRMLS_C);
	Register_TElSAMLEndpointType(TSRMLS_C);
	Register_TElSAMLIndexedEndpointType(TSRMLS_C);
	Register_TElSAMLEntityDescriptorElement(TSRMLS_C);
	Register_TElSAMLEntitiesDescriptorElement(TSRMLS_C);
	Register_TElSAMLKeyDescriptorElement(TSRMLS_C);
	Register_TElSAMLOrganizationElement(TSRMLS_C);
	Register_TElSAMLContactPersonElement(TSRMLS_C);
	Register_TElSAMLRoleDescriptorElement(TSRMLS_C);
	Register_TElSAMLAuthnQueryServiceElement(TSRMLS_C);
	Register_TElSAMLAssertionIDRequestServiceElement(TSRMLS_C);
	Register_TElSAMLAuthnAuthorityDescriptorElement(TSRMLS_C);
	Register_TElSAMLAttributeServiceElement(TSRMLS_C);
	Register_TElSAMLAttributeAuthorityDescriptorElement(TSRMLS_C);
	Register_TElSAMLAuthzServiceElement(TSRMLS_C);
	Register_TElSAMLPDPDescriptorElement(TSRMLS_C);
	Register_TElSAMLAffiliationDescriptorElement(TSRMLS_C);
	Register_TElSAMLOrganizationNameElement(TSRMLS_C);
	Register_TElSAMLOrganizationDisplayNameElement(TSRMLS_C);
	Register_TElSAMLOrganizationURLElement(TSRMLS_C);
	Register_TElSAMLAdditionalMetadataLocationElement(TSRMLS_C);
	Register_TElSAMLArtifactResolutionServiceElement(TSRMLS_C);
	Register_TElSAMLSingleLogoutServiceElement(TSRMLS_C);
	Register_TElSAMLManageNameIDServiceElement(TSRMLS_C);
	Register_TElSAMLSingleSignOnServiceElement(TSRMLS_C);
	Register_TElSAMLNameIDMappingServiceElement(TSRMLS_C);
	Register_TElSAMLSSODescriptorType(TSRMLS_C);
	Register_TElSAMLIDPSSODescriptorElement(TSRMLS_C);
	Register_TElSAMLAssertionConsumerServiceElement(TSRMLS_C);
	Register_TElSAMLRequestedAttributeElement(TSRMLS_C);
	Register_TElSAMLServiceNameElement(TSRMLS_C);
	Register_TElSAMLServiceDescriptionElement(TSRMLS_C);
	Register_TElSAMLAttributeConsumingServiceElement(TSRMLS_C);
	Register_TElSAMLSPSSODescriptorElement(TSRMLS_C);
	Register_TElSAMLEncryptionMethodType(TSRMLS_C);
	Register_TElSAMLMetadata(TSRMLS_C);
	Register_TElSAMLEndpoint(TSRMLS_C);
	Register_SBXMLSAMLMetadata_Enum_Flags(TSRMLS_C);

	// SBXMLSAMLProtocol unit class registration
	Register_TElSAMLExtensionsElement(TSRMLS_C);
	Register_TElSAMLRequestAbstractType(TSRMLS_C);
	Register_TElSAMLStatusCodeElement(TSRMLS_C);
	Register_TElSAMLStatusMessageElement(TSRMLS_C);
	Register_TElSAMLStatusDetailElement(TSRMLS_C);
	Register_TElSAMLStatusElement(TSRMLS_C);
	Register_TElSAMLStatusResponseType(TSRMLS_C);
	Register_TElSAMLAssertionIDRequestElement(TSRMLS_C);
	Register_TElSAMLSubjectQueryAbstractType(TSRMLS_C);
	Register_TElSAMLSubjectQueryElement(TSRMLS_C);
	Register_TElSAMLRequestedAuthnContextElement(TSRMLS_C);
	Register_TElSAMLAuthnQueryElement(TSRMLS_C);
	Register_TElSAMLAttributeQueryElement(TSRMLS_C);
	Register_TElSAMLAuthzDecisionQueryElement(TSRMLS_C);
	Register_TElSAMLResponseElement(TSRMLS_C);
	Register_TElSAMLNameIDPolicyElement(TSRMLS_C);
	Register_TElSAMLIDPEntryElement(TSRMLS_C);
	Register_TElSAMLIDPListElement(TSRMLS_C);
	Register_TElSAMLScopingElement(TSRMLS_C);
	Register_TElSAMLAuthnRequestElement(TSRMLS_C);
	Register_TElSAMLArtifactResolveElement(TSRMLS_C);
	Register_TElSAMLArtifactResponseElement(TSRMLS_C);
	Register_TElSAMLManageNameIDRequestElement(TSRMLS_C);
	Register_TElSAMLManageNameIDResponseElement(TSRMLS_C);
	Register_TElSAMLLogoutRequestElement(TSRMLS_C);
	Register_TElSAMLLogoutResponseElement(TSRMLS_C);
	Register_TElSAMLNameIDMappingRequestElement(TSRMLS_C);
	Register_TElSAMLNameIDMappingResponseElement(TSRMLS_C);
	Register_SBXMLSAMLProtocol_Enum_Flags(TSRMLS_C);

	// SBSAMLIdentityProvider unit class registration
	Register_TElSAMLIDPSession(TSRMLS_C);
	Register_TElSAMLServiceProviderInfo(TSRMLS_C);
	Register_TElSAMLSPData(TSRMLS_C);
	Register_TElSAMLIDPCustomAuthSource(TSRMLS_C);
	Register_TElSAMLIDRecord(TSRMLS_C);
	Register_TElSAMLIDPPasswordMemoryAuthSource(TSRMLS_C);
	Register_TElSAMLIdPSSOLink(TSRMLS_C);
	Register_TElSAMLIdentityProvider(TSRMLS_C);
	Register_SBSAMLIdentityProvider_Enum_Flags(TSRMLS_C);

	// SBSAMLServiceProvider unit class registration
	Register_TElSAMLSPSession(TSRMLS_C);
	Register_TElSAMLRequestResult(TSRMLS_C);
	Register_TElSAMLOneTimeUseRecord(TSRMLS_C);
	Register_TElSAMLCustomOneTimeUseCache(TSRMLS_C);
	Register_TElSAMLMemoryOneTimeUseCache(TSRMLS_C);
	Register_TElSAMLServiceProvider(TSRMLS_C);
	Register_SBSAMLServiceProvider_Enum_Flags(TSRMLS_C);

	// SBDCCMS unit class registration
	Register_TElDCCMSSignOperationHandler(TSRMLS_C);
	Register_TElDCServerCMSRequestSignatureHandler(TSRMLS_C);

	// SBDCCMSClient unit class registration
	Register_TElDCClientCMSRequestSignatureHandler(TSRMLS_C);

	// SBASiCContainer unit class registration
	Register_TElASiCSignature(TSRMLS_C);
	Register_TElASiCContainer(TSRMLS_C);
	Register_TElASiCEntryHashInfo(TSRMLS_C);
	Register_TElASiCDataObjectReference(TSRMLS_C);
	Register_TElASiCManifest(TSRMLS_C);
	Register_TElASiCTimestamp(TSRMLS_C);
	Register_TElASiCCAdESSignatureEntry(TSRMLS_C);
	Register_TElASiCCAdESSignature(TSRMLS_C);
	Register_TElASiCXAdESSignatureEntry(TSRMLS_C);
	Register_TElASiCXAdESSignature(TSRMLS_C);
	Register_TElOpenDocumentXMLElement(TSRMLS_C);
	Register_TElOpenDocumentXMLManifestFileEntry(TSRMLS_C);
	Register_TElOpenDocumentXMLManifest(TSRMLS_C);
	Register_TElASiCHashingUnit(TSRMLS_C);
	Register_SBASiCContainer_Enum_Flags(TSRMLS_C);
	Register_SBASiCContainer_Aliases(TSRMLS_C);

	SB_OUTPUT_DEBUG("Module init end")
	return SUCCESS;
}

PHP_MSHUTDOWN_FUNCTION(sbb)
{
	SBCleanupEvents();
	SB_OUTPUT_DEBUG("Module shutdown")
	UNREGISTER_INI_ENTRIES();

	return SUCCESS;
}

PHP_RINIT_FUNCTION(sbb)
{
	SB_OUTPUT_DEBUG("Request init")
	return SUCCESS;
}

PHP_RSHUTDOWN_FUNCTION(sbb)
{
	SBCleanupEvents();
	SB_OUTPUT_DEBUG("Request shutdown")
	return SUCCESS;
}

PHP_MINFO_FUNCTION(sbb)
{
	SB_OUTPUT_DEBUG("Module info")
	php_info_print_table_start();
	php_info_print_table_header(2, "SecureBlackbox support", "enabled");
	php_info_print_table_row(2, "SecureBlackbox library version", SBB_VERSION_NUMBER);
	php_info_print_table_end();
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_BytesOfString, 0, 0, 1)
	ZEND_ARG_INFO(0, str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_StringOfBytes, 0, 0, 1)
	ZEND_ARG_ARRAY_INFO(0, buffer, 0)
ZEND_END_ARG_INFO()

// SBConstants unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetPBEAlgorithmByOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetOIDByPBEAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetPKAlgorithmByOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetOIDByPKAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetSigAlgorithmByOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetOIDBySigAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetHashAlgorithmByOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetOIDByHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetAlgorithmByOID, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
	ZEND_ARG_INFO(0, UseCryptoProvConstants)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetOIDByAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetAlgorithmNameByAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetAlgorithmNameByOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetHashAlgorithmBySigAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetHMACAlgorithmByHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetHashAlgorithmByHMACAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetSigAlgorithmByHashAlgorithm, 0, 0, 2)
	ZEND_ARG_INFO(0, BasePKAlg)
	ZEND_ARG_INFO(0, HashAlg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetCertAlgorithmFromNormalizedAlgorithms, 0, 0, 2)
	ZEND_ARG_INFO(0, PKAlg)
	ZEND_ARG_INFO(0, HashAlg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetKeyAlgorithmBySigAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, SigAlg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_GetSigAlgorithmByKeyAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, KeyAlg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_IsSymmetricKeyAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_IsHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_IsMACAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_IsPublicKeyAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_IsAEADAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_NormalizeAlgorithmConstant, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_MGF1AlgorithmByHash, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBConstants_HashAlgorithmByMGF1, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

// SBASN1 unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_asn1ParseStream, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Stream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, CallBack, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_asn1AddTypeEqu, 0, 0, 4)
	ZEND_ARG_INFO(0, TagType1)
	ZEND_ARG_TYPE_INFO(0, Tag1, 0, 1)
	ZEND_ARG_INFO(0, TagSize1)
	ZEND_ARG_INFO(0, TagType2_or_Tag2)
	ZEND_ARG_TYPE_INFO(0, Tag2, 0, 1)
	ZEND_ARG_INFO(0, TagSize2)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteListSequence, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Strings, TElByteArrayList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WritePrimitiveListSeq, 0, 0, 2)
	ZEND_ARG_INFO(0, Tag)
	ZEND_ARG_OBJ_INFO(0, Strings, TElByteArrayList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteExplicit, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteInteger, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data_or_Number, 0, 1)
	ZEND_ARG_INFO(0, TagID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WritePrintableString, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteUTF8String, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteIA5String, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteUTCTime, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteGeneralizedTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, T, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteBitString, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteOctetString, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteVisibleString, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteBoolean, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteNULL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WritePrimitive, 0, 0, 2)
	ZEND_ARG_INFO(0, Tag)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_WriteStringPrimitive, 0, 0, 2)
	ZEND_ARG_INFO(0, Tag)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1_ASN1ParserFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBASN1Tree unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_asymWriteInteger, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1SimpleTag, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1ReadInteger, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1SimpleTag, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1ReadInteger64, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1SimpleTag, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1WriteInteger, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1SimpleTag, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1WriteInteger64, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1SimpleTag, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1ReadSimpleValue, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(1, TagID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1WriteTagAndLength, 0, 0, 2)
	ZEND_ARG_INFO(0, Tag)
	ZEND_ARG_INFO(0, Len)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1ReadBoolean, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1SimpleTag, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1WriteBoolean, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1SimpleTag, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1ReadString, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, TagId)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1ReadStringAnsi, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, TagId)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_FormatAttributeValue, 0, 0, 2)
	ZEND_ARG_INFO(0, TagID)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_UnformatAttributeValue, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
	ZEND_ARG_INFO(1, TagID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_GetTagDisplayName, 0, 0, 1)
	ZEND_ARG_INFO(0, TagID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_GetTagByDisplayName, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_GetMaxASN1TreeDepth, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_SetMaxASN1TreeDepth, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_GetMaxASN1BufferLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_SetMaxASN1BufferLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_GetASN1CopyBuffers, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_SetASN1CopyBuffers, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBASN1Tree_ASN1TagInfoFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBMSKeyBlob unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMSKeyBlob_WriteMSPublicKeyBlob, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, BlobType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMSKeyBlob_WriteMSDSSPublicKeyBlob, 0, 0, 10)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(0, PSize)
	ZEND_ARG_TYPE_INFO(0, Q, 0, 1)
	ZEND_ARG_INFO(0, QSize)
	ZEND_ARG_TYPE_INFO(0, G, 0, 1)
	ZEND_ARG_INFO(0, GSize)
	ZEND_ARG_TYPE_INFO(0, Y, 0, 1)
	ZEND_ARG_INFO(0, YSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMSKeyBlob_ParseMSKeyBlob, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(1, BlobType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMSKeyBlob_WriteMSKeyBlob, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, BlobType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMSKeyBlob_WriteMSKeyBlobEx, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_OBJ_INFO(0, Algorithm, TElAlgorithmIdentifier, 1)
ZEND_END_ARG_INFO()

// SBPEM unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPEM_Encode, 0, 0, 7)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, Header)
	ZEND_ARG_INFO(0, Encrypt)
	ZEND_ARG_INFO(0, PassPhrase)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPEM_EncodeEx, 0, 0, 7)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, Header)
	ZEND_ARG_INFO(0, EncryptionAlgorithm)
	ZEND_ARG_INFO(0, PassPhrase_or_EncryptionMode)
	ZEND_ARG_INFO(0, PassPhrase)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPEM_Decode, 0, 0, 6)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(0, PassPhrase)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(1, Header)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPEM_IsBase64UnicodeSequence, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPEM_IsBase64Sequence, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPEM_IsPEMSequence, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPEM_RaisePEMError, 0, 0, 1)
	ZEND_ARG_INFO(0, ErrorCode)
ZEND_END_ARG_INFO()

// SBRandom unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndTimeSeed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndInit, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndInitOnDemand, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndCreate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndDestroy, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndSeed, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Salt_or_Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndSeedTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndGenerate, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer_or_UpperBound, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndGenerateLInt, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, A, TLInt, 1)
	ZEND_ARG_INFO(0, Bytes)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndRandomize, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Seed, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRandom_SBRndString, 0, 0, 1)
	ZEND_ARG_INFO(0, Len)
	ZEND_ARG_INFO(0, Alphabet)
ZEND_END_ARG_INFO()

// SBUtils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToStr, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Digest, 0, 0)
	ZEND_ARG_INFO(0, LowerCase)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_StrToDigest, 0, 0, 2)
	ZEND_ARG_INFO(0, DigestStr)
	ZEND_ARG_TYPE_INFO(1, Digest, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToBinary, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Digest, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_BinaryToDigest, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_TYPE_INFO(1, Digest, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToByteArray128, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Digest, TMessageDigest128, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToByteArray160, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Digest, TMessageDigest160, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToByteArray224, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Digest, TMessageDigest224, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToByteArray256, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Digest, TMessageDigest256, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToByteArray320, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Digest, TMessageDigest320, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToByteArray384, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Digest, TMessageDigest384, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DigestToByteArray512, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Digest, TMessageDigest512, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayToDigest128, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_OBJ_INFO(1, Digest, TMessageDigest128, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayToDigest160, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_OBJ_INFO(1, Digest, TMessageDigest160, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayToDigest224, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_OBJ_INFO(1, Digest, TMessageDigest224, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayToDigest256, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_OBJ_INFO(1, Digest, TMessageDigest256, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayToDigest320, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_OBJ_INFO(1, Digest, TMessageDigest320, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayToDigest384, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_OBJ_INFO(1, Digest, TMessageDigest384, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayToDigest512, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Binary, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_OBJ_INFO(1, Digest, TMessageDigest512, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SBIncPtr, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Ptr, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SBDecPtr, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Ptr, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_PointerToLIntP, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(1, B, TLInt, 0)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_PointerToLInt, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(1, B, TLInt, 0)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_LIntToPointerP, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, B, TLInt, 1)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_LIntToPointer, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, B, TLInt, 1)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_LIntToPointerTrunc, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, B, TLInt, 1)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_BufferBitCount, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_BeautifyBinaryString, 0, 0, 2)
	ZEND_ARG_INFO(0, Str)
	ZEND_ARG_INFO(0, Separator)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SwapUInt16, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Value_or_Buffer, 0, 1)
	ZEND_ARG_INFO(1, Buffer_or_Offset)
	ZEND_ARG_INFO(1, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SwapInt32, 0, 0, 1)
	ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SwapUInt32, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value_or_Buffer_or_value, 0, 1)
	ZEND_ARG_INFO(1, Buffer_or_Offset)
	ZEND_ARG_INFO(1, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SwapInt64, 0, 0, 1)
	ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SwapSomeInt, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_RotateInteger, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_TrimZeros, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SubArray, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Arr, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SwapBigEndianWords, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SwapBigEndianDWords, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_IsEmptyDateTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_EmptyDateTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ByteArrayFromPtr, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_TrimLeadingZeros, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, V, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_TrimTrailingZeros, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, V, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_PrefixByteArray, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SuffixByteArray, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_FillByteArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, SrcOffset_or_Value)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetBytes64, 0, 0, 1)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetBytes32, 0, 0, 1)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetBytes16, 0, 0, 1)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetBytes8, 0, 0, 1)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_LocalDateTimeToSystemDateTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ADateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SystemDateTimeToLocalDateTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ADateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeAddMillis, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
	ZEND_ARG_INFO(0, Millis)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeAddDays, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
	ZEND_ARG_INFO(0, Days)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeAddHours, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
	ZEND_ARG_INFO(0, Hours)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeAddMinutes, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
	ZEND_ARG_INFO(0, Minutes)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeAddSeconds, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
	ZEND_ARG_INFO(0, Seconds)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeAddYears, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
	ZEND_ARG_INFO(0, Years)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeAfter, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DT1, DateTime, 0)
	ZEND_ARG_OBJ_INFO(0, DT2, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeBefore, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DT1, DateTime, 0)
	ZEND_ARG_OBJ_INFO(0, DT2, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeClone, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeCompare, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DT1, DateTime, 0)
	ZEND_ARG_OBJ_INFO(0, DT2, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeEquals, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, DT1, DateTime, 0)
	ZEND_ARG_OBJ_INFO(0, DT2, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeGetMonth, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeGetYear, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeIsLeapYear, 0, 0, 1)
	ZEND_ARG_INFO(0, Year_or_DT)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeNow, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeToString, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeUtcNow, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeGetHour, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeGetMinute, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMem, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Mem1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Mem2_or_Offset1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Mem2_or_Size, 0, 1)
	ZEND_ARG_INFO(0, Offset2)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareBuffers, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buf1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf2, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMD128, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, M1, TMessageDigest128, 0)
	ZEND_ARG_OBJ_INFO(0, M2, TMessageDigest128, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMD160, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, M1, TMessageDigest160, 0)
	ZEND_ARG_OBJ_INFO(0, M2, TMessageDigest160, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMD224, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, M1, TMessageDigest224, 0)
	ZEND_ARG_OBJ_INFO(0, M2, TMessageDigest224, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMD256, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, M1, TMessageDigest256, 0)
	ZEND_ARG_OBJ_INFO(0, M2, TMessageDigest256, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMD320, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, M1, TMessageDigest320, 0)
	ZEND_ARG_OBJ_INFO(0, M2, TMessageDigest320, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMD384, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, M1, TMessageDigest384, 0)
	ZEND_ARG_OBJ_INFO(0, M2, TMessageDigest384, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareMD512, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, M1, TMessageDigest512, 0)
	ZEND_ARG_OBJ_INFO(0, M2, TMessageDigest512, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareHashes, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Hash1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Hash2_or_StartIndex1_or_Len1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Count1_or_Hash2, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Hash2_or_Len2, 0, 1)
	ZEND_ARG_INFO(0, StartIndex2)
	ZEND_ARG_INFO(0, Count2)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_FreeAndNil, 0, 0, 1)
	ZEND_ARG_INFO(1, Obj)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetDigestSizeBits, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_EncodeDSASignature, 0, 0, 6)
	ZEND_ARG_TYPE_INFO(0, R, 0, 1)
	ZEND_ARG_INFO(0, RSize)
	ZEND_ARG_TYPE_INFO(0, S, 0, 1)
	ZEND_ARG_INFO(0, SSize)
	ZEND_ARG_TYPE_INFO(0, Blob, 0, 1)
	ZEND_ARG_INFO(1, BlobSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DecodeDSASignature, 0, 0, 6)
	ZEND_ARG_TYPE_INFO(0, Blob, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, R, 0, 1)
	ZEND_ARG_INFO(1, RSize)
	ZEND_ARG_TYPE_INFO(0, S, 0, 1)
	ZEND_ARG_INFO(1, SSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareAnsiStr, 0, 0, 2)
	ZEND_ARG_INFO(0, Content)
	ZEND_ARG_INFO(0, OID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ChangeByteOrder, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_BinaryToString, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Start_or_BufSize)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_StringToBinary, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareGUID, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Guid1, TGuid, 0)
	ZEND_ARG_OBJ_INFO(0, Guid2, TGuid, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_AnsiStringOfBytes, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Src, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ArrayStartsWith, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, SubP, 0, 1)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareArrays, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buf1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf2, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CreateByteArrayConst, 0, 0, 1)
	ZEND_ARG_INFO(0, Src)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_AnsiStringOfString, 0, 0, 1)
	ZEND_ARG_INFO(0, Source)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_StringOfAnsiString, 0, 0, 1)
	ZEND_ARG_INFO(0, Source)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_BytesOfAnsiString, 0, 0, 1)
	ZEND_ARG_INFO(0, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromByte, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_TYPE_INFO(0, Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromBytes, 0, 0, 2)
	ZEND_ARG_INFO(0, Value1)
	ZEND_ARG_INFO(0, Value2)
	ZEND_ARG_TYPE_INFO(0, Dest_or_Value3, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Position_or_Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromWordLE, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_TYPE_INFO(0, Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromWordBE, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_TYPE_INFO(0, Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromDWordLE, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_TYPE_INFO(0, Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromDWordBE, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_TYPE_INFO(0, Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromInt64LE, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_TYPE_INFO(0, Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetByteArrayFromInt64BE, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_TYPE_INFO(0, Dest, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetWordLEFromByteArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetWordBEFromByteArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetDWordLEFromByteArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetDWordBEFromByteArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetInt64LEFromByteArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetInt64BEFromByteArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SBBoolToStr, 0, 0, 1)
	ZEND_ARG_INFO(0, B)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SBStrToBool, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_WideStringOf, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_WideBytesOf, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SBConcatArrays, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buf1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf2, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf3, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ArrayEndsWith, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Substr, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateStrToDate, 0, 0, 2)
	ZEND_ARG_INFO(0, Time)
	ZEND_ARG_OBJ_INFO(1, ADateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ParseRFC822TimeString, 0, 0, 2)
	ZEND_ARG_INFO(0, RFC822TimeString)
	ZEND_ARG_OBJ_INFO(1, ADateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_RFC822TimeToDateTime, 0, 0, 1)
	ZEND_ARG_INFO(0, RFC822Time)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_UTCTimeToDate, 0, 0, 2)
	ZEND_ARG_INFO(0, UTCTime)
	ZEND_ARG_INFO(0, FourDigitYear)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_UTCTimeToTime, 0, 0, 2)
	ZEND_ARG_INFO(0, UTCTime)
	ZEND_ARG_INFO(0, FourDigitYear)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_UTCTimeToDateTime, 0, 0, 2)
	ZEND_ARG_INFO(0, UTCTime)
	ZEND_ARG_INFO(0, FourDigitYear)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GeneralizedTimeToDate, 0, 0, 1)
	ZEND_ARG_INFO(0, GenTime)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GeneralizedTimeToTime, 0, 0, 1)
	ZEND_ARG_INFO(0, GenTime)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GeneralizedTimeToDateTime, 0, 0, 1)
	ZEND_ARG_INFO(0, GenTime)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeToUTCTime, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, ADateTime, DateTime, 0)
	ZEND_ARG_INFO(0, FourDigitYear)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeToGeneralizedTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ADateTime, DateTime, 0)
	ZEND_ARG_INFO(0, DateTimeSplitPtn)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_UniversalDateTimeToRFC822DateTimeString, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_RFC822TimeStringToUniversalTime, 0, 0, 2)
	ZEND_ARG_INFO(0, TS)
	ZEND_ARG_OBJ_INFO(1, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_LocalDateTimeToRFC822DateTimeString, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ADateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SystemDateTimeToRFC822DateTimeString, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ADateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_FileTimeToUnixTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, _FILETIME, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_UnixTimeToFileTime, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()
#endif

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_FileTimeToDateTime, 0, 0, 1)
#ifdef SB_WINDOWS
	ZEND_ARG_OBJ_INFO(0, Value, windows_FILETIME, 0)
#else
	ZEND_ARG_OBJ_INFO(0, Value, _FILETIME, 0)
#endif
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeToFileTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_UnixTimeToDateTime, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeToUnixTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ConstLength, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Arr, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_TickDiff, 0, 0, 2)
	ZEND_ARG_INFO(0, Previous)
	ZEND_ARG_INFO(0, Current)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GenerateGUID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_IsTextualOID, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_IsWindowsOS, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_WaitFor, 0, 0, 1)
#ifdef SB_WINDOWS
	ZEND_ARG_INFO(0, Handle)
#else
	ZEND_ARG_OBJ_INFO(0, Thread, TThread, 1)
#endif
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_LocalTimeToUTCTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, LocalTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_UTCTimeToLocalTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, UtcTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_UTCNow, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_RegisterGlobalObject, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, O, TObject, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_UnregisterGlobalObject, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, O, TObject, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CleanupRegisteredGlobalObjects, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_AcquireGlobalLock, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ReleaseGlobalLock, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_HexDump, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(0, Len)
	ZEND_ARG_INFO(0, AddChars)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SBSameDateTime, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, A, DateTime, 0)
	ZEND_ARG_OBJ_INFO(0, B, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SBSameDate, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, A, DateTime, 0)
	ZEND_ARG_OBJ_INFO(0, B, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SBSameTime, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, A, DateTime, 0)
	ZEND_ARG_OBJ_INFO(0, B, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SBEncodeDateTime, 0, 0, 7)
	ZEND_ARG_INFO(0, Year)
	ZEND_ARG_INFO(0, Month)
	ZEND_ARG_INFO(0, Day)
	ZEND_ARG_INFO(0, Hour)
	ZEND_ARG_INFO(0, Minute)
	ZEND_ARG_INFO(0, Second)
	ZEND_ARG_INFO(0, Millisecond)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetUTCOffsetDateTime, 0, 0, 0)
	ZEND_ARG_OBJ_INFO(0, ADateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_CompareContent, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Content, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID_or_ContentStartIndex, 0, 1)
	ZEND_ARG_INFO(0, ContentLen)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
	ZEND_ARG_INFO(0, OIDStartIndex)
	ZEND_ARG_INFO(0, OIDLen)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeToISO8601Time, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Time, DateTime, 0)
	ZEND_ARG_INFO(0, EncodeMilliseconds)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_ISO8601TimeToDateTime, 0, 0, 1)
	ZEND_ARG_INFO(0, EncodedTime)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DateTimeToRFC3339, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
	ZEND_ARG_INFO(0, EncodeMilliseconds)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SetLicenseKey, 0, 0, 1)
	ZEND_ARG_INFO(0, Key)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_AppendSlash, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_EnsureDirectoryExists, 0, 0, 1)
	ZEND_ARG_INFO(0, DirName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_DirectoryExists, 0, 0, 1)
	ZEND_ARG_INFO(0, DirName)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SetDefaultExceptionHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElCustomExceptionHandler, 1)
#else
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetCurrentThreadID, 0, 0, 0)
#endif
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetDefaultExceptionHandler, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SetDefaultGlobalLogger, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Logger, TElCustomGlobalLogger, 1)
	ZEND_ARG_INFO(0, FreeOnRemoval)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetDefaultGlobalLogger, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_RecordEntryInGlobalLog, 0, 0, 3)
	ZEND_ARG_INFO(0, Level)
	ZEND_ARG_INFO(0, Source)
	ZEND_ARG_INFO(0, Line)
ZEND_END_ARG_INFO()

// SBStrUtils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringEndsWith, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, SubS)
	ZEND_ARG_INFO(0, IgnoreCase)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringEquals, 0, 0, 2)
	ZEND_ARG_INFO(0, S1)
	ZEND_ARG_INFO(0, S2_or_Index1)
	ZEND_ARG_INFO(0, IgnoreCase_or_MaxLength_or_S2)
	ZEND_ARG_INFO(0, IgnoreCase_or_Index2)
	ZEND_ARG_INFO(0, MaxLength)
	ZEND_ARG_INFO(0, IgnoreCase)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringIndexOf, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, C_or_SubS)
	ZEND_ARG_INFO(0, StartIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringIndexOfU, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, C)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringInsert, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, C_or_SubS)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringIsEmpty, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringLastIndexOf, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, C)
	ZEND_ARG_INFO(0, StartIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringRemove, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_WideStringRemove, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_AnsiStringRemove, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringToLower, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringToLowerInvariant, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringStartsWith, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, SubS)
	ZEND_ARG_INFO(0, IgnoreCase)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringSubstring, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Length)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringCopy, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringTrim, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringTrimEnd, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringTrimStart, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringToUpper, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringToUpperInvariant, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringSplit, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, Separator)
	ZEND_ARG_INFO(0, RemoveEmptyEntries)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringSplitPV, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(1, Name)
	ZEND_ARG_INFO(1, Value)
	ZEND_ARG_INFO(0, Separator)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringPadLeft, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, C)
	ZEND_ARG_INFO(0, Len)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringPadRight, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, C)
	ZEND_ARG_INFO(0, Len)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StrToDefEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, AStr)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_DefEncodingToStr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ASrc, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StrToStdEncoding, 0, 0, 2)
	ZEND_ARG_INFO(0, AStr)
	ZEND_ARG_INFO(0, UseUTF8)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StdEncodingToStr, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, ASrc, 0, 1)
	ZEND_ARG_INFO(0, UseUTF8)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBExtractFilePath, 0, 0, 1)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBExtractFileName, 0, 0, 1)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBExtractFileExt, 0, 0, 1)
	ZEND_ARG_INFO(0, FileName)
	ZEND_ARG_INFO(0, IncludeDot)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ReplaceExt, 0, 0, 2)
	ZEND_ARG_INFO(0, FileName)
	ZEND_ARG_INFO(0, NewExtension)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_FilenameMatchesMask, 0, 0, 3)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Mask)
	ZEND_ARG_INFO(0, CaseSensitive)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_DomainNameMatchesCertSN, 0, 0, 2)
	ZEND_ARG_INFO(0, DomainName)
	ZEND_ARG_INFO(0, Match)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_CountFoldersInPath, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ParseURL, 0, 0, 10)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_INFO(0, SingleNameIsPage)
	ZEND_ARG_INFO(1, Protocol)
	ZEND_ARG_INFO(1, Username)
	ZEND_ARG_INFO(1, Password)
	ZEND_ARG_INFO(1, Host)
	ZEND_ARG_INFO(1, Port)
	ZEND_ARG_INFO(1, Path)
	ZEND_ARG_INFO(1, anchor)
	ZEND_ARG_INFO(1, Parameters)
	ZEND_ARG_INFO(0, DefaultProtocol)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ComposeURL, 0, 0, 8)
	ZEND_ARG_INFO(0, Protocol)
	ZEND_ARG_INFO(0, UserName)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_INFO(0, Host)
	ZEND_ARG_INFO(0, Port)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_INFO(0, Anchor)
	ZEND_ARG_INFO(0, Parameters)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBRightPos, 0, 0, 2)
	ZEND_ARG_INFO(0, Substr)
	ZEND_ARG_INFO(0, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBPos, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, substr_or_SubP, 0, 1)
	ZEND_ARG_TYPE_INFO(0, str_or_P, 0, 1)
	ZEND_ARG_INFO(0, StartPos)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBCopy, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, str, 0, 1)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBConcatAnsiStrings, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Str1_or_Strs, 0, 1)
	ZEND_ARG_INFO(0, Str2)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_OIDToStr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StrToOID, 0, 0, 1)
	ZEND_ARG_INFO(0, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StrToUTF8, 0, 0, 1)
	ZEND_ARG_INFO(0, AStr)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_UTF8ToStr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ASrc, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StrToWideStr, 0, 0, 1)
	ZEND_ARG_INFO(0, AStr)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_WideStrToStr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ASrc, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_EncodeString, 0, 0, 2)
	ZEND_ARG_INFO(0, AStr)
	ZEND_ARG_INFO(0, Encoding)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_DecodeString, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, ASrc, 0, 1)
	ZEND_ARG_INFO(0, Encoding)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_UnicodeChangeEndianness, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_WideStrToUTF8, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AStr_or_ASrc, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_UTF8ToWideStr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ConvertUTF16toUTF8, 0, 0, 4)
	ZEND_ARG_INFO(0, source)
	ZEND_ARG_INFO(1, target)
	ZEND_ARG_INFO(0, flags)
	ZEND_ARG_INFO(0, BOM)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_isLegalUTF8, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, source, 0, 1)
	ZEND_ARG_INFO(0, sourcelen)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ConvertUTF8toUTF16, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, source, 0, 1)
	ZEND_ARG_INFO(1, target)
	ZEND_ARG_INFO(0, flags)
	ZEND_ARG_INFO(0, BOM)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ConvertFromUTF8String, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, CheckBOM)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ConvertToUTF8String, 0, 0, 1)
	ZEND_ARG_INFO(0, Source)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ConvertFromUTF32String, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, CheckBOM)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SetGlobalStringConverter, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Converter, TElStringConverter, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SetDefaultCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Charset)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StrMixToInt64, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBTrim, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, S, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBUppercase, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, S, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringReplace, 0, 0, 3)
	ZEND_ARG_INFO(0, Source)
	ZEND_ARG_INFO(0, Entry)
	ZEND_ARG_INFO(0, ReplaceWith)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PrefixString, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SuffixString, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathFirstComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathLastComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathCutFirstComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathCutLastComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathIsDirectory, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathTrim, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathConcatenate, 0, 0, 2)
	ZEND_ARG_INFO(0, Path1)
	ZEND_ARG_INFO(0, Path2)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathNormalizeSlashes, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathReverseSlashes, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathMatchesMask, 0, 0, 2)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_INFO(0, Mask)
	ZEND_ARG_INFO(0, CaseSensitive)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_IsFileMask, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ExtractPathFromMask, 0, 0, 1)
	ZEND_ARG_INFO(0, Mask)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SftpNormalizePath, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathFirstComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathLastComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathCutFirstComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathCutLastComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathIsDirectory, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathTrim, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathConcatenate, 0, 0, 2)
	ZEND_ARG_INFO(0, Path1)
	ZEND_ARG_INFO(0, Path2)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathNormalizeSlashes, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathReverseSlashes, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathMatchesMask, 0, 0, 2)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_INFO(0, Mask)
	ZEND_ARG_INFO(0, CaseSensitive)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipIsFileMask, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipExtractPathFromMask, 0, 0, 1)
	ZEND_ARG_INFO(0, Mask)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PosExSafe, 0, 0, 4)
	ZEND_ARG_INFO(0, SubStr)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PosLast, 0, 0, 2)
	ZEND_ARG_INFO(0, SubStr)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_WidePosEx, 0, 0, 4)
	ZEND_ARG_INFO(0, SubStr)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_WidePosLast, 0, 0, 2)
	ZEND_ARG_INFO(0, SubStr)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_WideStringToByteString, 0, 0, 1)
	ZEND_ARG_INFO(0, WS)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_AnsiStringToByteWideString, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_IntToStrPadLeft, 0, 0, 3)
	ZEND_ARG_INFO(0, Val)
	ZEND_ARG_INFO(0, iWidth)
	ZEND_ARG_INFO(0, chTemplate)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_GetWideBytesOf, 0, 0, 2)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_INFO(1, B)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_GetStringOf, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Bytes, 0, 1)
	ZEND_ARG_INFO(1, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_GetStringOfEx, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Bytes, 0, 1)
	ZEND_ARG_INFO(1, S)
	ZEND_ARG_INFO(0, LPos)
	ZEND_ARG_INFO(0, RPos)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_GetWideStringOf, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Bytes, 0, 1)
	ZEND_ARG_INFO(1, WS)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_TrimEx, 0, 0, 3)
	ZEND_ARG_INFO(1, S)
	ZEND_ARG_INFO(0, bTrimLeft)
	ZEND_ARG_INFO(0, bTrimRight)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_TrimSemicolon, 0, 0, 1)
	ZEND_ARG_INFO(1, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ExtractWideFileName, 0, 0, 1)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ExtractFileExtension, 0, 0, 1)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ExtractWideFileExtension, 0, 0, 1)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_WideTrimRight, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_DecodeDateTime, 0, 0, 8)
	ZEND_ARG_OBJ_INFO(0, AValue, DateTime, 0)
	ZEND_ARG_INFO(1, AYear)
	ZEND_ARG_INFO(1, AMonth)
	ZEND_ARG_INFO(1, ADay)
	ZEND_ARG_INFO(1, AHour)
	ZEND_ARG_INFO(1, AMinute)
	ZEND_ARG_INFO(1, ASecond)
	ZEND_ARG_INFO(1, AMilliSecond)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBDecStr2ToIntDef, 0, 0, 4)
	ZEND_ARG_INFO(0, SourceString)
	ZEND_ARG_INFO(0, StartOffset)
	ZEND_ARG_INFO(0, DefaultValue)
	ZEND_ARG_INFO(0, SkipLengthCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBDecStr3ToIntDef, 0, 0, 4)
	ZEND_ARG_INFO(0, SourceString)
	ZEND_ARG_INFO(0, StartOffset)
	ZEND_ARG_INFO(0, DefaultValue)
	ZEND_ARG_INFO(0, SkipLengthCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBDecStr4ToIntDef, 0, 0, 4)
	ZEND_ARG_INFO(0, SourceString)
	ZEND_ARG_INFO(0, StartOffset)
	ZEND_ARG_INFO(0, DefaultValue)
	ZEND_ARG_INFO(0, SkipLengthCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBStringZToString, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, CS, 0, 1)
ZEND_END_ARG_INFO()

// SBStreams unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_CopyStream, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(0, SrcStream_or_Source, TStream, 1)
	ZEND_ARG_OBJ_INFO(0, DestStream_or_Dest, TStream, 1)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, PreservePosition)
	ZEND_ARG_TYPE_INFO(0, ProgressEvent, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamPosition, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamSize, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_SetStreamPosition, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamSetPosition, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, NewPosition)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamSkip, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamRewind, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamRead, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamReadAll, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamReadByte, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamWrite, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Offset_or_Size)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamWriteLn, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Text)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamClear, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

// SBEncoding unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B64EstimateEncodedSize, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Ctx, TSBBase64Context, 0)
	ZEND_ARG_INFO(0, InSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B64InitializeEncoding, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(1, Ctx, TSBBase64Context, 0)
	ZEND_ARG_INFO(0, LineSize)
	ZEND_ARG_INFO(0, fEOL)
	ZEND_ARG_INFO(0, TrailingEOL)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B64InitializeDecoding, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(1, Ctx, TSBBase64Context, 0)
	ZEND_ARG_INFO(0, LiberalMode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B64Encode, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(1, Ctx, TSBBase64Context, 0)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B64Decode, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(1, Ctx, TSBBase64Context, 0)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B64FinalizeEncoding, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(1, Ctx, TSBBase64Context, 0)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B64FinalizeDecoding, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(1, Ctx, TSBBase64Context, 0)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64UnicodeDecode, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64Decode, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, LiberalMode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64Encode, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, WrapLines)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64EncodeString, 0, 0, 2)
	ZEND_ARG_INFO(0, InText)
	ZEND_ARG_INFO(0, WrapLines)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64DecodeString, 0, 0, 1)
	ZEND_ARG_INFO(0, InText)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64EncodeArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, InBuf, 0, 1)
	ZEND_ARG_INFO(0, WrapLines)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64DecodeArray, 0, 0, 1)
	ZEND_ARG_INFO(0, InBuf)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64EncodeBinary, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, InBuf, 0, 1)
	ZEND_ARG_INFO(0, WrapLines)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64DecodeBinary, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InBuf, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64ToBase64Url, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64UrlToBase64, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32EstimateEncodedSize, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Context, TSBBase32Context, 0)
	ZEND_ARG_INFO(0, InSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32InitializeEncoding, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(1, Context, TSBBase32Context, 0)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32Encode, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(1, Context, TSBBase32Context, 0)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size_or_Index)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_Size, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_OutBuffer)
	ZEND_ARG_INFO(0, OutIndex)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32FinalizeEncoding, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(1, Context, TSBBase32Context, 0)
	ZEND_ARG_TYPE_INFO(1, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_OutIndex)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base32Encode, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize_or_InIndex)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_InSize, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_OutBuffer)
	ZEND_ARG_INFO(0, UseExtendedAlphabet_or_OutIndex)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base32EncodeBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base32EncodeString, 0, 0, 2)
	ZEND_ARG_INFO(0, Data)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32EstimateDecodedSize, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Context, TSBBase32Context, 0)
	ZEND_ARG_INFO(0, InSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32InitializeDecoding, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(1, Context, TSBBase32Context, 0)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32Decode, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(1, Context, TSBBase32Context, 0)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size_or_Index)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_Size, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_OutBuffer)
	ZEND_ARG_INFO(0, OutIndex)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base32Decode, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize_or_InIndex)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_InSize, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_OutBuffer)
	ZEND_ARG_INFO(0, UseExtendedAlphabet_or_OutIndex)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32FinalizeDecoding, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(1, Context, TSBBase32Context, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base32DecodeBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base32DecodeString, 0, 0, 2)
	ZEND_ARG_INFO(0, Data)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base32Extract, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, Start)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_URLEncode, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
	ZEND_ARG_INFO(0, Charset)
	ZEND_ARG_INFO(0, EncodeSlash)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_URLDecode, 0, 0, 2)
	ZEND_ARG_INFO(0, Data)
	ZEND_ARG_INFO(0, FormEncoded_or_Charset)
	ZEND_ARG_INFO(0, FormEncoded)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base16DecodeString, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
ZEND_END_ARG_INFO()

// SBCRC unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCRC_CRC32, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, Start)
ZEND_END_ARG_INFO()

// SBSocket unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSocket_AddressToString, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Addr, sockaddr_storage, 0)
	ZEND_ARG_INFO(1, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSocket_StringToAddress, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_OBJ_INFO(1, Addr, sockaddr_storage, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSocket_IsIPv6Address, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

// SBCryptoProvUtils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_CryptoProvGetBoolParam, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
	ZEND_ARG_TYPE_INFO(0, Name, 0, 1)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetIntegerPropFromBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetInt64PropFromBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetInt64PropFromString, 0, 0, 2)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetBufferFromInteger, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetBufferFromInt64, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetStringFromInt64, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetBoolFromBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetBufferFromBool, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetPointerFromBuffer, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetBufferFromPointer, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_ExtractSymmetricCipherParams, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, AlgOID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AlgParams, 0, 1)
	ZEND_ARG_INFO(1, KeyLen)
	ZEND_ARG_INFO(1, IV)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_SerializeParams, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_UnserializeParams, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_IsKeyDrivenOperation, 0, 0, 1)
	ZEND_ARG_INFO(0, OpType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_IsSecretKeyOperation, 0, 0, 1)
	ZEND_ARG_INFO(0, OpType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_IsAlgorithmIndependentOperation, 0, 0, 1)
	ZEND_ARG_INFO(0, OpType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetBoolParameter, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Pars, TElRelativeDistinguishedName, 1)
	ZEND_ARG_TYPE_INFO(0, ParName, 0, 1)
	ZEND_ARG_INFO(0, Def)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetBufferTypeParameter, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Pars, TElRelativeDistinguishedName, 1)
	ZEND_ARG_TYPE_INFO(0, ParName, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Def, 0, 1)
ZEND_END_ARG_INFO()

// SBCryptoProvDefault unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvDefault_DefaultCryptoProvider, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvDefault_SetDefaultCryptoProviderType, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCryptoProviderClass, 1)
ZEND_END_ARG_INFO()

// SBCryptoProvBuiltIn unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvBuiltIn_BuiltInCryptoProvider, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvBuiltIn_TestFileKeyContainer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvBuiltIn_CompareContainers, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Container1, TElBuiltInCryptoKeyContainerFile, 1)
	ZEND_ARG_OBJ_INFO(0, Container2, TElBuiltInCryptoKeyContainerFile, 1)
ZEND_END_ARG_INFO()

// SBCryptoProvWin32 unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvWin32_Win32CryptoProvider, 0, 0, 0)
	ZEND_ARG_OBJ_INFO(0, OptionsTemplate, TElWin32CryptoProviderOptions, 1)
ZEND_END_ARG_INFO()

#else
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SetDefaultExceptionHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElCustomExceptionHandler, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetDefaultExceptionHandler, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_SetDefaultGlobalLogger, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Logger, TElCustomGlobalLogger, 1)
	ZEND_ARG_INFO(0, FreeOnRemoval)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_GetDefaultGlobalLogger, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUtils_RecordEntryInGlobalLog, 0, 0, 3)
	ZEND_ARG_INFO(0, Level)
	ZEND_ARG_INFO(0, Source)
	ZEND_ARG_INFO(0, Line)
ZEND_END_ARG_INFO()

// SBStrUtils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringEndsWith, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, SubS)
	ZEND_ARG_INFO(0, IgnoreCase)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringEquals, 0, 0, 2)
	ZEND_ARG_INFO(0, S1)
	ZEND_ARG_INFO(0, S2_or_Index1)
	ZEND_ARG_INFO(0, IgnoreCase_or_MaxLength_or_S2)
	ZEND_ARG_INFO(0, IgnoreCase_or_Index2)
	ZEND_ARG_INFO(0, MaxLength)
	ZEND_ARG_INFO(0, IgnoreCase)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringIndexOf, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, C_or_SubS)
	ZEND_ARG_INFO(0, StartIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringIndexOfU, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, C)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringInsert, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, C_or_SubS)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringIsEmpty, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringLastIndexOf, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, C)
	ZEND_ARG_INFO(0, StartIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringRemove, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_WideStringRemove, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_AnsiStringRemove, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringToLower, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringToLowerInvariant, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringStartsWith, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, SubS)
	ZEND_ARG_INFO(0, IgnoreCase)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringSubstring, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Length)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringCopy, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringTrim, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringTrimEnd, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringTrimStart, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringToUpper, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringToUpperInvariant, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringSplit, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, Separator)
	ZEND_ARG_INFO(0, RemoveEmptyEntries)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringSplitPV, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(1, Name)
	ZEND_ARG_INFO(1, Value)
	ZEND_ARG_INFO(0, Separator)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringPadLeft, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, C)
	ZEND_ARG_INFO(0, Len)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringPadRight, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, C)
	ZEND_ARG_INFO(0, Len)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StrToDefEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, AStr)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_DefEncodingToStr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ASrc, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StrToStdEncoding, 0, 0, 2)
	ZEND_ARG_INFO(0, AStr)
	ZEND_ARG_INFO(0, UseUTF8)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StdEncodingToStr, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, ASrc, 0, 1)
	ZEND_ARG_INFO(0, UseUTF8)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBExtractFilePath, 0, 0, 1)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBExtractFileName, 0, 0, 1)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBExtractFileExt, 0, 0, 1)
	ZEND_ARG_INFO(0, FileName)
	ZEND_ARG_INFO(0, IncludeDot)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ReplaceExt, 0, 0, 2)
	ZEND_ARG_INFO(0, FileName)
	ZEND_ARG_INFO(0, NewExtension)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_FilenameMatchesMask, 0, 0, 3)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Mask)
	ZEND_ARG_INFO(0, CaseSensitive)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_DomainNameMatchesCertSN, 0, 0, 2)
	ZEND_ARG_INFO(0, DomainName)
	ZEND_ARG_INFO(0, Match)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_CountFoldersInPath, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ParseURL, 0, 0, 10)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_INFO(0, SingleNameIsPage)
	ZEND_ARG_INFO(1, Protocol)
	ZEND_ARG_INFO(1, Username)
	ZEND_ARG_INFO(1, Password)
	ZEND_ARG_INFO(1, Host)
	ZEND_ARG_INFO(1, Port)
	ZEND_ARG_INFO(1, Path)
	ZEND_ARG_INFO(1, anchor)
	ZEND_ARG_INFO(1, Parameters)
	ZEND_ARG_INFO(0, DefaultProtocol)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ComposeURL, 0, 0, 8)
	ZEND_ARG_INFO(0, Protocol)
	ZEND_ARG_INFO(0, UserName)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_INFO(0, Host)
	ZEND_ARG_INFO(0, Port)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_INFO(0, Anchor)
	ZEND_ARG_INFO(0, Parameters)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBRightPos, 0, 0, 2)
	ZEND_ARG_INFO(0, Substr)
	ZEND_ARG_INFO(0, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBPos, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, substr_or_SubP, 0, 1)
	ZEND_ARG_TYPE_INFO(0, str_or_P, 0, 1)
	ZEND_ARG_INFO(0, StartPos)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBCopy, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, str, 0, 1)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBConcatAnsiStrings, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Str1_or_Strs, 0, 1)
	ZEND_ARG_INFO(0, Str2)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_OIDToStr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StrToOID, 0, 0, 1)
	ZEND_ARG_INFO(0, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StrToUTF8, 0, 0, 1)
	ZEND_ARG_INFO(0, AStr)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_UTF8ToStr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ASrc, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StrToWideStr, 0, 0, 1)
	ZEND_ARG_INFO(0, AStr)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_WideStrToStr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ASrc, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_EncodeString, 0, 0, 2)
	ZEND_ARG_INFO(0, AStr)
	ZEND_ARG_INFO(0, Encoding)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_DecodeString, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, ASrc, 0, 1)
	ZEND_ARG_INFO(0, Encoding)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_UnicodeChangeEndianness, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_WideStrToUTF8, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AStr_or_ASrc, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_UTF8ToWideStr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ConvertUTF16toUTF8, 0, 0, 4)
	ZEND_ARG_INFO(0, source)
	ZEND_ARG_INFO(1, target)
	ZEND_ARG_INFO(0, flags)
	ZEND_ARG_INFO(0, BOM)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_isLegalUTF8, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, source, 0, 1)
	ZEND_ARG_INFO(0, sourcelen)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ConvertUTF8toUTF16, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, source, 0, 1)
	ZEND_ARG_INFO(1, target)
	ZEND_ARG_INFO(0, flags)
	ZEND_ARG_INFO(0, BOM)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ConvertFromUTF8String, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, CheckBOM)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ConvertToUTF8String, 0, 0, 1)
	ZEND_ARG_INFO(0, Source)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ConvertFromUTF32String, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, CheckBOM)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SetGlobalStringConverter, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Converter, TElStringConverter, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SetDefaultCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Charset)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StrMixToInt64, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBTrim, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, S, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBUppercase, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, S, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_StringReplace, 0, 0, 3)
	ZEND_ARG_INFO(0, Source)
	ZEND_ARG_INFO(0, Entry)
	ZEND_ARG_INFO(0, ReplaceWith)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PrefixString, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SuffixString, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathFirstComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathLastComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathCutFirstComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathCutLastComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathIsDirectory, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathTrim, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathConcatenate, 0, 0, 2)
	ZEND_ARG_INFO(0, Path1)
	ZEND_ARG_INFO(0, Path2)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathNormalizeSlashes, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathReverseSlashes, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PathMatchesMask, 0, 0, 2)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_INFO(0, Mask)
	ZEND_ARG_INFO(0, CaseSensitive)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_IsFileMask, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ExtractPathFromMask, 0, 0, 1)
	ZEND_ARG_INFO(0, Mask)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SftpNormalizePath, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathFirstComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathLastComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathCutFirstComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathCutLastComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathIsDirectory, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathTrim, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathConcatenate, 0, 0, 2)
	ZEND_ARG_INFO(0, Path1)
	ZEND_ARG_INFO(0, Path2)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathNormalizeSlashes, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathReverseSlashes, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipPathMatchesMask, 0, 0, 2)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_INFO(0, Mask)
	ZEND_ARG_INFO(0, CaseSensitive)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipIsFileMask, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ZipExtractPathFromMask, 0, 0, 1)
	ZEND_ARG_INFO(0, Mask)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PosExSafe, 0, 0, 4)
	ZEND_ARG_INFO(0, SubStr)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_PosLast, 0, 0, 2)
	ZEND_ARG_INFO(0, SubStr)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_WidePosEx, 0, 0, 4)
	ZEND_ARG_INFO(0, SubStr)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_WidePosLast, 0, 0, 2)
	ZEND_ARG_INFO(0, SubStr)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_WideStringToByteString, 0, 0, 1)
	ZEND_ARG_INFO(0, WS)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_AnsiStringToByteWideString, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_IntToStrPadLeft, 0, 0, 3)
	ZEND_ARG_INFO(0, Val)
	ZEND_ARG_INFO(0, iWidth)
	ZEND_ARG_INFO(0, chTemplate)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_GetWideBytesOf, 0, 0, 2)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_INFO(1, B)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_GetStringOf, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Bytes, 0, 1)
	ZEND_ARG_INFO(1, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_GetStringOfEx, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Bytes, 0, 1)
	ZEND_ARG_INFO(1, S)
	ZEND_ARG_INFO(0, LPos)
	ZEND_ARG_INFO(0, RPos)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_GetWideStringOf, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Bytes, 0, 1)
	ZEND_ARG_INFO(1, WS)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_TrimEx, 0, 0, 3)
	ZEND_ARG_INFO(1, S)
	ZEND_ARG_INFO(0, bTrimLeft)
	ZEND_ARG_INFO(0, bTrimRight)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_TrimSemicolon, 0, 0, 1)
	ZEND_ARG_INFO(1, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ExtractWideFileName, 0, 0, 1)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ExtractFileExtension, 0, 0, 1)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_ExtractWideFileExtension, 0, 0, 1)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_WideTrimRight, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_DecodeDateTime, 0, 0, 8)
	ZEND_ARG_OBJ_INFO(0, AValue, DateTime, 0)
	ZEND_ARG_INFO(1, AYear)
	ZEND_ARG_INFO(1, AMonth)
	ZEND_ARG_INFO(1, ADay)
	ZEND_ARG_INFO(1, AHour)
	ZEND_ARG_INFO(1, AMinute)
	ZEND_ARG_INFO(1, ASecond)
	ZEND_ARG_INFO(1, AMilliSecond)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBDecStr2ToIntDef, 0, 0, 4)
	ZEND_ARG_INFO(0, SourceString)
	ZEND_ARG_INFO(0, StartOffset)
	ZEND_ARG_INFO(0, DefaultValue)
	ZEND_ARG_INFO(0, SkipLengthCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBDecStr3ToIntDef, 0, 0, 4)
	ZEND_ARG_INFO(0, SourceString)
	ZEND_ARG_INFO(0, StartOffset)
	ZEND_ARG_INFO(0, DefaultValue)
	ZEND_ARG_INFO(0, SkipLengthCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBDecStr4ToIntDef, 0, 0, 4)
	ZEND_ARG_INFO(0, SourceString)
	ZEND_ARG_INFO(0, StartOffset)
	ZEND_ARG_INFO(0, DefaultValue)
	ZEND_ARG_INFO(0, SkipLengthCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStrUtils_SBStringZToString, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, CS, 0, 1)
ZEND_END_ARG_INFO()

// SBStreams unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_CopyStream, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(0, SrcStream_or_Source, TStream, 1)
	ZEND_ARG_OBJ_INFO(0, DestStream_or_Dest, TStream, 1)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, PreservePosition)
	ZEND_ARG_TYPE_INFO(0, ProgressEvent, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamPosition, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamSize, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_SetStreamPosition, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Position)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamSetPosition, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, NewPosition)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamSkip, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamRewind, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamRead, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamReadAll, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamReadByte, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamWrite, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Offset_or_Size)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamWriteLn, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Text)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBStreams_StreamClear, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

// SBEncoding unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B64EstimateEncodedSize, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Ctx, TSBBase64Context, 0)
	ZEND_ARG_INFO(0, InSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B64InitializeEncoding, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(1, Ctx, TSBBase64Context, 0)
	ZEND_ARG_INFO(0, LineSize)
	ZEND_ARG_INFO(0, fEOL)
	ZEND_ARG_INFO(0, TrailingEOL)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B64InitializeDecoding, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(1, Ctx, TSBBase64Context, 0)
	ZEND_ARG_INFO(0, LiberalMode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B64Encode, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(1, Ctx, TSBBase64Context, 0)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B64Decode, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(1, Ctx, TSBBase64Context, 0)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B64FinalizeEncoding, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(1, Ctx, TSBBase64Context, 0)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B64FinalizeDecoding, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(1, Ctx, TSBBase64Context, 0)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64UnicodeDecode, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64Decode, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, LiberalMode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64Encode, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, WrapLines)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64EncodeString, 0, 0, 2)
	ZEND_ARG_INFO(0, InText)
	ZEND_ARG_INFO(0, WrapLines)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64DecodeString, 0, 0, 1)
	ZEND_ARG_INFO(0, InText)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64EncodeArray, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, InBuf, 0, 1)
	ZEND_ARG_INFO(0, WrapLines)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64DecodeArray, 0, 0, 1)
	ZEND_ARG_INFO(0, InBuf)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64EncodeBinary, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, InBuf, 0, 1)
	ZEND_ARG_INFO(0, WrapLines)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64DecodeBinary, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InBuf, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64ToBase64Url, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base64UrlToBase64, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32EstimateEncodedSize, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Context, TSBBase32Context, 0)
	ZEND_ARG_INFO(0, InSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32InitializeEncoding, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(1, Context, TSBBase32Context, 0)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32Encode, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(1, Context, TSBBase32Context, 0)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size_or_Index)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_Size, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_OutBuffer)
	ZEND_ARG_INFO(0, OutIndex)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32FinalizeEncoding, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(1, Context, TSBBase32Context, 0)
	ZEND_ARG_TYPE_INFO(1, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_OutIndex)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base32Encode, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize_or_InIndex)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_InSize, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_OutBuffer)
	ZEND_ARG_INFO(0, UseExtendedAlphabet_or_OutIndex)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base32EncodeBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base32EncodeString, 0, 0, 2)
	ZEND_ARG_INFO(0, Data)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32EstimateDecodedSize, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Context, TSBBase32Context, 0)
	ZEND_ARG_INFO(0, InSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32InitializeDecoding, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(1, Context, TSBBase32Context, 0)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32Decode, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(1, Context, TSBBase32Context, 0)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size_or_Index)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_Size, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_OutBuffer)
	ZEND_ARG_INFO(0, OutIndex)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base32Decode, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, InSize_or_InIndex)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_InSize, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_OutBuffer)
	ZEND_ARG_INFO(0, UseExtendedAlphabet_or_OutIndex)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_B32FinalizeDecoding, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(1, Context, TSBBase32Context, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base32DecodeBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base32DecodeString, 0, 0, 2)
	ZEND_ARG_INFO(0, Data)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base32Extract, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, Start)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, UseExtendedAlphabet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_URLEncode, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
	ZEND_ARG_INFO(0, Charset)
	ZEND_ARG_INFO(0, EncodeSlash)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_URLDecode, 0, 0, 2)
	ZEND_ARG_INFO(0, Data)
	ZEND_ARG_INFO(0, FormEncoded_or_Charset)
	ZEND_ARG_INFO(0, FormEncoded)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBEncoding_Base16DecodeString, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
ZEND_END_ARG_INFO()

// SBCRC unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCRC_CRC32, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, Start)
ZEND_END_ARG_INFO()

// SBSocket unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSocket_AddressToString, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Addr, sockaddr_storage, 0)
	ZEND_ARG_INFO(1, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSocket_StringToAddress, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_OBJ_INFO(1, Addr, sockaddr_storage, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSocket_IsIPv6Address, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

// SBCryptoProvUtils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_CryptoProvGetBoolParam, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
	ZEND_ARG_TYPE_INFO(0, Name, 0, 1)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetIntegerPropFromBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetInt64PropFromBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetInt64PropFromString, 0, 0, 2)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetBufferFromInteger, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetBufferFromInt64, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetStringFromInt64, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetBoolFromBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetBufferFromBool, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetPointerFromBuffer, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetBufferFromPointer, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_ExtractSymmetricCipherParams, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, AlgOID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AlgParams, 0, 1)
	ZEND_ARG_INFO(1, KeyLen)
	ZEND_ARG_INFO(1, IV)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_SerializeParams, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_UnserializeParams, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_IsKeyDrivenOperation, 0, 0, 1)
	ZEND_ARG_INFO(0, OpType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_IsSecretKeyOperation, 0, 0, 1)
	ZEND_ARG_INFO(0, OpType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_IsAlgorithmIndependentOperation, 0, 0, 1)
	ZEND_ARG_INFO(0, OpType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetBoolParameter, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Pars, TElRelativeDistinguishedName, 1)
	ZEND_ARG_TYPE_INFO(0, ParName, 0, 1)
	ZEND_ARG_INFO(0, Def)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvUtils_GetBufferTypeParameter, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Pars, TElRelativeDistinguishedName, 1)
	ZEND_ARG_TYPE_INFO(0, ParName, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Def, 0, 1)
ZEND_END_ARG_INFO()

// SBCryptoProvDefault unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvDefault_DefaultCryptoProvider, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvDefault_SetDefaultCryptoProviderType, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCryptoProviderClass, 1)
ZEND_END_ARG_INFO()

// SBCryptoProvBuiltIn unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvBuiltIn_BuiltInCryptoProvider, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvBuiltIn_TestFileKeyContainer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvBuiltIn_CompareContainers, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Container1, TElBuiltInCryptoKeyContainerFile, 1)
	ZEND_ARG_OBJ_INFO(0, Container2, TElBuiltInCryptoKeyContainerFile, 1)
ZEND_END_ARG_INFO()
#endif

// SBCryptoProvManager unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvManager_DefaultCryptoProviderManager, 0, 0, 0)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvManager_FIPSCompliantCryptoProviderManager, 0, 0, 0)
ZEND_END_ARG_INFO()
#endif

// SBX509 unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBX509_PVKHeaderToByteArray, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Header, TPVKHeader, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBX509_PVK_DeriveKey, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Password, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Salt, 0, 1)
	ZEND_ARG_INFO(0, AWeakMethod)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBX509_RaiseX509Error, 0, 0, 1)
	ZEND_ARG_INFO(0, ErrorCode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBX509_SerialNumberCorresponds, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, Serial, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBX509_GetOriginalSerialNumber, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBX509_GetX509NegativeSerialWorkaround, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBX509_SetX509NegativeSerialWorkaround, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

// SBX509Ext unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBX509Ext_OctetsToIPAddress, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Octets, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBX509Ext_IPAddressToOctets, 0, 0, 1)
	ZEND_ARG_INFO(0, IPAddrStr)
ZEND_END_ARG_INFO()

// SBCRL unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCRL_CRLObjectFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBCRLStorage unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCRLStorage_CRLManagerAddRef, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCRLStorage_CRLManagerRelease, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBCertRetriever unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCertRetriever_CertificateRetrieverManagerAddRef, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCertRetriever_CertificateRetrieverManagerRelease, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBCertValidator unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCertValidator_GetCertificateCache, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBRDN unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRDN_FormatRDN, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, RDN, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRDN_MapUnicodeString, 0, 0, 2)
	ZEND_ARG_INFO(0, str)
	ZEND_ARG_INFO(0, CaseIgnore)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRDN_InsignificantSpaceHandling, 0, 0, 1)
	ZEND_ARG_INFO(0, str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRDN_GetRDNStringValue, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, RDN, TElRelativeDistinguishedName, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRDN_GetNormalizedRDNStringValue, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, RDN, TElRelativeDistinguishedName, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRDN_GetNormalizedRDNString, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRDN_CompareRDN, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Name1, TElRelativeDistinguishedName, 1)
	ZEND_ARG_OBJ_INFO(0, Name2, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRDN_CompareRDNAsStrings, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Name1, TElRelativeDistinguishedName, 1)
	ZEND_ARG_OBJ_INFO(0, Name2, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRDN_NonstrictCompareRDN, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, InnerRDN, TElRelativeDistinguishedName, 1)
	ZEND_ARG_OBJ_INFO(0, OuterRDN, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRDN_NonstrictCompareRDNAsStrings, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, InnerRDN, TElRelativeDistinguishedName, 1)
	ZEND_ARG_OBJ_INFO(0, OuterRDN, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRDN_GetIgnoreTagsWhenComparingRDNs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBRDN_SetIgnoreTagsWhenComparingRDNs, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

// SBCustomCertStorage unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCustomCertStorage_IsIssuerCertificate, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Subject, TElX509Certificate, 1)
	ZEND_ARG_OBJ_INFO(0, Issuer, TElX509Certificate, 1)
	ZEND_ARG_INFO(0, StrictChainBuilding)
ZEND_END_ARG_INFO()

// SBPKCS5 unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS5_DeriveRouteOneOTP, 0, 0, 2)
	ZEND_ARG_INFO(0, Input)
	ZEND_ARG_INFO(0, Password)
ZEND_END_ARG_INFO()

// SBPKCS7 unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS7_ProcessContentInfo, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1ConstrainedTag, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer_or_PKCS7Data, 0, 1)
	ZEND_ARG_INFO(1, Size_or_ReadOnly)
	ZEND_ARG_INFO(1, ContentType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS7_SaveSignerInfo, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1ConstrainedTag, 1)
	ZEND_ARG_OBJ_INFO(0, Signer, TElPKCS7Signer, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS7_ProcessSignerInfo, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1CustomTag, 1)
	ZEND_ARG_OBJ_INFO(0, SignerInfo, TElPKCS7Signer, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS7_RaisePKCS7Error, 0, 0, 1)
	ZEND_ARG_INFO(0, ErrorCode)
ZEND_END_ARG_INFO()

// SBPKCS7Utils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS7Utils_SaveAttributes, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1ConstrainedTag, 1)
	ZEND_ARG_OBJ_INFO(0, Attributes, TElPKCS7Attributes, 1)
	ZEND_ARG_INFO(0, TagID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS7Utils_ProcessAttributes, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1CustomTag, 1)
	ZEND_ARG_OBJ_INFO(0, Attributes, TElPKCS7Attributes, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS7Utils_ProcessAlgorithmIdentifier, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1CustomTag, 1)
	ZEND_ARG_INFO(1, Algorithm)
	ZEND_ARG_INFO(1, Params)
	ZEND_ARG_INFO(0, ImplicitTagging)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS7Utils_SaveAlgorithmIdentifier, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1ConstrainedTag, 1)
	ZEND_ARG_TYPE_INFO(0, Algorithm, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Params, 0, 1)
	ZEND_ARG_INFO(0, ImplicitTag)
	ZEND_ARG_INFO(0, WriteNullIfParamsAreEmpty)
ZEND_END_ARG_INFO()

// SBPKCS8 unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS8_RaisePKCS8Error, 0, 0, 1)
	ZEND_ARG_INFO(0, ErrorCode)
ZEND_END_ARG_INFO()

// SBPKCS12 unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS12_BufToInt, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS12_IntToBuf, 0, 0, 1)
	ZEND_ARG_INFO(0, Number)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS12_RaisePKCS12Error, 0, 0, 1)
	ZEND_ARG_INFO(0, ErrorCode)
ZEND_END_ARG_INFO()

// SBOCSPCommon unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOCSPCommon_ReasonFlagToEnum, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOCSPCommon_EnumToReasonFlag, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOCSPCommon_ReadAsnInteger, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, IntBuf, 0, 1)
ZEND_END_ARG_INFO()

// SBOCSPClient unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOCSPClient_OCSPClientManagerAddRef, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOCSPClient_OCSPClientManagerRelease, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOCSPClient_GetOCSPCertID, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Cert_or_Signer, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Issuer, TElX509Certificate, 1)
	ZEND_ARG_INFO(0, DigestAlg)
	ZEND_ARG_INFO(1, aIssuerNameHash)
	ZEND_ARG_INFO(1, IssuerKeyHash)
ZEND_END_ARG_INFO()

// SBPublicKeyCrypto unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPublicKeyCrypto_GetCheckKeyIntegrityBeforeUse, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPublicKeyCrypto_SetCheckKeyIntegrityBeforeUse, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

// SBPKIAsync unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKIAsync_GetGlobalAsyncCalculator, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBECCommon unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBECCommon_GetCurveByOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBECCommon_GetOIDByCurve, 0, 0, 1)
	ZEND_ARG_INFO(0, Curve)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBECCommon_IsPointCompressed, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBECCommon_BufferToPoint, 0, 0, 7)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_OBJ_INFO(0, DomainParams, TElECDomainParameters, 1)
	ZEND_ARG_TYPE_INFO(0, X, 0, 1)
	ZEND_ARG_INFO(1, XSize)
	ZEND_ARG_TYPE_INFO(0, Y, 0, 1)
	ZEND_ARG_INFO(1, YSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBECCommon_PointToBuffer, 0, 0, 9)
	ZEND_ARG_TYPE_INFO(0, X, 0, 1)
	ZEND_ARG_INFO(0, XSize)
	ZEND_ARG_TYPE_INFO(0, Y, 0, 1)
	ZEND_ARG_INFO(0, YSize)
	ZEND_ARG_OBJ_INFO(0, DomainParams, TElECDomainParameters, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
	ZEND_ARG_INFO(0, Compress)
	ZEND_ARG_INFO(0, Hybrid)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBECCommon_ValidateKey, 0, 0, 7)
	ZEND_ARG_OBJ_INFO(0, DomainParams, TElECDomainParameters, 1)
	ZEND_ARG_TYPE_INFO(0, D, 0, 1)
	ZEND_ARG_INFO(0, DSize)
	ZEND_ARG_TYPE_INFO(0, Qx, 0, 1)
	ZEND_ARG_INFO(0, QxSize)
	ZEND_ARG_TYPE_INFO(0, Qy, 0, 1)
	ZEND_ARG_INFO(0, QySize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBECCommon_HexStrToFieldElement, 0, 0, 3)
	ZEND_ARG_INFO(0, Src)
	ZEND_ARG_INFO(0, LittleEndian)
	ZEND_ARG_INFO(0, PSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBECCommon_BufferToFieldElement, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
	ZEND_ARG_INFO(1, A_or_Size)
	ZEND_ARG_OBJ_INFO(1, P_or_A, TLInt, 1)
	ZEND_ARG_OBJ_INFO(0, P, TLInt, 1)
ZEND_END_ARG_INFO()

// SBGSSAPIBase unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBGSSAPIBase_GSS_CALLING_ERROR, 0, 0, 1)
	ZEND_ARG_INFO(0, x)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBGSSAPIBase_GSS_ROUTINE_ERROR, 0, 0, 1)
	ZEND_ARG_INFO(0, x)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBGSSAPIBase_GSS_SUPPLEMENTARY_INFO, 0, 0, 1)
	ZEND_ARG_INFO(0, x)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBGSSAPIBase_GSS_ERROR, 0, 0, 1)
	ZEND_ARG_INFO(0, x)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBGSSAPIBase_DecodeMechOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBGSSAPIBase_EncodeMechOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

// SBDNSSEC unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSEC_CheckSystemNameServers, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, SL, TElStringList, 1)
	ZEND_ARG_INFO(0, UseIPv6)
ZEND_END_ARG_INFO()

// SBDNSSECUtils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_ResourceTypeToCode, 0, 0, 1)
	ZEND_ARG_INFO(0, AType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_ResourceCodeToType, 0, 0, 1)
	ZEND_ARG_INFO(0, ACode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_IPv6ToString, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_ReadDomainName, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Offset)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_WriteDomainName, 0, 0, 2)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_TYPE_INFO(1, Stream_or_Buffer, 0, 1)
	ZEND_ARG_INFO(1, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_WriteIPv4Address, 0, 0, 3)
	ZEND_ARG_INFO(0, Address)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(1, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_WriteIPv6Address, 0, 0, 3)
	ZEND_ARG_INFO(0, Address)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(1, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_WriteString, 0, 0, 3)
	ZEND_ARG_INFO(0, Str)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(1, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_ResponseCodeToRCode, 0, 0, 1)
	ZEND_ARG_INFO(0, ACode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_RCodeToResponseCode, 0, 0, 2)
	ZEND_ARG_INFO(0, ACode)
	ZEND_ARG_INFO(0, UsedInExtensions)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_OperationCodeToOpCode, 0, 0, 1)
	ZEND_ARG_INFO(0, ACode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_OpCodeToOperationCode, 0, 0, 1)
	ZEND_ARG_INFO(0, ACode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_CheckBufferBounds, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Offset)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_IsSubdomain, 0, 0, 2)
	ZEND_ARG_INFO(0, Subdomain)
	ZEND_ARG_INFO(0, Domain)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_LabelCount, 0, 0, 1)
	ZEND_ARG_INFO(0, Domain)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_ExtractLabels, 0, 0, 2)
	ZEND_ARG_INFO(0, Domain)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDNSSECUtils_CompareDomainNames, 0, 0, 2)
	ZEND_ARG_INFO(0, Name1)
	ZEND_ARG_INFO(0, Name2)
ZEND_END_ARG_INFO()

// SBCustomFSAdapter unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCustomFSAdapter_RaiseVFSAdapterError, 0, 0, 2)
	ZEND_ARG_INFO(0, ErrorCode)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCustomFSAdapter_RaiseVFSAdapterErrorEx, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Adapter, TElCustomFileSystemAdapter, 1)
	ZEND_ARG_INFO(0, ErrorCode)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

// SBPunycode unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPunycode_PunycodeEncode, 0, 0, 1)
	ZEND_ARG_INFO(0, Input)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPunycode_PunycodeDecode, 0, 0, 1)
	ZEND_ARG_INFO(0, Input)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPunycode_ToASCII, 0, 0, 1)
	ZEND_ARG_INFO(0, Domain)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPunycode_ToUnicode, 0, 0, 1)
	ZEND_ARG_INFO(0, Domain)
ZEND_END_ARG_INFO()

// SBHTTPAuth unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHTTPAuth_AuthInit, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, pAS, AUTH_SEQ, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHTTPAuth_AuthTerm, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, pAS, AUTH_SEQ, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHTTPAuth_AuthConverse, 0, 0, 8)
	ZEND_ARG_OBJ_INFO(0, pAS, AUTH_SEQ, 1)
	ZEND_ARG_TYPE_INFO(0, BuffIn, 0, 1)
	ZEND_ARG_INFO(1, BuffOut)
	ZEND_ARG_INFO(1, NeedMoreData)
	ZEND_ARG_INFO(0, Package)
	ZEND_ARG_INFO(0, Username)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_INFO(0, UsernameOption)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHTTPAuth_AddAuthorizationHeader, 0, 0, 8)
	ZEND_ARG_INFO(1, Str)
	ZEND_ARG_INFO(0, Scheme)
	ZEND_ARG_INFO(0, AuthData)
	ZEND_ARG_INFO(0, UserName)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_INFO(1, NeedMoreData)
	ZEND_ARG_INFO(0, ForProxy)
	ZEND_ARG_OBJ_INFO(0, aSeq, AUTH_SEQ, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHTTPAuth_ValidateSecPacks, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ls, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHTTPAuth_InitAuthLib, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBSASL unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSASL_CreateSASLClient, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Mechanism_or_Mechanisms, 0, 1)
ZEND_END_ARG_INFO()

// SBDC unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDC_DCBoolToStr, 0, 0, 1)
	ZEND_ARG_INFO(0, B)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDC_DCStrToBool, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, Def)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDC_DCBoolToByteArray, 0, 0, 1)
	ZEND_ARG_INFO(0, B)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDC_DCByteArrayToBool, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, S, 0, 1)
	ZEND_ARG_INFO(0, Def)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDC_DCSigMessageSort, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Item1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Item2, 0, 1)
ZEND_END_ARG_INFO()

// SBDCDef unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDCDef_DefaultDCRequestFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBDCEnc unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDCEnc_SetDefaultDCEncoding, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElDCEncoding, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDCEnc_GetDefaultDCEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBDCASN1Enc unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDCASN1Enc_DCASN1Encoding, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBDCCanonEnc unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDCCanonEnc_DCCanonEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBChSConv unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSConv_EnumCharsets, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, EnumProc, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSConv_CreateCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSConv_CreateCharsetByDescription, 0, 0, 1)
	ZEND_ARG_INFO(0, ADescription)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSConv_CreateSystemDefaultCharset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSConv_GetSystemDefaultCharsetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSConv_GetCharsetNameByAlias, 0, 0, 1)
	ZEND_ARG_INFO(0, Alias)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSConv_ConvertCharset, 0, 0, 3)
	ZEND_ARG_INFO(0, Source)
	ZEND_ARG_INFO(0, SourceCP)
	ZEND_ARG_INFO(0, DestCP)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSConv_InitializeCharsetObjects, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBChSConvBase unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSConvBase_RegisterCharset, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, CharsetClass, TPlCharsetClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSConvBase_UnregisterCharset, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, CharsetClass, TPlCharsetClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSConvBase_RegisterCharsetLibrary, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, RegistrationProc, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSConvBase_AbstractError, 0, 0, 2)
	ZEND_ARG_INFO(0, ClassName)
	ZEND_ARG_INFO(0, Method)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSConvBase_Initialize, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBChSUnicode unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSUnicode_WideUpperCase, 0, 0, 1)
	ZEND_ARG_INFO(1, C_or_S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSUnicode_WideTitleCase, 0, 0, 1)
	ZEND_ARG_INFO(1, C_or_S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSUnicode_GetCharType, 0, 0, 1)
	ZEND_ARG_INFO(0, C)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSUnicode_WideLowerCase, 0, 0, 1)
	ZEND_ARG_INFO(1, C_or_S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSUnicode_Normalize_NFD, 0, 0, 1)
	ZEND_ARG_INFO(0, AString)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSUnicode_Normalize_NFC, 0, 0, 1)
	ZEND_ARG_INFO(0, AString)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSUnicode_Normalize_NFKD, 0, 0, 1)
	ZEND_ARG_INFO(0, AString)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSUnicode_Normalize_NFKC, 0, 0, 1)
	ZEND_ARG_INFO(0, AString)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSUnicode_CheckProhibit, 0, 0, 1)
	ZEND_ARG_INFO(0, str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSUnicode_CheckBidi, 0, 0, 1)
	ZEND_ARG_INFO(0, str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSUnicode_GetCharCode, 0, 0, 1)
	ZEND_ARG_INFO(0, InCh)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBChSUnicode_GetCharValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Code)
ZEND_END_ARG_INFO()

// SBUnicode unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBUnicode_CreateUnicodeStringConverter, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBCryptoProvBuiltInEx unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvBuiltInEx_BuiltInCryptoProviderEx, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBDynStruct unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDynStruct_NullPtr, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDynStruct_GetArrayPtr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDynStruct_FreePointer, 0, 0, 1)
	ZEND_ARG_INFO(1, Value)
ZEND_END_ARG_INFO()

// SBAttrCert unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBAttrCert_ACWriteBitString, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBAttrCert_ACReadBitString, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
ZEND_END_ARG_INFO()

// SBScrypt unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBScrypt_scrypt, 0, 0, 6)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_TYPE_INFO(0, Salt, 0, 1)
	ZEND_ARG_INFO(0, N)
	ZEND_ARG_INFO(0, r)
	ZEND_ARG_INFO(0, p)
	ZEND_ARG_INFO(0, DKLen)
ZEND_END_ARG_INFO()

// SBDataStorage unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDataStorage_DataStorageSecurityHandlersFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDataStorage_DataStorageEncodingHandlersFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBAWSDataStorage unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBAWSDataStorage_GetNodeInnerXML, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, XmlNode, TElXMLDOMNode, 1)
ZEND_END_ARG_INFO()

// SBFileDataStorage unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBFileDataStorage_ComposeETag, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, ModTime, DateTime, 0)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

// SBWinAzureDataStorage unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWinAzureDataStorage_GetNodeText, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, XmlNode, TElXMLDOMNode, 1)
ZEND_END_ARG_INFO()

// SBDataStorageUtils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDataStorageUtils_TryGetStreamSize, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDataStorageUtils_PathAddExtension, 0, 0, 2)
	ZEND_ARG_INFO(0, PathName)
	ZEND_ARG_INFO(0, Extension)
ZEND_END_ARG_INFO()

// SBWebDAVClient unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVClient_AddSlash, 0, 0, 1)
	ZEND_ARG_INFO(0, s)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVClient_HTTPSuccess, 0, 0, 1)
	ZEND_ARG_INFO(0, Res)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVClient_Unauthorized, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Err, TObject, 1)
ZEND_END_ARG_INFO()

// SBWebDAVCommon unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_CalDAVTimeToDateTime, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_DateTimeToCalDAV, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_ISOTimeToDateTime, 0, 0, 1)
	ZEND_ARG_INFO(0, s)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_DateTimeToISOTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_DepthToStr, 0, 0, 1)
	ZEND_ARG_INFO(0, Depth)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_StrToDepth, 0, 0, 1)
	ZEND_ARG_INFO(0, Depth)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_ScopeToStr, 0, 0, 1)
	ZEND_ARG_INFO(0, Scope)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_StrToScope, 0, 0, 1)
	ZEND_ARG_INFO(0, Scope)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_Substring, 0, 0, 3)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, EndIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_URLComparePaths, 0, 0, 2)
	ZEND_ARG_INFO(0, URL1)
	ZEND_ARG_INFO(0, URL2)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_URLChild, 0, 0, 2)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_INFO(0, SubURL)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_URLExtractParent, 0, 0, 1)
	ZEND_ARG_INFO(0, s)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_URLExtractExtension, 0, 0, 1)
	ZEND_ARG_INFO(0, s)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_URLExtractResourceName, 0, 0, 1)
	ZEND_ARG_INFO(0, s)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_CollectionURL, 0, 0, 1)
	ZEND_ARG_INFO(0, URL)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_URLExtractPath, 0, 0, 1)
	ZEND_ARG_INFO(0, URL)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_URLCalculateDestPath, 0, 0, 3)
	ZEND_ARG_INFO(0, SrcURL)
	ZEND_ARG_INFO(0, DestURL)
	ZEND_ARG_INFO(0, URL)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_URLAddPrefixSlash, 0, 0, 1)
	ZEND_ARG_INFO(0, URL)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_URLAddPostfixSlash, 0, 0, 1)
	ZEND_ARG_INFO(0, URL)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_URLRemoveSlash, 0, 0, 1)
	ZEND_ARG_INFO(0, URL)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_URLFixSlashes, 0, 0, 1)
	ZEND_ARG_INFO(0, URL)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_URLEncodeEx, 0, 0, 1)
	ZEND_ARG_INFO(0, Data)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_URLConcat, 0, 0, 2)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_CheckStatusCode, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_SingleChildElement, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Elem, TElXMLDOMNode, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_MaxDateTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_GenerateRandomStr, 0, 0, 1)
	ZEND_ARG_INFO(0, Len)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_StrToPrivilege, 0, 0, 2)
	ZEND_ARG_INFO(0, NS)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_PrivilegeToStr, 0, 0, 1)
	ZEND_ARG_INFO(0, Privilege)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVCommon_PrivilegesArray, 0, 0, 4)
	ZEND_ARG_INFO(0, Privileges)
	ZEND_ARG_INFO(0, IncludeAll)
	ZEND_ARG_INFO(0, IncludeRead)
	ZEND_ARG_INFO(0, IncludeWrite)
ZEND_END_ARG_INFO()

// SBWebDAVServer unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBWebDAVServer_FindLockInList, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, List, TList, 1)
	ZEND_ARG_INFO(0, Token)
ZEND_END_ARG_INFO()

// SBDCXMLEnc unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBDCXMLEnc_DCXMLEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBFTPSCommon unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBFTPSCommon_IsWhitespace, 0, 0, 1)
	ZEND_ARG_INFO(0, b)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBFTPSCommon_DateTimeToFTPTimeVal, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBFTPSCommon_UnixPermissionsToStringRwx, 0, 0, 1)
	ZEND_ARG_INFO(0, Permissions)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBFTPSCommon_UnixPermissionsToStringOct, 0, 0, 1)
	ZEND_ARG_INFO(0, Permissions)
ZEND_END_ARG_INFO()

// SBHTTPSCommon unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHTTPSCommon_HTTPHeaderGetDelimiter, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Header, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Length)
	ZEND_ARG_INFO(1, Delimiter)
	ZEND_ARG_INFO(1, EndHeaderIndex)
ZEND_END_ARG_INFO()

// SBHTTPOCSPClient unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHTTPOCSPClient_RegisterHTTPOCSPClientFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHTTPOCSPClient_UnregisterHTTPOCSPClientFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBHTTPCertRetriever unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHTTPCertRetriever_RegisterHTTPCertificateRetrieverFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHTTPCertRetriever_UnregisterHTTPCertificateRetrieverFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBHTTPCRL unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHTTPCRL_RegisterHTTPCRLRetrieverFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHTTPCRL_UnregisterHTTPCRLRetrieverFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBHTTPSServer unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHTTPSServer_GetDefaultReasonPhrase, 0, 0, 1)
	ZEND_ARG_INFO(0, ResponseCode)
ZEND_END_ARG_INFO()

// SBLDAPCertRetriever unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPCertRetriever_RegisterLDAPCertificateRetrieverFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPCertRetriever_UnregisterLDAPCertificateRetrieverFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBLDAPCRL unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPCRL_RegisterLDAPCRLRetrieverFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPCRL_UnregisterLDAPCRLRetrieverFactory, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBLDAPSCore unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_AttrFromString, 0, 0, 3)
	ZEND_ARG_INFO(0, Type_)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_INFO(0, Operation)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_AttrFromBuffer, 0, 0, 3)
	ZEND_ARG_INFO(0, Type_)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
	ZEND_ARG_INFO(0, Operation)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_PutSimpleFilter, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(1, Tag, TElASN1ConstrainedTag, 0)
	ZEND_ARG_INFO(0, s)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_PutSubstringFilter, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(1, Tag, TElASN1ConstrainedTag, 0)
	ZEND_ARG_INFO(0, TagId)
	ZEND_ARG_INFO(0, Type_)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_SplitValue, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(1, List, TElStringList, 0)
	ZEND_ARG_INFO(0, s)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_PutFilterList, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(1, Tag, TElASN1ConstrainedTag, 0)
	ZEND_ARG_INFO(0, s)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_IsDigit, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_IsHexLower, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_IsHexUpper, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_IsHex, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_IsLower, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_IsUpper, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_IsAlpha, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_IsAlnum, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_IsLdh, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_IsSpace, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_Hex2Value, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_GetMessageLenSize, 0, 0, 2)
	ZEND_ARG_INFO(1, Buf)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_GetMessageLen, 0, 0, 2)
	ZEND_ARG_INFO(1, Buf)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBLDAPSCore_GetMessageType, 0, 0, 2)
	ZEND_ARG_INFO(1, Buf)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

// SBIMAPUtils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBIMAPUtils_QuoteString, 0, 0, 2)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_INFO(0, Quote)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBIMAPUtils_QuoteStringIfNeed, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBIMAPUtils_UnQuoteString, 0, 0, 2)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_INFO(0, QuotesRemoved)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBIMAPUtils_IsLiteralToken, 0, 0, 1)
	ZEND_ARG_INFO(0, Token)
ZEND_END_ARG_INFO()

// SBMIME unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIME_WideSameText, 0, 0, 2)
	ZEND_ARG_INFO(0, S1)
	ZEND_ARG_INFO(0, S2)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIME_GetHeaderFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIME_DeleteQuotationMarks, 0, 0, 1)
	ZEND_ARG_INFO(1, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIME_SetInQuotationMarks, 0, 0, 1)
	ZEND_ARG_INFO(1, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIME_IsAddressListField, 0, 0, 2)
	ZEND_ARG_INFO(0, FieldName)
	ZEND_ARG_INFO(0, CheckPartial)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIME_IsMessageScopeField, 0, 0, 1)
	ZEND_ARG_INFO(0, FieldName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIME_IsUnstructuredField, 0, 0, 1)
	ZEND_ARG_INFO(0, FieldName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIME_RegisterUnstructuredField, 0, 0, 1)
	ZEND_ARG_INFO(0, FieldName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIME_AddRegisteredMIMEMessagePartHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElMessagePartHandlerClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIME_RemoveRegisteredMIMEMessagePartHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElMessagePartHandlerClass, 1)
ZEND_END_ARG_INFO()

// SBMIMEEnc unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIMEEnc_DecodeHeader, 0, 0, 4)
	ZEND_ARG_INFO(0, Encoded)
	ZEND_ARG_INFO(0, Encoding)
	ZEND_ARG_INFO(1, Charset)
	ZEND_ARG_INFO(1, Decoded)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIMEEnc_EncodeQuotedPrintableBodyForHeader, 0, 0, 4)
	ZEND_ARG_INFO(0, Source)
	ZEND_ARG_INFO(1, Offset)
	ZEND_ARG_INFO(0, Max)
	ZEND_ARG_INFO(1, Dest)
ZEND_END_ARG_INFO()

// SBMIMEStream unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIMEStream_WriteStringToStream, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, S, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, LPos)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIMEStream_WriteWideStringToStream, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIMEStream_WriteStreamToStream, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Source, TStream, 1)
	ZEND_ARG_OBJ_INFO(0, Dest, TStream, 1)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIMEStream_ReadLineFromStream, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(0, Source, TStream, 1)
	ZEND_ARG_TYPE_INFO(1, smDest_or_sDest, 0, 1)
	ZEND_ARG_INFO(1, iLineLength_or_MaxLineLength)
	ZEND_ARG_INFO(0, MaxLineLength_or_bReadLongLine)
	ZEND_ARG_INFO(0, bReadLongLine_or_bSeekLongToEOL)
	ZEND_ARG_INFO(0, bSeekLongToEOL)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBMIMEStream_SeekStreamToEnd, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

// SBCompoundFile unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCompoundFile_IsValidDirectoryEntryName, 0, 0, 1)
	ZEND_ARG_INFO(0, EntryName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCompoundFile_CompareDirectoryEntryNames, 0, 0, 2)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(0, Y)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCompoundFile_CopyStorage, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, SourceStorage, TElCompoundFileStorageEntry, 1)
	ZEND_ARG_OBJ_INFO(0, DestStorage, TElCompoundFileStorageEntry, 1)
ZEND_END_ARG_INFO()

// SBOffice unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOffice_RegisterSecurityHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, HandlerClass, TElOfficeSecurityHandlerClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOffice_UnregisterSecurityHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, HandlerClass, TElOfficeSecurityHandlerClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOffice_DocumentFormatToString, 0, 0, 1)
	ZEND_ARG_INFO(0, DocumentFormat)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOffice_BinaryDocumentTypeToString, 0, 0, 1)
	ZEND_ARG_INFO(0, DocumentType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOffice_OpenXMLDocumentTypeToString, 0, 0, 1)
	ZEND_ARG_INFO(0, DocumentType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOffice_OpenDocumentTypeToString, 0, 0, 1)
	ZEND_ARG_INFO(0, DocumentType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOffice_IsSharedWorkbook, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Storage, TElCompoundFileStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOffice_Initialize, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBOfficeBinaryCore unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeBinaryCore_BufferToInt32, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeBinaryCore_BufferToInt64, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeBinaryCore_Int32ToBuffer, 0, 0, 3)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeBinaryCore_UInt32ToBuffer, 0, 0, 3)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeBinaryCore_Int64ToBuffer, 0, 0, 3)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeBinaryCore_SwapTimeEncoding, 0, 0, 1)
#ifdef SB_WINDOWS
	ZEND_ARG_OBJ_INFO(0, Value, windows_FILETIME, 0)
#else
	ZEND_ARG_OBJ_INFO(0, Value, _FILETIME, 0)
#endif
ZEND_END_ARG_INFO()

// SBOfficeXMLCore unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_IsValidPartIRI, 0, 0, 1)
	ZEND_ARG_INFO(0, IRI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_IsValidPartURI, 0, 0, 1)
	ZEND_ARG_INFO(0, URI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_ConvertPartIRIToURI, 0, 0, 1)
	ZEND_ARG_INFO(0, IRI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_ConvertPartURIToIRI, 0, 0, 1)
	ZEND_ARG_INFO(0, URI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_ComparePartIRI, 0, 0, 2)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(0, Y)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_ComparePartURI, 0, 0, 2)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(0, Y)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_NormalizePartIRI, 0, 0, 1)
	ZEND_ARG_INFO(0, IRI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_NormalizePartURI, 0, 0, 1)
	ZEND_ARG_INFO(0, URI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_ResolveRelativePartIRI, 0, 0, 2)
	ZEND_ARG_INFO(0, BaseIRI)
	ZEND_ARG_INFO(0, TargetIRI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_ResolveRelativePartURI, 0, 0, 2)
	ZEND_ARG_INFO(0, BaseURI)
	ZEND_ARG_INFO(0, TargetURI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_GetRelativePartURI, 0, 0, 2)
	ZEND_ARG_INFO(0, URI)
	ZEND_ARG_INFO(0, BaseURI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_GetRelationshipURI, 0, 0, 1)
	ZEND_ARG_INFO(0, PartURI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_GetPartURIExtension, 0, 0, 1)
	ZEND_ARG_INFO(0, URI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_GetPartURIPath, 0, 0, 1)
	ZEND_ARG_INFO(0, URI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_GetPartURIName, 0, 0, 1)
	ZEND_ARG_INFO(0, URI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_GetPartURIQueryComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, URI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_RemovePartURIExtension, 0, 0, 1)
	ZEND_ARG_INFO(0, URI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_RemovePartIRIQueryComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, IRI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_RemovePartURIQueryComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, URI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_GetValueFromQueryComponent, 0, 0, 2)
	ZEND_ARG_INFO(0, Query)
	ZEND_ARG_INFO(0, Key)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_IsLogicalItemSuffixName, 0, 0, 1)
	ZEND_ARG_INFO(0, SuffixName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_ParseLogicalItemSuffixName, 0, 0, 2)
	ZEND_ARG_INFO(0, SuffixName)
	ZEND_ARG_INFO(1, IsLast)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_FormatLogicalItemSuffixName, 0, 0, 3)
	ZEND_ARG_INFO(0, PieceNumber)
	ZEND_ARG_INFO(0, IsLast)
	ZEND_ARG_INFO(0, SkipSlash)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_DecodeXMLName, 0, 0, 1)
	ZEND_ARG_INFO(0, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_EncodeXMLNameSimple, 0, 0, 1)
	ZEND_ARG_INFO(0, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_GenerateUniqueIdForRelationship, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Relationships, TElOfficeOpenXMLRelationships, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_GetOpenXMLDocumentTypeFromContentType, 0, 0, 1)
	ZEND_ARG_INFO(0, ContentType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_GetOpenDocumentTypeFromMimeType, 0, 0, 1)
	ZEND_ARG_INFO(0, MimeType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBOfficeXMLCore_WideCompareStrOrdinal, 0, 0, 2)
	ZEND_ARG_INFO(0, S1)
	ZEND_ARG_INFO(0, S2)
ZEND_END_ARG_INFO()

// SBPDF unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDF_RegisterSecurityHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, HandlerClass, TElPDFSecurityHandlerClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDF_UnregisterSecurityHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, HandlerClass, TElPDFSecurityHandlerClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDF_GetPDFStandardType1FontName, 0, 0, 1)
	ZEND_ARG_INFO(0, Font)
ZEND_END_ARG_INFO()

// SBPDFCore unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_GetNameObjectFromDictionary, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Dict, TElPDFDictionary, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Default)
	ZEND_ARG_INFO(0, RaiseException)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_GetIntObjectFromDictionary, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Dict, TElPDFDictionary, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Default)
	ZEND_ARG_INFO(0, RaiseException)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_GetRealObjectFromDictionary, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Dict, TElPDFDictionary, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Default)
	ZEND_ARG_INFO(0, RaiseException)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_GetStringObjectFromDictionary, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Dict, TElPDFDictionary, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, RaiseException)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_GetArrayObjectFromDictionary, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Dict, TElPDFDictionary, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, RaiseException)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_GetDictionaryObjectFromDictionary, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Dict, TElPDFDictionary, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, RaiseException)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_GetBooleanObjectFromDictionary, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Dict, TElPDFDictionary, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Default)
	ZEND_ARG_INFO(0, RaiseException)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_AddRealObjectToDictionary, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Dict, TElPDFDictionary, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_INFO(0, Overwrite)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_AddIntObjectToDictionary, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Dict, TElPDFDictionary, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_INFO(0, Overwrite)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_AddBooleanObjectToDictionary, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Dict, TElPDFDictionary, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_INFO(0, Overwrite)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_AddStringObjectToDictionary, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Dict, TElPDFDictionary, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
	ZEND_ARG_INFO(0, Enc)
	ZEND_ARG_INFO(0, Overwrite)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_AddNameObjectToDictionary, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Dict, TElPDFDictionary, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_INFO(0, Overwrite)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_AddRectangleObjectToDictionary, 0, 0, 6)
	ZEND_ARG_OBJ_INFO(0, Dict, TElPDFDictionary, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, X1)
	ZEND_ARG_INFO(0, Y1)
	ZEND_ARG_INFO(0, X2)
	ZEND_ARG_INFO(0, Y2)
	ZEND_ARG_INFO(0, Overwrite)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_AddReferenceToDictionary, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Dict, TElPDFDictionary, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_OBJ_INFO(0, Obj, TElPDFRef, 1)
	ZEND_ARG_INFO(0, Overwrite)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_AddRealObjectToArray, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Arr, TElPDFArray, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_AddIntObjectToArray, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Arr, TElPDFArray, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_AddNameObjectToArray, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Arr, TElPDFArray, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_AddStringObjectToArray, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Arr, TElPDFArray, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
	ZEND_ARG_INFO(0, Enc)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_CreateStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TElPDFFile, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_CompressStream, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Strm, TElPDFStream, 1)
	ZEND_ARG_INFO(0, AddCRLF)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_EncodePDFDate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, D, DateTime, 0)
	ZEND_ARG_INFO(0, AddUTCPostfix)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_DecodePDFDate, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_EncodeTextString, 0, 0, 1)
	ZEND_ARG_INFO(0, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_EncodeTextStringUnicode, 0, 0, 1)
	ZEND_ARG_INFO(0, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_DecodeTextString, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFCore_GetSortedKeyList, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Dictionary, TElPDFDictionary, 1)
	ZEND_ARG_OBJ_INFO(0, List, TStringList, 1)
ZEND_END_ARG_INFO()

// SBPDFUtils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFUtils_IntToByteArray, 0, 0, 2)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_INFO(0, LittleEndian)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFUtils_UIntToByteArray, 0, 0, 2)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_INFO(0, LittleEndian)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFUtils_IsPNGPredictor, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFUtils_DecodePNG, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, Cols)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPDFUtils_TrimArray, 0, 0, 1)
	ZEND_ARG_INFO(1, a)
ZEND_END_ARG_INFO()

// SBPGPEntities unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPEntities_CreateEntity, 0, 0, 1)
	ZEND_ARG_INFO(0, PktType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPEntities_CloneEntity, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Entity, TElPGPEntity, 1)
ZEND_END_ARG_INFO()

// SBPGPMD unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPMD_MDGetDigestSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPMD_MDInitialize, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(1, HashFunction, TElHashFunction, 0)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPMD_MDHash, 0, 0, 3)
	ZEND_ARG_INFO(0, Algorithm)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPMD_MDFinalize, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(1, HashFunction, TElHashFunction, 0)
ZEND_END_ARG_INFO()

// SBPGPUtils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_UTCTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_TimestampToDateTime, 0, 0, 1)
	ZEND_ARG_INFO(0, Timestamp)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_DateTimeToTimestamp, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DateTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_ReadMPInt, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_OBJ_INFO(1, Dest, TLInt, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_WriteMPInt, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Src, TLInt, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_WriteMPInt2, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Src, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_GetPGPPacketHeaderSize, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_GetSigSubpktTypeByExtension, 0, 0, 1)
	ZEND_ARG_INFO(0, ExtType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_WriteSizeInt, 0, 0, 3)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, ResSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_MPIntToByteArray, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Src, 0, 1)
	ZEND_ARG_INFO(1, Dest)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_IsCorrectHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_IsCorrectSymmetricAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_AlgorithmCanSign, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_AlgorithmCanEncrypt, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_TranslateMDAlgorithmFromPGP, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_TranslateMDAlgorithmToPGP, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_TranslateSKAlgorithmFromPGP, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_TranslateSKAlgorithmToPGP, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_TranslateMDAlgorithmToECDSA, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_AddPKCS1Prefix, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Hash, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_SymmetricInitialize, 0, 0, 4)
	ZEND_ARG_INFO(0, Algorithm)
	ZEND_ARG_OBJ_INFO(1, Crypto, TElSymmetricCrypto, 0)
	ZEND_ARG_TYPE_INFO(0, Key, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InitialVector, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_SymmetricFinalize, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(1, Crypto, TElSymmetricCrypto, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_MPIntSize, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_MPIntBitCount, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, MPInt, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_CRC24, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, Init)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_CalculateChecksum, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_ToBase64_32, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, OutBuffer)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_ToBase64_2, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, OutBuffer)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_ToBase64_1, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, OutBuffer)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_SKGetBlockSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_SKGetKeySize, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_CreateAndInitRandom, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_Max64, 0, 0, 2)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(0, Y)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_Min64, 0, 0, 2)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(0, Y)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_IsPublicKeyEncryptionAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Alg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_IsPublicKeySigningAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Alg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_AlgorithmMPIntsPublic, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_AlgorithmMPIntsSecret, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_CompareKeyID, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, ID1, TSBKeyID, 0)
	ZEND_ARG_OBJ_INFO(0, ID2, TSBKeyID, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_CompareKeyFP, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, FP1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, FP2, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_CompareKeyIDArrays, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, ID1, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ID2, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_GetSymmetricKeyAlgorithmName, 0, 0, 1)
	ZEND_ARG_INFO(0, Alg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_GetSymmetricKeyAlgorithmByName, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_FormatPKCS1, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Modulus, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, BlockType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_UnformatPKCS1, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(1, BlockType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_PGPCurveByOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_OIDByPGPCurve, 0, 0, 1)
	ZEND_ARG_INFO(0, Curve)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_PGPCurveByBits, 0, 0, 1)
	ZEND_ARG_INFO(0, Bits)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_BitsInPGPCurve, 0, 0, 1)
	ZEND_ARG_INFO(0, Curve)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_HashAlgorithmByPGPCurve, 0, 0, 1)
	ZEND_ARG_INFO(0, Curve)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_SymmetricAlgorithmByPGPCurve, 0, 0, 1)
	ZEND_ARG_INFO(0, Curve)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_DetectMessageEncoding, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Msg, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(1, BOMSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_BytesInEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Encoding)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_UnicodeMessageToUtf8, 0, 0, 7)
	ZEND_ARG_INFO(0, Encoding)
	ZEND_ARG_TYPE_INFO(0, Msg, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
	ZEND_ARG_TYPE_INFO(0, OutBuf, 0, 1)
	ZEND_ARG_INFO(0, OutIndex)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_IsCleartextMessage, 0, 0, 4)
	ZEND_ARG_INFO(0, Encoding)
	ZEND_ARG_TYPE_INFO(0, Msg, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_SizeOfMessageInEncoding, 0, 0, 4)
	ZEND_ARG_INFO(0, Encoding)
	ZEND_ARG_TYPE_INFO(0, Msg, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_IsWhitespace, 0, 0, 1)
	ZEND_ARG_INFO(0, B)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_IsEOL, 0, 0, 1)
	ZEND_ARG_INFO(0, B)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_IsEmailChar, 0, 0, 1)
	ZEND_ARG_INFO(0, B)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_UserIDCorrespondsToEmail, 0, 0, 2)
	ZEND_ARG_INFO(0, UserID)
	ZEND_ARG_INFO(0, Email)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_KeyID2Str, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, KeyID, TSBKeyID, 0)
	ZEND_ARG_INFO(0, OnlyLowBytes)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_KeyID2Array, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, KeyID, TSBKeyID, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_KeyFP2Str, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, KeyFP, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_PKAlg2Str, 0, 0, 1)
	ZEND_ARG_INFO(0, Alg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_HashAlg2Str, 0, 0, 1)
	ZEND_ARG_INFO(0, Alg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_Str2HashAlg, 0, 0, 1)
	ZEND_ARG_INFO(0, Alg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_ComprAlg2Str, 0, 0, 1)
	ZEND_ARG_INFO(0, Alg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_ConvertDaysToSeconds, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_ConvertSecondsToDays, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_EncodePassword, 0, 0, 1)
	ZEND_ARG_INFO(0, Password)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_GetOpenPGPPasswordCharset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPUtils_SetOpenPGPPasswordCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

// SBPGPMIME unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPGPMIME_Initialize, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBCMS unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCMS_GetTimestampTypeOID, 0, 0, 1)
	ZEND_ARG_INFO(0, TimestampType)
ZEND_END_ARG_INFO()

// SBCryptoProvPKCS11 unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvPKCS11_PKCS11CryptoProvider, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBPKCS11Base unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS11Base_PKCS11AlgorithmConverter, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS11Base_CreateMutexCallback, 0, 0, 1)
	ZEND_ARG_INFO(1, MutexPtr)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS11Base_DestroyMutexCallback, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, MutexPtr, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS11Base_LockMutexCallback, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, MutexPtr, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS11Base_UnlockMutexCallback, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, MutexPtr, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS11Base_GetPKCS11String, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, MaxLength)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS11Base_PKCS11CheckError, 0, 0, 2)
	ZEND_ARG_INFO(0, FunctionCode)
	ZEND_ARG_INFO(0, ResultCode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS11Base_GetPKCS11ErrorNameByCode, 0, 0, 1)
	ZEND_ARG_INFO(0, Code)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS11Base_EncodeErrorInfo, 0, 0, 5)
	ZEND_ARG_INFO(0, MethodName)
	ZEND_ARG_INFO(0, ErrorStr)
	ZEND_ARG_INFO(0, ErrorClassName)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS11Base_GetPKCS11ModuleList, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS11Base_UnloadPKCS11Modules, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBPKCS11CertStorage unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBPKCS11CertStorage_GetContextByCertificate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

// SBAuthenticode unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBAuthenticode_GetDigestAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBAuthenticode_GetDigestAlgorithmOID, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBAuthenticode_GetAuthenticodeDigestAlgorithm, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Algorithm_or_OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBAuthenticode_GetAuthenticodeDigestAlgorithmName, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

// SBJWCrypto unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBJWCrypto_Base64UrlEncode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBJWCrypto_Base64UrlDecode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

// SBHID unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHID_HIDEnumerateDevices, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, EnumProc, 0, 1)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
// SBHIDWin unit arg info
#endif
#ifdef LINUX
// SBHIDLinux unit arg info
#endif
#ifdef MACOS
// SBHIDMac unit arg info
#endif

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_HIDEnumerateDevices, 0, 0, 2)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_HIDEnumerateDevices, 0, 0, 2)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_HIDEnumerateDevices, 0, 0, 2)
#endif
	ZEND_ARG_OBJ_INFO(0, List, TElHIDDeviceInfoList, 1)
	ZEND_ARG_TYPE_INFO(0, EnumProc, 0, 1)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_LoadHIDModule, 0, 0, 0)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_LoadUdevModule, 0, 0, 0)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_LoadIOHIDModule, 0, 0, 0)
#endif
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_LoadSetupAPIModule, 0, 0, 0)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_UnloadUdevModule, 0, 0, 0)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_UnloadIOHIDModule, 0, 0, 0)
#endif
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_UnloadHIDModule, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_UnloadSetupAPIModule, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_HIDOpenDevice, 0, 0, 2)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_HIDOpenDevice, 0, 0, 2)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_HIDOpenDevice, 0, 0, 2)
#endif
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_INFO(0, ReadWriteAccess)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_HIDCloseDevice, 0, 0, 1)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_HIDCloseDevice, 0, 0, 1)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_HIDCloseDevice, 0, 0, 1)
#endif
	ZEND_ARG_OBJ_INFO(0, Device, TObject, 1)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_HIDReadTimeout, 0, 0, 5)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_HIDReadTimeout, 0, 0, 5)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_HIDReadTimeout, 0, 0, 5)
#endif
	ZEND_ARG_OBJ_INFO(0, Device, TObject, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, Timeout)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_HIDWriteTimeout, 0, 0, 5)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_HIDWriteTimeout, 0, 0, 5)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_HIDWriteTimeout, 0, 0, 5)
#endif
	ZEND_ARG_OBJ_INFO(0, Device, TObject, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, Timeout)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_HIDIsInvalidDevice, 0, 0, 1)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_HIDIsInvalidDevice, 0, 0, 1)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_HIDIsInvalidDevice, 0, 0, 1)
#endif
	ZEND_ARG_OBJ_INFO(0, Device, TObject, 1)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_HIDGetDeviceAttributes, 0, 0, 4)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_HIDGetDeviceAttributes, 0, 0, 4)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_HIDGetDeviceAttributes, 0, 0, 4)
#endif
	ZEND_ARG_OBJ_INFO(0, Device, TObject, 1)
	ZEND_ARG_INFO(1, VendorID)
	ZEND_ARG_INFO(1, ProductID)
	ZEND_ARG_INFO(1, VersionNumber)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_HIDGetDeviceSerialNumber, 0, 0, 1)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_HIDGetDeviceSerialNumber, 0, 0, 1)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_HIDGetDeviceSerialNumber, 0, 0, 1)
#endif
	ZEND_ARG_OBJ_INFO(0, Device, TObject, 1)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_HIDGetDeviceManufacturer, 0, 0, 1)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_HIDGetDeviceManufacturer, 0, 0, 1)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_HIDGetDeviceManufacturer, 0, 0, 1)
#endif
	ZEND_ARG_OBJ_INFO(0, Device, TObject, 1)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_HIDGetDeviceProduct, 0, 0, 1)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_HIDGetDeviceProduct, 0, 0, 1)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_HIDGetDeviceProduct, 0, 0, 1)
#endif
	ZEND_ARG_OBJ_INFO(0, Device, TObject, 1)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_HIDGetDeviceIndexedString, 0, 0, 2)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_HIDGetDeviceIndexedString, 0, 0, 2)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_HIDGetDeviceIndexedString, 0, 0, 2)
#endif
	ZEND_ARG_OBJ_INFO(0, Device, TObject, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_HIDGetDeviceCapabilities, 0, 0, 6)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_HIDGetDeviceCapabilities, 0, 0, 6)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_HIDGetDeviceCapabilities, 0, 0, 6)
#endif
	ZEND_ARG_OBJ_INFO(0, Device, TObject, 1)
	ZEND_ARG_INFO(1, Usage)
	ZEND_ARG_INFO(1, UsagePage)
	ZEND_ARG_INFO(1, InputReportByteLength)
	ZEND_ARG_INFO(1, OutputReportByteLength)
	ZEND_ARG_INFO(1, FeatureReportByteLength)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_HIDGetDeviceFeature, 0, 0, 4)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_HIDGetDeviceFeature, 0, 0, 4)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_HIDGetDeviceFeature, 0, 0, 4)
#endif
	ZEND_ARG_OBJ_INFO(0, Device, TObject, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDWin_HIDSetDeviceFeature, 0, 0, 4)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_HIDSetDeviceFeature, 0, 0, 4)
#endif
#ifdef MACOS
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDMac_HIDSetDeviceFeature, 0, 0, 4)
#endif
	ZEND_ARG_OBJ_INFO(0, Device, TObject, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
// SBU2FHID unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDEnumerateDevices, 0, 0, 0)
#endif
#ifdef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_GetHIDOptions, 0, 0, 0)
#endif
#ifndef MACOS
ZEND_END_ARG_INFO()

#ifndef LINUX
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDInit, 0, 0, 6)
	ZEND_ARG_OBJ_INFO(0, Device, TElHIDDevice, 1)
	ZEND_ARG_INFO(1, VersionInterface)
	ZEND_ARG_INFO(1, VersionMajor)
	ZEND_ARG_INFO(1, VersionMinor)
	ZEND_ARG_INFO(1, VersionBuild)
	ZEND_ARG_INFO(1, CapFlags)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDSendCmd, 0, 0, 6)
	ZEND_ARG_OBJ_INFO(0, Device, TElHIDDevice, 1)
	ZEND_ARG_INFO(0, CID)
	ZEND_ARG_INFO(0, Cmd)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDMessage, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(0, Device, TElHIDDevice, 1)
	ZEND_ARG_INFO(0, CID)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDPing, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Device, TElHIDDevice, 1)
	ZEND_ARG_INFO(0, CID)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDWink, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Device, TElHIDDevice, 1)
	ZEND_ARG_INFO(0, CID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDLock, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Device, TElHIDDevice, 1)
	ZEND_ARG_INFO(0, CID)
	ZEND_ARG_INFO(0, LockTime)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDSync, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Device, TElHIDDevice, 1)
	ZEND_ARG_INFO(0, CID)
ZEND_END_ARG_INFO()

// SBU2FCommon unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FFormatRequestMessageFrame, 0, 0, 6)
	ZEND_ARG_INFO(0, Cmd)
	ZEND_ARG_INFO(0, P1)
	ZEND_ARG_INFO(0, P2)
	ZEND_ARG_TYPE_INFO(0, RequestData, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FGetStatusCodeFromResponseMessageFrame, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, ResponseData, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FStatusCodeToMessage, 0, 0, 1)
	ZEND_ARG_INFO(0, StatusCode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FFormatRegistrationRequestMessage, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, ChallengeParameter, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ApplicationParameter, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FParseRegistrationResponseMessage, 0, 0, 6)
	ZEND_ARG_TYPE_INFO(0, Msg, 0, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(1, UserPublicKey)
	ZEND_ARG_INFO(1, KeyHandle)
	ZEND_ARG_INFO(1, AttestationCertificate)
	ZEND_ARG_INFO(1, Signature)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FFormatAuthRequestMessage, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, ChallengeParameter, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ApplicationParameter, 0, 1)
	ZEND_ARG_TYPE_INFO(0, KeyHandle, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FParseAuthResponseMessage, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Msg, 0, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(1, UserPresence)
	ZEND_ARG_INFO(1, Counter)
	ZEND_ARG_INFO(1, Signature)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONFormatClientData, 0, 0, 4)
	ZEND_ARG_INFO(0, DataType)
	ZEND_ARG_INFO(0, Challenge)
	ZEND_ARG_INFO(0, Origin)
	ZEND_ARG_TYPE_INFO(0, CIDPubkey, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONParseClientData, 0, 0, 5)
	ZEND_ARG_INFO(0, ClientData)
	ZEND_ARG_INFO(1, DataType)
	ZEND_ARG_INFO(1, Challenge)
	ZEND_ARG_INFO(1, Origin)
	ZEND_ARG_INFO(1, CIDPubkey)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONFormatRegistrationChallenge, 0, 0, 3)
	ZEND_ARG_INFO(0, Challenge)
	ZEND_ARG_INFO(0, AppID)
	ZEND_ARG_INFO(0, Version)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONParseRegistrationChallenge, 0, 0, 4)
	ZEND_ARG_INFO(0, RegChallenge)
	ZEND_ARG_INFO(1, Challenge)
	ZEND_ARG_INFO(1, AppID)
	ZEND_ARG_INFO(1, Version)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONFormatAuthenticationChallenge, 0, 0, 3)
	ZEND_ARG_INFO(0, Challenge)
	ZEND_ARG_INFO(0, AppID)
	ZEND_ARG_INFO(0, Version)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONParseAuthenticationChallenge, 0, 0, 4)
	ZEND_ARG_INFO(0, AuthChallenge)
	ZEND_ARG_INFO(1, Challenge)
	ZEND_ARG_INFO(1, AppID)
	ZEND_ARG_INFO(1, Version)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONLoadU2FRegisterRequest, 0, 0, 7)
	ZEND_ARG_INFO(0, U2FRegisterRequest)
	ZEND_ARG_INFO(1, AppId)
	ZEND_ARG_OBJ_INFO(0, RegisterRequests, TElU2FJSRegisterRequests, 1)
	ZEND_ARG_OBJ_INFO(0, UserKeys, TElU2FUserKeys, 1)
	ZEND_ARG_OBJ_INFO(0, AppIDs, TElStringList, 1)
	ZEND_ARG_INFO(1, TimeoutSeconds)
	ZEND_ARG_INFO(1, RequestID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONSaveU2FRegisterRequest, 0, 0, 6)
	ZEND_ARG_INFO(0, AppID)
	ZEND_ARG_OBJ_INFO(0, RegisterRequests, TElU2FJSRegisterRequests, 1)
	ZEND_ARG_OBJ_INFO(0, UserKeys, TElU2FUserKeys, 1)
	ZEND_ARG_INFO(0, TimeoutSeconds)
	ZEND_ARG_INFO(0, RequestID)
	ZEND_ARG_INFO(0, JSAPIVersion)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONLoadU2FRegisterResponse, 0, 0, 7)
	ZEND_ARG_INFO(0, U2FRegisterResponse)
	ZEND_ARG_INFO(1, Version)
	ZEND_ARG_INFO(1, ClientData)
	ZEND_ARG_INFO(1, RegistrationData)
	ZEND_ARG_INFO(1, ErrorCode)
	ZEND_ARG_INFO(1, ErrorMessage)
	ZEND_ARG_INFO(1, RequestID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONSaveU2FRegisterResponse, 0, 0, 5)
	ZEND_ARG_INFO(0, Version)
	ZEND_ARG_INFO(0, ClientData)
	ZEND_ARG_TYPE_INFO(0, RegistrationData, 0, 1)
	ZEND_ARG_INFO(0, RequestID)
	ZEND_ARG_INFO(0, JSAPIVersion)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONSaveU2FRegisterResponseError, 0, 0, 4)
	ZEND_ARG_INFO(0, ErrorCode)
	ZEND_ARG_INFO(0, ErrorMessage)
	ZEND_ARG_INFO(0, RequestID)
	ZEND_ARG_INFO(0, JSAPIVersion)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONLoadU2FSignRequest, 0, 0, 8)
	ZEND_ARG_INFO(0, U2FSignRequest)
	ZEND_ARG_INFO(1, Challenge)
	ZEND_ARG_INFO(1, AppId)
	ZEND_ARG_OBJ_INFO(0, UserKeys, TElU2FUserKeys, 1)
	ZEND_ARG_OBJ_INFO(0, Challenges, TElStringList, 1)
	ZEND_ARG_OBJ_INFO(0, AppIDs, TElStringList, 1)
	ZEND_ARG_INFO(1, TimeoutSeconds)
	ZEND_ARG_INFO(1, RequestID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONSaveU2FSignRequest, 0, 0, 6)
	ZEND_ARG_INFO(0, Challenge)
	ZEND_ARG_INFO(0, AppID)
	ZEND_ARG_OBJ_INFO(0, UserKeys, TElU2FUserKeys, 1)
	ZEND_ARG_INFO(0, TimeoutSeconds)
	ZEND_ARG_INFO(0, RequestID)
	ZEND_ARG_INFO(0, JSAPIVersion)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONLoadU2FSignResponse, 0, 0, 7)
	ZEND_ARG_INFO(0, U2FSignResponse)
	ZEND_ARG_INFO(1, KeyHandle)
	ZEND_ARG_INFO(1, SignatureData)
	ZEND_ARG_INFO(1, ClientData)
	ZEND_ARG_INFO(1, ErrorCode)
	ZEND_ARG_INFO(1, ErrorMessage)
	ZEND_ARG_INFO(1, RequestID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONSaveU2FSignResponse, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, KeyHandle, 0, 1)
	ZEND_ARG_TYPE_INFO(0, SignatureData, 0, 1)
	ZEND_ARG_INFO(0, ClientData)
	ZEND_ARG_INFO(0, RequestID)
	ZEND_ARG_INFO(0, JSAPIVersion)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONSaveU2FSignResponseError, 0, 0, 4)
	ZEND_ARG_INFO(0, ErrorCode)
	ZEND_ARG_INFO(0, ErrorMessage)
	ZEND_ARG_INFO(0, RequestID)
	ZEND_ARG_INFO(0, JSAPIVersion)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSAPIErrorToServerError, 0, 0, 1)
	ZEND_ARG_INFO(0, ErrorCode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FBase64UrlEncodeBytes, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FBase64UrlDecodeBytes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FVerifyRegistrationSignature, 0, 0, 6)
	ZEND_ARG_TYPE_INFO(0, ChallengeParameter, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ApplicationParameter, 0, 1)
	ZEND_ARG_TYPE_INFO(0, KeyHandle, 0, 1)
	ZEND_ARG_TYPE_INFO(0, UserPublicKey, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Signature, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AttestationCertificate, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FVerifyAuthenticationSignature, 0, 0, 6)
	ZEND_ARG_TYPE_INFO(0, ChallengeParameter, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ApplicationParameter, 0, 1)
	ZEND_ARG_TYPE_INFO(0, UserPublicKey, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Signature, 0, 1)
	ZEND_ARG_INFO(0, UserPresence)
	ZEND_ARG_INFO(0, Counter)
ZEND_END_ARG_INFO()

// SBCryptoProvCardPIV unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBCryptoProvCardPIV_PIVCardCryptoProvider, 0, 0, 0)
ZEND_END_ARG_INFO()

#else
ZEND_BEGIN_ARG_INFO_EX(arginfo_SBHIDLinux_SetHIDOptions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

#endif
#endif
#ifndef SB_WINDOWS
// SBU2FHID unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDEnumerateDevices, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDInit, 0, 0, 6)
	ZEND_ARG_OBJ_INFO(0, Device, TElHIDDevice, 1)
	ZEND_ARG_INFO(1, VersionInterface)
	ZEND_ARG_INFO(1, VersionMajor)
	ZEND_ARG_INFO(1, VersionMinor)
	ZEND_ARG_INFO(1, VersionBuild)
	ZEND_ARG_INFO(1, CapFlags)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDSendCmd, 0, 0, 6)
	ZEND_ARG_OBJ_INFO(0, Device, TElHIDDevice, 1)
	ZEND_ARG_INFO(0, CID)
	ZEND_ARG_INFO(0, Cmd)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDMessage, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(0, Device, TElHIDDevice, 1)
	ZEND_ARG_INFO(0, CID)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDPing, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Device, TElHIDDevice, 1)
	ZEND_ARG_INFO(0, CID)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDWink, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Device, TElHIDDevice, 1)
	ZEND_ARG_INFO(0, CID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDLock, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Device, TElHIDDevice, 1)
	ZEND_ARG_INFO(0, CID)
	ZEND_ARG_INFO(0, LockTime)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FHID_U2FHIDSync, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Device, TElHIDDevice, 1)
	ZEND_ARG_INFO(0, CID)
ZEND_END_ARG_INFO()

// SBU2FCommon unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FFormatRequestMessageFrame, 0, 0, 6)
	ZEND_ARG_INFO(0, Cmd)
	ZEND_ARG_INFO(0, P1)
	ZEND_ARG_INFO(0, P2)
	ZEND_ARG_TYPE_INFO(0, RequestData, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FGetStatusCodeFromResponseMessageFrame, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, ResponseData, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FStatusCodeToMessage, 0, 0, 1)
	ZEND_ARG_INFO(0, StatusCode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FFormatRegistrationRequestMessage, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, ChallengeParameter, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ApplicationParameter, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FParseRegistrationResponseMessage, 0, 0, 6)
	ZEND_ARG_TYPE_INFO(0, Msg, 0, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(1, UserPublicKey)
	ZEND_ARG_INFO(1, KeyHandle)
	ZEND_ARG_INFO(1, AttestationCertificate)
	ZEND_ARG_INFO(1, Signature)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FFormatAuthRequestMessage, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, ChallengeParameter, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ApplicationParameter, 0, 1)
	ZEND_ARG_TYPE_INFO(0, KeyHandle, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FParseAuthResponseMessage, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Msg, 0, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(1, UserPresence)
	ZEND_ARG_INFO(1, Counter)
	ZEND_ARG_INFO(1, Signature)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONFormatClientData, 0, 0, 4)
	ZEND_ARG_INFO(0, DataType)
	ZEND_ARG_INFO(0, Challenge)
	ZEND_ARG_INFO(0, Origin)
	ZEND_ARG_TYPE_INFO(0, CIDPubkey, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONParseClientData, 0, 0, 5)
	ZEND_ARG_INFO(0, ClientData)
	ZEND_ARG_INFO(1, DataType)
	ZEND_ARG_INFO(1, Challenge)
	ZEND_ARG_INFO(1, Origin)
	ZEND_ARG_INFO(1, CIDPubkey)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONFormatRegistrationChallenge, 0, 0, 3)
	ZEND_ARG_INFO(0, Challenge)
	ZEND_ARG_INFO(0, AppID)
	ZEND_ARG_INFO(0, Version)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONParseRegistrationChallenge, 0, 0, 4)
	ZEND_ARG_INFO(0, RegChallenge)
	ZEND_ARG_INFO(1, Challenge)
	ZEND_ARG_INFO(1, AppID)
	ZEND_ARG_INFO(1, Version)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONFormatAuthenticationChallenge, 0, 0, 3)
	ZEND_ARG_INFO(0, Challenge)
	ZEND_ARG_INFO(0, AppID)
	ZEND_ARG_INFO(0, Version)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONParseAuthenticationChallenge, 0, 0, 4)
	ZEND_ARG_INFO(0, AuthChallenge)
	ZEND_ARG_INFO(1, Challenge)
	ZEND_ARG_INFO(1, AppID)
	ZEND_ARG_INFO(1, Version)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONLoadU2FRegisterRequest, 0, 0, 7)
	ZEND_ARG_INFO(0, U2FRegisterRequest)
	ZEND_ARG_INFO(1, AppId)
	ZEND_ARG_OBJ_INFO(0, RegisterRequests, TElU2FJSRegisterRequests, 1)
	ZEND_ARG_OBJ_INFO(0, UserKeys, TElU2FUserKeys, 1)
	ZEND_ARG_OBJ_INFO(0, AppIDs, TElStringList, 1)
	ZEND_ARG_INFO(1, TimeoutSeconds)
	ZEND_ARG_INFO(1, RequestID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONSaveU2FRegisterRequest, 0, 0, 6)
	ZEND_ARG_INFO(0, AppID)
	ZEND_ARG_OBJ_INFO(0, RegisterRequests, TElU2FJSRegisterRequests, 1)
	ZEND_ARG_OBJ_INFO(0, UserKeys, TElU2FUserKeys, 1)
	ZEND_ARG_INFO(0, TimeoutSeconds)
	ZEND_ARG_INFO(0, RequestID)
	ZEND_ARG_INFO(0, JSAPIVersion)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONLoadU2FRegisterResponse, 0, 0, 7)
	ZEND_ARG_INFO(0, U2FRegisterResponse)
	ZEND_ARG_INFO(1, Version)
	ZEND_ARG_INFO(1, ClientData)
	ZEND_ARG_INFO(1, RegistrationData)
	ZEND_ARG_INFO(1, ErrorCode)
	ZEND_ARG_INFO(1, ErrorMessage)
	ZEND_ARG_INFO(1, RequestID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONSaveU2FRegisterResponse, 0, 0, 5)
	ZEND_ARG_INFO(0, Version)
	ZEND_ARG_INFO(0, ClientData)
	ZEND_ARG_TYPE_INFO(0, RegistrationData, 0, 1)
	ZEND_ARG_INFO(0, RequestID)
	ZEND_ARG_INFO(0, JSAPIVersion)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONSaveU2FRegisterResponseError, 0, 0, 4)
	ZEND_ARG_INFO(0, ErrorCode)
	ZEND_ARG_INFO(0, ErrorMessage)
	ZEND_ARG_INFO(0, RequestID)
	ZEND_ARG_INFO(0, JSAPIVersion)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONLoadU2FSignRequest, 0, 0, 8)
	ZEND_ARG_INFO(0, U2FSignRequest)
	ZEND_ARG_INFO(1, Challenge)
	ZEND_ARG_INFO(1, AppId)
	ZEND_ARG_OBJ_INFO(0, UserKeys, TElU2FUserKeys, 1)
	ZEND_ARG_OBJ_INFO(0, Challenges, TElStringList, 1)
	ZEND_ARG_OBJ_INFO(0, AppIDs, TElStringList, 1)
	ZEND_ARG_INFO(1, TimeoutSeconds)
	ZEND_ARG_INFO(1, RequestID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONSaveU2FSignRequest, 0, 0, 6)
	ZEND_ARG_INFO(0, Challenge)
	ZEND_ARG_INFO(0, AppID)
	ZEND_ARG_OBJ_INFO(0, UserKeys, TElU2FUserKeys, 1)
	ZEND_ARG_INFO(0, TimeoutSeconds)
	ZEND_ARG_INFO(0, RequestID)
	ZEND_ARG_INFO(0, JSAPIVersion)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONLoadU2FSignResponse, 0, 0, 7)
	ZEND_ARG_INFO(0, U2FSignResponse)
	ZEND_ARG_INFO(1, KeyHandle)
	ZEND_ARG_INFO(1, SignatureData)
	ZEND_ARG_INFO(1, ClientData)
	ZEND_ARG_INFO(1, ErrorCode)
	ZEND_ARG_INFO(1, ErrorMessage)
	ZEND_ARG_INFO(1, RequestID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONSaveU2FSignResponse, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, KeyHandle, 0, 1)
	ZEND_ARG_TYPE_INFO(0, SignatureData, 0, 1)
	ZEND_ARG_INFO(0, ClientData)
	ZEND_ARG_INFO(0, RequestID)
	ZEND_ARG_INFO(0, JSAPIVersion)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSONSaveU2FSignResponseError, 0, 0, 4)
	ZEND_ARG_INFO(0, ErrorCode)
	ZEND_ARG_INFO(0, ErrorMessage)
	ZEND_ARG_INFO(0, RequestID)
	ZEND_ARG_INFO(0, JSAPIVersion)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FJSAPIErrorToServerError, 0, 0, 1)
	ZEND_ARG_INFO(0, ErrorCode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FBase64UrlEncodeBytes, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FBase64UrlDecodeBytes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FVerifyRegistrationSignature, 0, 0, 6)
	ZEND_ARG_TYPE_INFO(0, ChallengeParameter, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ApplicationParameter, 0, 1)
	ZEND_ARG_TYPE_INFO(0, KeyHandle, 0, 1)
	ZEND_ARG_TYPE_INFO(0, UserPublicKey, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Signature, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AttestationCertificate, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBU2FCommon_U2FVerifyAuthenticationSignature, 0, 0, 6)
	ZEND_ARG_TYPE_INFO(0, ChallengeParameter, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ApplicationParameter, 0, 1)
	ZEND_ARG_TYPE_INFO(0, UserPublicKey, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Signature, 0, 1)
	ZEND_ARG_INFO(0, UserPresence)
	ZEND_ARG_INFO(0, Counter)
ZEND_END_ARG_INFO()
#endif

// SBSftpCommon unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSftpCommon_WriteDefaultAttributes, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(1, Attributes, TElSftpFileAttributes, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSftpCommon_RealPathControlToByte, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSftpCommon_ByteToRealPathControl, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSftpCommon_FileOpenAccessToUInt32, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSftpCommon_UInt32ToFileOpenAccess, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSftpCommon_UInt32ToRenameFlags, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSftpCommon_GetSFTPPacketNameByCode, 0, 0, 1)
	ZEND_ARG_INFO(0, Code)
ZEND_END_ARG_INFO()

// SBSMIMECore unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSMIMECore_Initialize, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBSSHConstants unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHConstants_GetSSHPacketNameByCode, 0, 0, 1)
	ZEND_ARG_INFO(0, Code)
ZEND_END_ARG_INFO()

// SBSSHUtils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHUtils_WriteString, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, S, 0, 1)
	ZEND_ARG_INFO(0, AddZero)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHUtils_WriteBitCount, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHUtils_ReadSSH2MPInt, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(1, HeaderSz)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHUtils_ReadBoolean, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHUtils_ReadString, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHUtils_ReadBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size_or_AIndex)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHUtils_ReadSSH1MPInt, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHUtils_ReadLength, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size_or_AIndex)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHUtils_ReadUINT16, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHUtils_ReadUINT64, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHUtils_WriteSSH2MPInt, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, P, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHUtils_WriteBoolean, 0, 0, 1)
	ZEND_ARG_INFO(0, B)
ZEND_END_ARG_INFO()

// SBSSHCommon unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHCommon_SSHEncodeString, 0, 0, 4)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_INFO(0, UseUTF8)
	ZEND_ARG_INFO(0, NoTranslation)
	ZEND_ARG_OBJ_INFO(0, Converter, TPlConverter, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHCommon_SSHDecodeString, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
	ZEND_ARG_INFO(0, UseUTF8)
	ZEND_ARG_INFO(0, NoTranslation)
	ZEND_ARG_OBJ_INFO(0, Converter, TPlConverter, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHCommon_SSHMemoryManager, 0, 0, 0)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
// SBSSHAuthAgent unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHAuthAgent_PageantAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSHAuthAgent_ParseAccessInfo, 0, 0, 3)
	ZEND_ARG_INFO(0, AInfo)
	ZEND_ARG_INFO(1, Port)
	ZEND_ARG_INFO(1, Magic)
ZEND_END_ARG_INFO()
#endif

// SBSSLCommon unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSLCommon_ConvertAlertDescriptionToErrorCode, 0, 0, 1)
	ZEND_ARG_INFO(0, Desc)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSLCommon_ConvertSSLError, 0, 0, 1)
	ZEND_ARG_INFO(0, AD)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSLCommon_GetAlertDescriptionFromValidityReason, 0, 0, 1)
	ZEND_ARG_INFO(0, Reason)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSLCommon_GetSecondsCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSLCommon_GetCurveByTlsCurve, 0, 0, 1)
	ZEND_ARG_INFO(0, Curve)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSLCommon_GetTlsCurveByCurve, 0, 0, 1)
	ZEND_ARG_INFO(0, Curve)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSLCommon_ReadLengthPrefixedArray, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, ABuffer, 0, 1)
	ZEND_ARG_INFO(0, ASize)
	ZEND_ARG_INFO(0, ALenBytes)
	ZEND_ARG_INFO(1, BytesRead)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSLCommon_SSLMemoryManager, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBSSLServer unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSLServer_CreateSSLServerTemplate, 0, 0, 1)
	ZEND_ARG_INFO(0, Config)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSLServer_GetTLSCipherSuiteByCode, 0, 0, 3)
	ZEND_ARG_INFO(0, B1)
	ZEND_ARG_INFO(0, B2)
	ZEND_ARG_INFO(1, CipherSuite)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSLServer_PrepareSSLServerEnvironment, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSLServer_GetSSLDHKeyLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSSLServer_SetSSLDHKeyLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

// SBSessionPool unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBSessionPool_FreeSessionContext, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Ctx, TSBSessionContext, 1)
ZEND_END_ARG_INFO()

// SBXMLCore unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLCore_isXMLblank, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLCore_isXMLIdeographic, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLCore_isXMLBaseChar, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLCore_isXMLCombining, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLCore_isXMLDigit, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLCore_isXMLExtender, 0, 0, 1)
	ZEND_ARG_INFO(0, c)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLCore_XMLGetPrefix, 0, 0, 1)
	ZEND_ARG_INFO(0, AName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLCore_XMLGetLocalName, 0, 0, 1)
	ZEND_ARG_INFO(0, AName)
ZEND_END_ARG_INFO()

// SBXMLUtils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_ParseElementFromXMLString, 0, 0, 2)
	ZEND_ARG_INFO(0, Data)
	ZEND_ARG_OBJ_INFO(0, Document, TElXMLDOMDocument, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_ParseNodeListFromXMLString, 0, 0, 2)
	ZEND_ARG_INFO(0, Data)
	ZEND_ARG_OBJ_INFO(0, Document, TElXMLDOMDocument, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_ConvertToBase64String, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_ConvertFromBase64String, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_ConvertBinaryToBigInt, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
	ZEND_ARG_INFO(0, AllowNegativeNumbers)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_ConvertBigIntToBinary, 0, 0, 2)
	ZEND_ARG_INFO(0, Value)
	ZEND_ARG_INFO(0, AllowHexNumbers)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_ConvertHexToBinary, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_AddTextToXMLElement, 0, 0, 2)
	ZEND_ARG_INFO(0, Text)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_InsertTextBeforeXMLElement, 0, 0, 3)
	ZEND_ARG_INFO(0, Text)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
	ZEND_ARG_OBJ_INFO(0, Ref, TElXMLDOMNode, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_GetTextFromXMLElement, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_GetStrictTextFromXMLElement, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_FindChildElementByLocalName, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
	ZEND_ARG_INFO(0, LocalName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_FindChildElement, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, NamespaceURI)
	ZEND_ARG_INFO(0, DefaultPrefix)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_FindElementById, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, RootElement, TElXMLDOMElement, 1)
	ZEND_ARG_INFO(0, ID)
	ZEND_ARG_INFO(0, NamespaceURI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_FindElementByName, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, RootElement, TElXMLDOMElement, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, NamespaceURI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_ExtractIdFromLocalURI, 0, 0, 1)
	ZEND_ARG_INFO(0, URI)
	ZEND_ARG_INFO(1, Id)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_GetElementId, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_SetElementId, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_CanonicalizationMethodToURI, 0, 0, 1)
	ZEND_ARG_INFO(0, ACanonicalizationMethod)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_URIToCanonicalizationMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, AURI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_AddPrefixes, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
	ZEND_ARG_INFO(0, Prefixes)
	ZEND_ARG_INFO(0, NamespaceURI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_DateTimeToXMLString, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
	ZEND_ARG_INFO(0, Format)
	ZEND_ARG_INFO(0, TimeZoneOffset)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_XMLStringToDateTime, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_DateTimeFormatToString, 0, 0, 1)
	ZEND_ARG_INFO(0, Format)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_DecodeXMLEntities, 0, 0, 1)
	ZEND_ARG_INFO(0, Str)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLUtils_EncodeXMLEntities, 0, 0, 1)
	ZEND_ARG_INFO(0, Str)
ZEND_END_ARG_INFO()

// SBXMLAdES unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLAdES_GetXAdESVersion, 0, 0, 1)
	ZEND_ARG_INFO(0, NamespaceURI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLAdES_GetXAdESNamespaceURI, 0, 0, 1)
	ZEND_ARG_INFO(0, Version)
	ZEND_ARG_INFO(0, SupportedV141)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLAdES_GetXAdESReferenceType, 0, 0, 1)
	ZEND_ARG_INFO(0, Version)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLAdES_XAdESVersionToString, 0, 0, 1)
	ZEND_ARG_INFO(0, XAdESVersion)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLAdES_XAdESFormToString, 0, 0, 1)
	ZEND_ARG_INFO(0, XAdESForm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLAdES_XAdESFormGreaterThan, 0, 0, 2)
	ZEND_ARG_INFO(0, XAdESForm)
	ZEND_ARG_INFO(0, XAdESForm2)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLAdES_XAdESFormGreaterOrEqual, 0, 0, 2)
	ZEND_ARG_INFO(0, XAdESForm)
	ZEND_ARG_INFO(0, XAdESForm2)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLAdES_IsExtendedXAdESForm, 0, 0, 1)
	ZEND_ARG_INFO(0, XAdESForm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLAdES_XAdESFormToExtendedForm, 0, 0, 1)
	ZEND_ARG_INFO(0, XAdESForm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLAdES_XAdESFormToStandardForm, 0, 0, 1)
	ZEND_ARG_INFO(0, XAdESForm)
ZEND_END_ARG_INFO()

// SBXMLSec unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSec_ToCryptoBinary, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
	ZEND_ARG_INFO(0, KeepTrailingZero)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSec_FindChildElementEnc, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSec_FindChildElementSig, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSec_FindChildElementXAdES, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, NamespaceURI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSec_CalculateDigest, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, aMethod)
	ZEND_ARG_TYPE_INFO(0, Manager_or_Parameters, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Prov_or_Manager, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Prov, TElCustomCryptoProvider, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSec_CalculateDigestStream, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, aMethod)
	ZEND_ARG_OBJ_INFO(0, Manager, TElCustomCryptoProviderManager, 1)
	ZEND_ARG_OBJ_INFO(0, Prov, TElCustomCryptoProvider, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSec_DigestMethodToHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, DigestMethod)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSec_DigestMethodToURI, 0, 0, 1)
	ZEND_ARG_INFO(0, DigestMethod)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSec_URIToDigestMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, DigestMethod)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSec_GetDigestMethodFromSignatureMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, SignatureMethod)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSec_HashAlgorithmToDigestMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, HashAlgorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSec_FormatRDN, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, RDN, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSec_ExtractRDN, 0, 0, 2)
	ZEND_ARG_INFO(0, Data)
	ZEND_ARG_OBJ_INFO(0, RDN, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSec_RDNDescriptorMap, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBXMLTransform unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLTransform_Initialize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLTransform_LoadDocumentFromData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLTransform_NodeToNodeList, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Node, TElXMLDOMNode, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLTransform_RegisterTransformClass, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TransformClass, TElXMLTransformClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLTransform_UnregisterTransformClass, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TransformClass, TElXMLTransformClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLTransform_FindTransformClass, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

// SBXMLSOAPCore unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSOAPCore_GetSOAPNamespaceURI, 0, 0, 1)
	ZEND_ARG_INFO(0, Version)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSOAPCore_SOAPSecGetElementId, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSOAPCore_SOAPSecSetElementId, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

// SBXMLWSSCore unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLWSSCore_WSUGetElementId, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLWSSCore_WSUSetElementId, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLWSSCore_WSSETokenTypeToURI, 0, 0, 1)
	ZEND_ARG_INFO(0, TokenType)
ZEND_END_ARG_INFO()

// SBXMLSOAP unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSOAP_RegisterSecurityHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, HandlerClass, TElXMLSOAPSignatureHandlerClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSOAP_UnregisterSecurityHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, HandlerClass, TElXMLSOAPSignatureHandlerClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSOAP_Initialize, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBXMLSOAPClient unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSOAPClient_SOAPParametersManager, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBArcBase unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBArcBase_GetUseUTCTimeInNewEntries, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBArcBase_SetUseUTCTimeInNewEntries, 0, 0, 1)
	ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

// SBZipUtils unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_BufferToUINT16, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_UINT16ToBuffer, 0, 0, 3)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_BufferToUINT32, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_UINT32ToBuffer, 0, 0, 3)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_BufferToUINT64, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_UINT64ToBuffer, 0, 0, 3)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_ReverseBuffer, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_ZipInitializeEncryption, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(1, Context, TSBZIPEncryptionContext, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_ZipUpdateKeys, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(1, Context, TSBZIPEncryptionContext, 0)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_ZipEncrypt, 0, 0, 6)
	ZEND_ARG_OBJ_INFO(1, Context, TSBZIPEncryptionContext, 0)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(1, OutBuffer)
	ZEND_ARG_INFO(0, OutIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_ZipDecrypt, 0, 0, 6)
	ZEND_ARG_OBJ_INFO(1, Context, TSBZIPEncryptionContext, 0)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(1, OutBuffer)
	ZEND_ARG_INFO(0, OutIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_ZipHashAlgorithmToSBB, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_SBBHashAlgorithmToZip, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_ZipSymmetricAlgorithmToSBB, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_ZipCipherDefaultKeySize, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_ZipCipherIVSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_ZipCompressionMethodName, 0, 0, 1)
	ZEND_ARG_INFO(0, CompressionMethod)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_ZipEncryptionAlgorithmName, 0, 0, 1)
	ZEND_ARG_INFO(0, EncryptionAlgorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_ZipVersionStr, 0, 0, 1)
	ZEND_ARG_INFO(0, Version)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_OEMEncodingName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_ANSIEncodingName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBZipUtils_CopyStreamPart, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(0, Source, TStream, 1)
	ZEND_ARG_INFO(0, SourcePosition)
	ZEND_ARG_OBJ_INFO(0, Dest, TStream, 1)
	ZEND_ARG_INFO(0, DestPosition)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

// SBXMLSAMLBind unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLBind_ParseHTTPParameters, 0, 0, 2)
	ZEND_ARG_INFO(0, S)
	ZEND_ARG_OBJ_INFO(0, Output, TElStringList, 1)
ZEND_END_ARG_INFO()

// SBXMLSAMLCommon unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCommon_XMLDocToStr, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Doc, TElXMLDOMDocument, 1)
ZEND_END_ARG_INFO()

// SBXMLSAMLCore unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCore_GetSAMLNSMap, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCore_SetSAMLNSMap, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElXMLNamespaceMap, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCore_CreateElementNS, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Document, TElXMLDOMDocument, 1)
	ZEND_ARG_INFO(0, URI)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCore_StreamToStr, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Input, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCore_StreamToStrUTF8, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Input, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCore_StreamToArray, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Input, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCore_FindChildElement, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, NamespaceURI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCore_FreeList, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, List, TList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCore_XMLStrToBool, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCore_BoolToXMLStr, 0, 0, 1)
	ZEND_ARG_INFO(0, B)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCore_GenerateID, 0, 0, 0)
	ZEND_ARG_INFO(0, Len)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCore_RandomString, 0, 0, 0)
	ZEND_ARG_INFO(0, Len)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCore_DateTimeToString, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, DT, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLCore_CurrentDateTime, 0, 0, 0)
ZEND_END_ARG_INFO()

// SBXMLSAMLMetadata unit arg info

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLMetadata_ContactTypeToStr, 0, 0, 1)
	ZEND_ARG_INFO(0, T)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLMetadata_StrToContactType, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLMetadata_KeyUsageToStr, 0, 0, 1)
	ZEND_ARG_INFO(0, U)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_SBXMLSAMLMetadata_StrToKeyUsage, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

const zend_function_entry sbb_functions[] = {
	SB_PHP_FE(SBUtils, BytesOfString, arginfo_SBUtils_BytesOfString)
	SB_PHP_FE(SBUtils, StringOfBytes, arginfo_SBUtils_StringOfBytes)

	// SBConstants unit functions
	SB_PHP_FE(SBConstants, GetPBEAlgorithmByOID, arginfo_SBConstants_GetPBEAlgorithmByOID)
	SB_PHP_FE(SBConstants, GetOIDByPBEAlgorithm, arginfo_SBConstants_GetOIDByPBEAlgorithm)
	SB_PHP_FE(SBConstants, GetPKAlgorithmByOID, arginfo_SBConstants_GetPKAlgorithmByOID)
	SB_PHP_FE(SBConstants, GetOIDByPKAlgorithm, arginfo_SBConstants_GetOIDByPKAlgorithm)
	SB_PHP_FE(SBConstants, GetSigAlgorithmByOID, arginfo_SBConstants_GetSigAlgorithmByOID)
	SB_PHP_FE(SBConstants, GetOIDBySigAlgorithm, arginfo_SBConstants_GetOIDBySigAlgorithm)
	SB_PHP_FE(SBConstants, GetHashAlgorithmByOID, arginfo_SBConstants_GetHashAlgorithmByOID)
	SB_PHP_FE(SBConstants, GetOIDByHashAlgorithm, arginfo_SBConstants_GetOIDByHashAlgorithm)
	SB_PHP_FE(SBConstants, GetAlgorithmByOID, arginfo_SBConstants_GetAlgorithmByOID)
	SB_PHP_FE(SBConstants, GetOIDByAlgorithm, arginfo_SBConstants_GetOIDByAlgorithm)
	SB_PHP_FE(SBConstants, GetAlgorithmNameByAlgorithm, arginfo_SBConstants_GetAlgorithmNameByAlgorithm)
	SB_PHP_FE(SBConstants, GetAlgorithmNameByOID, arginfo_SBConstants_GetAlgorithmNameByOID)
	SB_PHP_FE(SBConstants, GetHashAlgorithmBySigAlgorithm, arginfo_SBConstants_GetHashAlgorithmBySigAlgorithm)
	SB_PHP_FE(SBConstants, GetHMACAlgorithmByHashAlgorithm, arginfo_SBConstants_GetHMACAlgorithmByHashAlgorithm)
	SB_PHP_FE(SBConstants, GetHashAlgorithmByHMACAlgorithm, arginfo_SBConstants_GetHashAlgorithmByHMACAlgorithm)
	SB_PHP_FE(SBConstants, GetSigAlgorithmByHashAlgorithm, arginfo_SBConstants_GetSigAlgorithmByHashAlgorithm)
	SB_PHP_FE(SBConstants, GetCertAlgorithmFromNormalizedAlgorithms, arginfo_SBConstants_GetCertAlgorithmFromNormalizedAlgorithms)
	SB_PHP_FE(SBConstants, GetKeyAlgorithmBySigAlgorithm, arginfo_SBConstants_GetKeyAlgorithmBySigAlgorithm)
	SB_PHP_FE(SBConstants, GetSigAlgorithmByKeyAlgorithm, arginfo_SBConstants_GetSigAlgorithmByKeyAlgorithm)
	SB_PHP_FE(SBConstants, IsSymmetricKeyAlgorithm, arginfo_SBConstants_IsSymmetricKeyAlgorithm)
	SB_PHP_FE(SBConstants, IsHashAlgorithm, arginfo_SBConstants_IsHashAlgorithm)
	SB_PHP_FE(SBConstants, IsMACAlgorithm, arginfo_SBConstants_IsMACAlgorithm)
	SB_PHP_FE(SBConstants, IsPublicKeyAlgorithm, arginfo_SBConstants_IsPublicKeyAlgorithm)
	SB_PHP_FE(SBConstants, IsAEADAlgorithm, arginfo_SBConstants_IsAEADAlgorithm)
	SB_PHP_FE(SBConstants, NormalizeAlgorithmConstant, arginfo_SBConstants_NormalizeAlgorithmConstant)
	SB_PHP_FE(SBConstants, MGF1AlgorithmByHash, arginfo_SBConstants_MGF1AlgorithmByHash)
	SB_PHP_FE(SBConstants, HashAlgorithmByMGF1, arginfo_SBConstants_HashAlgorithmByMGF1)

	// SBASN1 unit functions
	SB_PHP_FE(SBASN1, asn1ParseStream, arginfo_SBASN1_asn1ParseStream)
	SB_PHP_FE(SBASN1, asn1AddTypeEqu, arginfo_SBASN1_asn1AddTypeEqu)
	SB_PHP_FE(SBASN1, WriteListSequence, arginfo_SBASN1_WriteListSequence)
	SB_PHP_FE(SBASN1, WritePrimitiveListSeq, arginfo_SBASN1_WritePrimitiveListSeq)
	SB_PHP_FE(SBASN1, WriteExplicit, arginfo_SBASN1_WriteExplicit)
	SB_PHP_FE(SBASN1, WriteInteger, arginfo_SBASN1_WriteInteger)
	SB_PHP_FE(SBASN1, WriteOID, arginfo_SBASN1_WriteOID)
	SB_PHP_FE(SBASN1, WritePrintableString, arginfo_SBASN1_WritePrintableString)
	SB_PHP_FE(SBASN1, WriteUTF8String, arginfo_SBASN1_WriteUTF8String)
	SB_PHP_FE(SBASN1, WriteIA5String, arginfo_SBASN1_WriteIA5String)
	SB_PHP_FE(SBASN1, WriteUTCTime, arginfo_SBASN1_WriteUTCTime)
	SB_PHP_FE(SBASN1, WriteGeneralizedTime, arginfo_SBASN1_WriteGeneralizedTime)
	SB_PHP_FE(SBASN1, WriteSize, arginfo_SBASN1_WriteSize)
	SB_PHP_FE(SBASN1, WriteBitString, arginfo_SBASN1_WriteBitString)
	SB_PHP_FE(SBASN1, WriteOctetString, arginfo_SBASN1_WriteOctetString)
	SB_PHP_FE(SBASN1, WriteVisibleString, arginfo_SBASN1_WriteVisibleString)
	SB_PHP_FE(SBASN1, WriteBoolean, arginfo_SBASN1_WriteBoolean)
	SB_PHP_FE(SBASN1, WriteNULL, arginfo_SBASN1_WriteNULL)
	SB_PHP_FE(SBASN1, WritePrimitive, arginfo_SBASN1_WritePrimitive)
	SB_PHP_FE(SBASN1, WriteStringPrimitive, arginfo_SBASN1_WriteStringPrimitive)
	SB_PHP_FE(SBASN1, ASN1ParserFactory, arginfo_SBASN1_ASN1ParserFactory)

	// SBASN1Tree unit functions
	SB_PHP_FE(SBASN1Tree, asymWriteInteger, arginfo_SBASN1Tree_asymWriteInteger)
	SB_PHP_FE(SBASN1Tree, ASN1ReadInteger, arginfo_SBASN1Tree_ASN1ReadInteger)
	SB_PHP_FE(SBASN1Tree, ASN1ReadInteger64, arginfo_SBASN1Tree_ASN1ReadInteger64)
	SB_PHP_FE(SBASN1Tree, ASN1WriteInteger, arginfo_SBASN1Tree_ASN1WriteInteger)
	SB_PHP_FE(SBASN1Tree, ASN1WriteInteger64, arginfo_SBASN1Tree_ASN1WriteInteger64)
	SB_PHP_FE(SBASN1Tree, ASN1ReadSimpleValue, arginfo_SBASN1Tree_ASN1ReadSimpleValue)
	SB_PHP_FE(SBASN1Tree, ASN1WriteTagAndLength, arginfo_SBASN1Tree_ASN1WriteTagAndLength)
	SB_PHP_FE(SBASN1Tree, ASN1ReadBoolean, arginfo_SBASN1Tree_ASN1ReadBoolean)
	SB_PHP_FE(SBASN1Tree, ASN1WriteBoolean, arginfo_SBASN1Tree_ASN1WriteBoolean)
	SB_PHP_FE(SBASN1Tree, ASN1ReadString, arginfo_SBASN1Tree_ASN1ReadString)
	SB_PHP_FE(SBASN1Tree, ASN1ReadStringAnsi, arginfo_SBASN1Tree_ASN1ReadStringAnsi)
	SB_PHP_FE(SBASN1Tree, FormatAttributeValue, arginfo_SBASN1Tree_FormatAttributeValue)
	SB_PHP_FE(SBASN1Tree, UnformatAttributeValue, arginfo_SBASN1Tree_UnformatAttributeValue)
	SB_PHP_FE(SBASN1Tree, GetTagDisplayName, arginfo_SBASN1Tree_GetTagDisplayName)
	SB_PHP_FE(SBASN1Tree, GetTagByDisplayName, arginfo_SBASN1Tree_GetTagByDisplayName)
	SB_PHP_FE(SBASN1Tree, GetMaxASN1TreeDepth, arginfo_SBASN1Tree_GetMaxASN1TreeDepth)
	SB_PHP_FE(SBASN1Tree, SetMaxASN1TreeDepth, arginfo_SBASN1Tree_SetMaxASN1TreeDepth)
	SB_PHP_FE(SBASN1Tree, GetMaxASN1BufferLength, arginfo_SBASN1Tree_GetMaxASN1BufferLength)
	SB_PHP_FE(SBASN1Tree, SetMaxASN1BufferLength, arginfo_SBASN1Tree_SetMaxASN1BufferLength)
	SB_PHP_FE(SBASN1Tree, GetASN1CopyBuffers, arginfo_SBASN1Tree_GetASN1CopyBuffers)
	SB_PHP_FE(SBASN1Tree, SetASN1CopyBuffers, arginfo_SBASN1Tree_SetASN1CopyBuffers)
	SB_PHP_FE(SBASN1Tree, ASN1TagInfoFactory, arginfo_SBASN1Tree_ASN1TagInfoFactory)

	// SBMSKeyBlob unit functions
	SB_PHP_FE(SBMSKeyBlob, WriteMSPublicKeyBlob, arginfo_SBMSKeyBlob_WriteMSPublicKeyBlob)
	SB_PHP_FE(SBMSKeyBlob, WriteMSDSSPublicKeyBlob, arginfo_SBMSKeyBlob_WriteMSDSSPublicKeyBlob)
	SB_PHP_FE(SBMSKeyBlob, ParseMSKeyBlob, arginfo_SBMSKeyBlob_ParseMSKeyBlob)
	SB_PHP_FE(SBMSKeyBlob, WriteMSKeyBlob, arginfo_SBMSKeyBlob_WriteMSKeyBlob)
	SB_PHP_FE(SBMSKeyBlob, WriteMSKeyBlobEx, arginfo_SBMSKeyBlob_WriteMSKeyBlobEx)

	// SBPEM unit functions
	SB_PHP_FE(SBPEM, Encode, arginfo_SBPEM_Encode)
	SB_PHP_FE(SBPEM, EncodeEx, arginfo_SBPEM_EncodeEx)
	SB_PHP_FE(SBPEM, Decode, arginfo_SBPEM_Decode)
	SB_PHP_FE(SBPEM, IsBase64UnicodeSequence, arginfo_SBPEM_IsBase64UnicodeSequence)
	SB_PHP_FE(SBPEM, IsBase64Sequence, arginfo_SBPEM_IsBase64Sequence)
	SB_PHP_FE(SBPEM, IsPEMSequence, arginfo_SBPEM_IsPEMSequence)
	SB_PHP_FE(SBPEM, RaisePEMError, arginfo_SBPEM_RaisePEMError)

	// SBRandom unit functions
	SB_PHP_FE(SBRandom, SBRndTimeSeed, arginfo_SBRandom_SBRndTimeSeed)
	SB_PHP_FE(SBRandom, SBRndInit, arginfo_SBRandom_SBRndInit)
	SB_PHP_FE(SBRandom, SBRndInitOnDemand, arginfo_SBRandom_SBRndInitOnDemand)
	SB_PHP_FE(SBRandom, SBRndCreate, arginfo_SBRandom_SBRndCreate)
	SB_PHP_FE(SBRandom, SBRndDestroy, arginfo_SBRandom_SBRndDestroy)
	SB_PHP_FE(SBRandom, SBRndSeed, arginfo_SBRandom_SBRndSeed)
	SB_PHP_FE(SBRandom, SBRndSeedTime, arginfo_SBRandom_SBRndSeedTime)
	SB_PHP_FE(SBRandom, SBRndGenerate, arginfo_SBRandom_SBRndGenerate)
	SB_PHP_FE(SBRandom, SBRndGenerateLInt, arginfo_SBRandom_SBRndGenerateLInt)
	SB_PHP_FE(SBRandom, SBRndRandomize, arginfo_SBRandom_SBRndRandomize)
	SB_PHP_FE(SBRandom, SBRndString, arginfo_SBRandom_SBRndString)

	// SBUtils unit functions
	SB_PHP_FE(SBUtils, DigestToStr, arginfo_SBUtils_DigestToStr)
	SB_PHP_FE(SBUtils, StrToDigest, arginfo_SBUtils_StrToDigest)
	SB_PHP_FE(SBUtils, DigestToBinary, arginfo_SBUtils_DigestToBinary)
	SB_PHP_FE(SBUtils, BinaryToDigest, arginfo_SBUtils_BinaryToDigest)
	SB_PHP_FE(SBUtils, DigestToByteArray128, arginfo_SBUtils_DigestToByteArray128)
	SB_PHP_FE(SBUtils, DigestToByteArray160, arginfo_SBUtils_DigestToByteArray160)
	SB_PHP_FE(SBUtils, DigestToByteArray224, arginfo_SBUtils_DigestToByteArray224)
	SB_PHP_FE(SBUtils, DigestToByteArray256, arginfo_SBUtils_DigestToByteArray256)
	SB_PHP_FE(SBUtils, DigestToByteArray320, arginfo_SBUtils_DigestToByteArray320)
	SB_PHP_FE(SBUtils, DigestToByteArray384, arginfo_SBUtils_DigestToByteArray384)
	SB_PHP_FE(SBUtils, DigestToByteArray512, arginfo_SBUtils_DigestToByteArray512)
	SB_PHP_FE(SBUtils, ByteArrayToDigest128, arginfo_SBUtils_ByteArrayToDigest128)
	SB_PHP_FE(SBUtils, ByteArrayToDigest160, arginfo_SBUtils_ByteArrayToDigest160)
	SB_PHP_FE(SBUtils, ByteArrayToDigest224, arginfo_SBUtils_ByteArrayToDigest224)
	SB_PHP_FE(SBUtils, ByteArrayToDigest256, arginfo_SBUtils_ByteArrayToDigest256)
	SB_PHP_FE(SBUtils, ByteArrayToDigest320, arginfo_SBUtils_ByteArrayToDigest320)
	SB_PHP_FE(SBUtils, ByteArrayToDigest384, arginfo_SBUtils_ByteArrayToDigest384)
	SB_PHP_FE(SBUtils, ByteArrayToDigest512, arginfo_SBUtils_ByteArrayToDigest512)
	SB_PHP_FE(SBUtils, SBIncPtr, arginfo_SBUtils_SBIncPtr)
	SB_PHP_FE(SBUtils, SBDecPtr, arginfo_SBUtils_SBDecPtr)
	SB_PHP_FE(SBUtils, PointerToLIntP, arginfo_SBUtils_PointerToLIntP)
	SB_PHP_FE(SBUtils, PointerToLInt, arginfo_SBUtils_PointerToLInt)
	SB_PHP_FE(SBUtils, LIntToPointerP, arginfo_SBUtils_LIntToPointerP)
	SB_PHP_FE(SBUtils, LIntToPointer, arginfo_SBUtils_LIntToPointer)
	SB_PHP_FE(SBUtils, LIntToPointerTrunc, arginfo_SBUtils_LIntToPointerTrunc)
	SB_PHP_FE(SBUtils, BufferBitCount, arginfo_SBUtils_BufferBitCount)
	SB_PHP_FE(SBUtils, BeautifyBinaryString, arginfo_SBUtils_BeautifyBinaryString)
	SB_PHP_FE(SBUtils, SwapUInt16, arginfo_SBUtils_SwapUInt16)
	SB_PHP_FE(SBUtils, SwapInt32, arginfo_SBUtils_SwapInt32)
	SB_PHP_FE(SBUtils, SwapUInt32, arginfo_SBUtils_SwapUInt32)
	SB_PHP_FE(SBUtils, SwapInt64, arginfo_SBUtils_SwapInt64)
	SB_PHP_FE(SBUtils, SwapSomeInt, arginfo_SBUtils_SwapSomeInt)
	SB_PHP_FE(SBUtils, RotateInteger, arginfo_SBUtils_RotateInteger)
	SB_PHP_FE(SBUtils, TrimZeros, arginfo_SBUtils_TrimZeros)
	SB_PHP_FE(SBUtils, SubArray, arginfo_SBUtils_SubArray)
	SB_PHP_FE(SBUtils, SwapBigEndianWords, arginfo_SBUtils_SwapBigEndianWords)
	SB_PHP_FE(SBUtils, SwapBigEndianDWords, arginfo_SBUtils_SwapBigEndianDWords)
	SB_PHP_FE(SBUtils, IsEmptyDateTime, arginfo_SBUtils_IsEmptyDateTime)
	SB_PHP_FE(SBUtils, EmptyDateTime, arginfo_SBUtils_EmptyDateTime)
	SB_PHP_FE(SBUtils, ByteArrayFromPtr, arginfo_SBUtils_ByteArrayFromPtr)
	SB_PHP_FE(SBUtils, TrimLeadingZeros, arginfo_SBUtils_TrimLeadingZeros)
	SB_PHP_FE(SBUtils, TrimTrailingZeros, arginfo_SBUtils_TrimTrailingZeros)
	SB_PHP_FE(SBUtils, PrefixByteArray, arginfo_SBUtils_PrefixByteArray)
	SB_PHP_FE(SBUtils, SuffixByteArray, arginfo_SBUtils_SuffixByteArray)
	SB_PHP_FE(SBUtils, FillByteArray, arginfo_SBUtils_FillByteArray)
	SB_PHP_FE(SBUtils, GetBytes64, arginfo_SBUtils_GetBytes64)
	SB_PHP_FE(SBUtils, GetBytes32, arginfo_SBUtils_GetBytes32)
	SB_PHP_FE(SBUtils, GetBytes16, arginfo_SBUtils_GetBytes16)
	SB_PHP_FE(SBUtils, GetBytes8, arginfo_SBUtils_GetBytes8)
	SB_PHP_FE(SBUtils, LocalDateTimeToSystemDateTime, arginfo_SBUtils_LocalDateTimeToSystemDateTime)
	SB_PHP_FE(SBUtils, SystemDateTimeToLocalDateTime, arginfo_SBUtils_SystemDateTimeToLocalDateTime)
	SB_PHP_FE(SBUtils, DateTimeAddMillis, arginfo_SBUtils_DateTimeAddMillis)
	SB_PHP_FE(SBUtils, DateTimeAddDays, arginfo_SBUtils_DateTimeAddDays)
	SB_PHP_FE(SBUtils, DateTimeAddHours, arginfo_SBUtils_DateTimeAddHours)
	SB_PHP_FE(SBUtils, DateTimeAddMinutes, arginfo_SBUtils_DateTimeAddMinutes)
	SB_PHP_FE(SBUtils, DateTimeAddSeconds, arginfo_SBUtils_DateTimeAddSeconds)
	SB_PHP_FE(SBUtils, DateTimeAddYears, arginfo_SBUtils_DateTimeAddYears)
	SB_PHP_FE(SBUtils, DateTimeAfter, arginfo_SBUtils_DateTimeAfter)
	SB_PHP_FE(SBUtils, DateTimeBefore, arginfo_SBUtils_DateTimeBefore)
	SB_PHP_FE(SBUtils, DateTimeClone, arginfo_SBUtils_DateTimeClone)
	SB_PHP_FE(SBUtils, DateTimeCompare, arginfo_SBUtils_DateTimeCompare)
	SB_PHP_FE(SBUtils, DateTimeEquals, arginfo_SBUtils_DateTimeEquals)
	SB_PHP_FE(SBUtils, DateTimeGetMonth, arginfo_SBUtils_DateTimeGetMonth)
	SB_PHP_FE(SBUtils, DateTimeGetYear, arginfo_SBUtils_DateTimeGetYear)
	SB_PHP_FE(SBUtils, DateTimeIsLeapYear, arginfo_SBUtils_DateTimeIsLeapYear)
	SB_PHP_FE(SBUtils, DateTimeNow, arginfo_SBUtils_DateTimeNow)
	SB_PHP_FE(SBUtils, DateTimeToString, arginfo_SBUtils_DateTimeToString)
	SB_PHP_FE(SBUtils, DateTimeUtcNow, arginfo_SBUtils_DateTimeUtcNow)
	SB_PHP_FE(SBUtils, DateTimeGetHour, arginfo_SBUtils_DateTimeGetHour)
	SB_PHP_FE(SBUtils, DateTimeGetMinute, arginfo_SBUtils_DateTimeGetMinute)
	SB_PHP_FE(SBUtils, CompareMem, arginfo_SBUtils_CompareMem)
	SB_PHP_FE(SBUtils, CompareBuffers, arginfo_SBUtils_CompareBuffers)
	SB_PHP_FE(SBUtils, CompareMD128, arginfo_SBUtils_CompareMD128)
	SB_PHP_FE(SBUtils, CompareMD160, arginfo_SBUtils_CompareMD160)
	SB_PHP_FE(SBUtils, CompareMD224, arginfo_SBUtils_CompareMD224)
	SB_PHP_FE(SBUtils, CompareMD256, arginfo_SBUtils_CompareMD256)
	SB_PHP_FE(SBUtils, CompareMD320, arginfo_SBUtils_CompareMD320)
	SB_PHP_FE(SBUtils, CompareMD384, arginfo_SBUtils_CompareMD384)
	SB_PHP_FE(SBUtils, CompareMD512, arginfo_SBUtils_CompareMD512)
	SB_PHP_FE(SBUtils, CompareHashes, arginfo_SBUtils_CompareHashes)
	SB_PHP_FE(SBUtils, FreeAndNil, arginfo_SBUtils_FreeAndNil)
	SB_PHP_FE(SBUtils, GetDigestSizeBits, arginfo_SBUtils_GetDigestSizeBits)
	SB_PHP_FE(SBUtils, EncodeDSASignature, arginfo_SBUtils_EncodeDSASignature)
	SB_PHP_FE(SBUtils, DecodeDSASignature, arginfo_SBUtils_DecodeDSASignature)
	SB_PHP_FE(SBUtils, CompareAnsiStr, arginfo_SBUtils_CompareAnsiStr)
	SB_PHP_FE(SBUtils, ChangeByteOrder, arginfo_SBUtils_ChangeByteOrder)
	SB_PHP_FE(SBUtils, BinaryToString, arginfo_SBUtils_BinaryToString)
	SB_PHP_FE(SBUtils, StringToBinary, arginfo_SBUtils_StringToBinary)
	SB_PHP_FE(SBUtils, CompareGUID, arginfo_SBUtils_CompareGUID)
	SB_PHP_FE(SBUtils, AnsiStringOfBytes, arginfo_SBUtils_AnsiStringOfBytes)
	SB_PHP_FE(SBUtils, ArrayStartsWith, arginfo_SBUtils_ArrayStartsWith)
	SB_PHP_FE(SBUtils, CompareArrays, arginfo_SBUtils_CompareArrays)
	SB_PHP_FE(SBUtils, CreateByteArrayConst, arginfo_SBUtils_CreateByteArrayConst)
	SB_PHP_FE(SBUtils, AnsiStringOfString, arginfo_SBUtils_AnsiStringOfString)
	SB_PHP_FE(SBUtils, StringOfAnsiString, arginfo_SBUtils_StringOfAnsiString)
	SB_PHP_FE(SBUtils, BytesOfAnsiString, arginfo_SBUtils_BytesOfAnsiString)
	SB_PHP_FE(SBUtils, GetByteArrayFromByte, arginfo_SBUtils_GetByteArrayFromByte)
	SB_PHP_FE(SBUtils, GetByteArrayFromBytes, arginfo_SBUtils_GetByteArrayFromBytes)
	SB_PHP_FE(SBUtils, GetByteArrayFromWordLE, arginfo_SBUtils_GetByteArrayFromWordLE)
	SB_PHP_FE(SBUtils, GetByteArrayFromWordBE, arginfo_SBUtils_GetByteArrayFromWordBE)
	SB_PHP_FE(SBUtils, GetByteArrayFromDWordLE, arginfo_SBUtils_GetByteArrayFromDWordLE)
	SB_PHP_FE(SBUtils, GetByteArrayFromDWordBE, arginfo_SBUtils_GetByteArrayFromDWordBE)
	SB_PHP_FE(SBUtils, GetByteArrayFromInt64LE, arginfo_SBUtils_GetByteArrayFromInt64LE)
	SB_PHP_FE(SBUtils, GetByteArrayFromInt64BE, arginfo_SBUtils_GetByteArrayFromInt64BE)
	SB_PHP_FE(SBUtils, GetWordLEFromByteArray, arginfo_SBUtils_GetWordLEFromByteArray)
	SB_PHP_FE(SBUtils, GetWordBEFromByteArray, arginfo_SBUtils_GetWordBEFromByteArray)
	SB_PHP_FE(SBUtils, GetDWordLEFromByteArray, arginfo_SBUtils_GetDWordLEFromByteArray)
	SB_PHP_FE(SBUtils, GetDWordBEFromByteArray, arginfo_SBUtils_GetDWordBEFromByteArray)
	SB_PHP_FE(SBUtils, GetInt64LEFromByteArray, arginfo_SBUtils_GetInt64LEFromByteArray)
	SB_PHP_FE(SBUtils, GetInt64BEFromByteArray, arginfo_SBUtils_GetInt64BEFromByteArray)
	SB_PHP_FE(SBUtils, SBBoolToStr, arginfo_SBUtils_SBBoolToStr)
	SB_PHP_FE(SBUtils, SBStrToBool, arginfo_SBUtils_SBStrToBool)
	SB_PHP_FE(SBUtils, WideStringOf, arginfo_SBUtils_WideStringOf)
	SB_PHP_FE(SBUtils, WideBytesOf, arginfo_SBUtils_WideBytesOf)
	SB_PHP_FE(SBUtils, SBConcatArrays, arginfo_SBUtils_SBConcatArrays)
	SB_PHP_FE(SBUtils, ArrayEndsWith, arginfo_SBUtils_ArrayEndsWith)
	SB_PHP_FE(SBUtils, DateStrToDate, arginfo_SBUtils_DateStrToDate)
	SB_PHP_FE(SBUtils, ParseRFC822TimeString, arginfo_SBUtils_ParseRFC822TimeString)
	SB_PHP_FE(SBUtils, RFC822TimeToDateTime, arginfo_SBUtils_RFC822TimeToDateTime)
	SB_PHP_FE(SBUtils, UTCTimeToDate, arginfo_SBUtils_UTCTimeToDate)
	SB_PHP_FE(SBUtils, UTCTimeToTime, arginfo_SBUtils_UTCTimeToTime)
	SB_PHP_FE(SBUtils, UTCTimeToDateTime, arginfo_SBUtils_UTCTimeToDateTime)
	SB_PHP_FE(SBUtils, GeneralizedTimeToDate, arginfo_SBUtils_GeneralizedTimeToDate)
	SB_PHP_FE(SBUtils, GeneralizedTimeToTime, arginfo_SBUtils_GeneralizedTimeToTime)
	SB_PHP_FE(SBUtils, GeneralizedTimeToDateTime, arginfo_SBUtils_GeneralizedTimeToDateTime)
	SB_PHP_FE(SBUtils, DateTimeToUTCTime, arginfo_SBUtils_DateTimeToUTCTime)
	SB_PHP_FE(SBUtils, DateTimeToGeneralizedTime, arginfo_SBUtils_DateTimeToGeneralizedTime)
	SB_PHP_FE(SBUtils, UniversalDateTimeToRFC822DateTimeString, arginfo_SBUtils_UniversalDateTimeToRFC822DateTimeString)
	SB_PHP_FE(SBUtils, RFC822TimeStringToUniversalTime, arginfo_SBUtils_RFC822TimeStringToUniversalTime)
	SB_PHP_FE(SBUtils, LocalDateTimeToRFC822DateTimeString, arginfo_SBUtils_LocalDateTimeToRFC822DateTimeString)
	SB_PHP_FE(SBUtils, SystemDateTimeToRFC822DateTimeString, arginfo_SBUtils_SystemDateTimeToRFC822DateTimeString)
#ifndef SB_WINDOWS
	SB_PHP_FE(SBUtils, FileTimeToUnixTime, arginfo_SBUtils_FileTimeToUnixTime)
	SB_PHP_FE(SBUtils, UnixTimeToFileTime, arginfo_SBUtils_UnixTimeToFileTime)
#endif
	SB_PHP_FE(SBUtils, FileTimeToDateTime, arginfo_SBUtils_FileTimeToDateTime)
	SB_PHP_FE(SBUtils, DateTimeToFileTime, arginfo_SBUtils_DateTimeToFileTime)
	SB_PHP_FE(SBUtils, UnixTimeToDateTime, arginfo_SBUtils_UnixTimeToDateTime)
	SB_PHP_FE(SBUtils, DateTimeToUnixTime, arginfo_SBUtils_DateTimeToUnixTime)
	SB_PHP_FE(SBUtils, ConstLength, arginfo_SBUtils_ConstLength)
	SB_PHP_FE(SBUtils, TickDiff, arginfo_SBUtils_TickDiff)
	SB_PHP_FE(SBUtils, GenerateGUID, arginfo_SBUtils_GenerateGUID)
	SB_PHP_FE(SBUtils, IsTextualOID, arginfo_SBUtils_IsTextualOID)
	SB_PHP_FE(SBUtils, IsWindowsOS, arginfo_SBUtils_IsWindowsOS)
	SB_PHP_FE(SBUtils, WaitFor, arginfo_SBUtils_WaitFor)
	SB_PHP_FE(SBUtils, LocalTimeToUTCTime, arginfo_SBUtils_LocalTimeToUTCTime)
	SB_PHP_FE(SBUtils, UTCTimeToLocalTime, arginfo_SBUtils_UTCTimeToLocalTime)
	SB_PHP_FE(SBUtils, UTCNow, arginfo_SBUtils_UTCNow)
	SB_PHP_FE(SBUtils, RegisterGlobalObject, arginfo_SBUtils_RegisterGlobalObject)
	SB_PHP_FE(SBUtils, UnregisterGlobalObject, arginfo_SBUtils_UnregisterGlobalObject)
	SB_PHP_FE(SBUtils, CleanupRegisteredGlobalObjects, arginfo_SBUtils_CleanupRegisteredGlobalObjects)
	SB_PHP_FE(SBUtils, AcquireGlobalLock, arginfo_SBUtils_AcquireGlobalLock)
	SB_PHP_FE(SBUtils, ReleaseGlobalLock, arginfo_SBUtils_ReleaseGlobalLock)
	SB_PHP_FE(SBUtils, HexDump, arginfo_SBUtils_HexDump)
	SB_PHP_FE(SBUtils, SBSameDateTime, arginfo_SBUtils_SBSameDateTime)
	SB_PHP_FE(SBUtils, SBSameDate, arginfo_SBUtils_SBSameDate)
	SB_PHP_FE(SBUtils, SBSameTime, arginfo_SBUtils_SBSameTime)
	SB_PHP_FE(SBUtils, SBEncodeDateTime, arginfo_SBUtils_SBEncodeDateTime)
	SB_PHP_FE(SBUtils, GetUTCOffsetDateTime, arginfo_SBUtils_GetUTCOffsetDateTime)
	SB_PHP_FE(SBUtils, CompareContent, arginfo_SBUtils_CompareContent)
	SB_PHP_FE(SBUtils, DateTimeToISO8601Time, arginfo_SBUtils_DateTimeToISO8601Time)
	SB_PHP_FE(SBUtils, ISO8601TimeToDateTime, arginfo_SBUtils_ISO8601TimeToDateTime)
	SB_PHP_FE(SBUtils, DateTimeToRFC3339, arginfo_SBUtils_DateTimeToRFC3339)
	SB_PHP_FE(SBUtils, SetLicenseKey, arginfo_SBUtils_SetLicenseKey)
	SB_PHP_FE(SBUtils, AppendSlash, arginfo_SBUtils_AppendSlash)
	SB_PHP_FE(SBUtils, EnsureDirectoryExists, arginfo_SBUtils_EnsureDirectoryExists)
	SB_PHP_FE(SBUtils, DirectoryExists, arginfo_SBUtils_DirectoryExists)
#ifndef SB_WINDOWS
	SB_PHP_FE(SBUtils, GetCurrentThreadID, arginfo_SBUtils_GetCurrentThreadID)
#endif
	SB_PHP_FE(SBUtils, SetDefaultExceptionHandler, arginfo_SBUtils_SetDefaultExceptionHandler)
	SB_PHP_FE(SBUtils, GetDefaultExceptionHandler, arginfo_SBUtils_GetDefaultExceptionHandler)
	SB_PHP_FE(SBUtils, SetDefaultGlobalLogger, arginfo_SBUtils_SetDefaultGlobalLogger)
	SB_PHP_FE(SBUtils, GetDefaultGlobalLogger, arginfo_SBUtils_GetDefaultGlobalLogger)
	SB_PHP_FE(SBUtils, RecordEntryInGlobalLog, arginfo_SBUtils_RecordEntryInGlobalLog)

	// SBStrUtils unit functions
	SB_PHP_FE(SBStrUtils, StringEndsWith, arginfo_SBStrUtils_StringEndsWith)
	SB_PHP_FE(SBStrUtils, StringEquals, arginfo_SBStrUtils_StringEquals)
	SB_PHP_FE(SBStrUtils, StringIndexOf, arginfo_SBStrUtils_StringIndexOf)
	SB_PHP_FE(SBStrUtils, StringIndexOfU, arginfo_SBStrUtils_StringIndexOfU)
	SB_PHP_FE(SBStrUtils, StringInsert, arginfo_SBStrUtils_StringInsert)
	SB_PHP_FE(SBStrUtils, StringIsEmpty, arginfo_SBStrUtils_StringIsEmpty)
	SB_PHP_FE(SBStrUtils, StringLastIndexOf, arginfo_SBStrUtils_StringLastIndexOf)
	SB_PHP_FE(SBStrUtils, StringRemove, arginfo_SBStrUtils_StringRemove)
	SB_PHP_FE(SBStrUtils, WideStringRemove, arginfo_SBStrUtils_WideStringRemove)
	SB_PHP_FE(SBStrUtils, AnsiStringRemove, arginfo_SBStrUtils_AnsiStringRemove)
	SB_PHP_FE(SBStrUtils, StringToLower, arginfo_SBStrUtils_StringToLower)
	SB_PHP_FE(SBStrUtils, StringToLowerInvariant, arginfo_SBStrUtils_StringToLowerInvariant)
	SB_PHP_FE(SBStrUtils, StringStartsWith, arginfo_SBStrUtils_StringStartsWith)
	SB_PHP_FE(SBStrUtils, StringSubstring, arginfo_SBStrUtils_StringSubstring)
	SB_PHP_FE(SBStrUtils, StringCopy, arginfo_SBStrUtils_StringCopy)
	SB_PHP_FE(SBStrUtils, StringTrim, arginfo_SBStrUtils_StringTrim)
	SB_PHP_FE(SBStrUtils, StringTrimEnd, arginfo_SBStrUtils_StringTrimEnd)
	SB_PHP_FE(SBStrUtils, StringTrimStart, arginfo_SBStrUtils_StringTrimStart)
	SB_PHP_FE(SBStrUtils, StringToUpper, arginfo_SBStrUtils_StringToUpper)
	SB_PHP_FE(SBStrUtils, StringToUpperInvariant, arginfo_SBStrUtils_StringToUpperInvariant)
	SB_PHP_FE(SBStrUtils, StringSplit, arginfo_SBStrUtils_StringSplit)
	SB_PHP_FE(SBStrUtils, StringSplitPV, arginfo_SBStrUtils_StringSplitPV)
	SB_PHP_FE(SBStrUtils, StringPadLeft, arginfo_SBStrUtils_StringPadLeft)
	SB_PHP_FE(SBStrUtils, StringPadRight, arginfo_SBStrUtils_StringPadRight)
	SB_PHP_FE(SBStrUtils, StrToDefEncoding, arginfo_SBStrUtils_StrToDefEncoding)
	SB_PHP_FE(SBStrUtils, DefEncodingToStr, arginfo_SBStrUtils_DefEncodingToStr)
	SB_PHP_FE(SBStrUtils, StrToStdEncoding, arginfo_SBStrUtils_StrToStdEncoding)
	SB_PHP_FE(SBStrUtils, StdEncodingToStr, arginfo_SBStrUtils_StdEncodingToStr)
	SB_PHP_FE(SBStrUtils, SBExtractFilePath, arginfo_SBStrUtils_SBExtractFilePath)
	SB_PHP_FE(SBStrUtils, SBExtractFileName, arginfo_SBStrUtils_SBExtractFileName)
	SB_PHP_FE(SBStrUtils, SBExtractFileExt, arginfo_SBStrUtils_SBExtractFileExt)
	SB_PHP_FE(SBStrUtils, ReplaceExt, arginfo_SBStrUtils_ReplaceExt)
	SB_PHP_FE(SBStrUtils, FilenameMatchesMask, arginfo_SBStrUtils_FilenameMatchesMask)
	SB_PHP_FE(SBStrUtils, DomainNameMatchesCertSN, arginfo_SBStrUtils_DomainNameMatchesCertSN)
	SB_PHP_FE(SBStrUtils, CountFoldersInPath, arginfo_SBStrUtils_CountFoldersInPath)
	SB_PHP_FE(SBStrUtils, ParseURL, arginfo_SBStrUtils_ParseURL)
	SB_PHP_FE(SBStrUtils, ComposeURL, arginfo_SBStrUtils_ComposeURL)
	SB_PHP_FE(SBStrUtils, SBRightPos, arginfo_SBStrUtils_SBRightPos)
	SB_PHP_FE(SBStrUtils, SBPos, arginfo_SBStrUtils_SBPos)
	SB_PHP_FE(SBStrUtils, SBCopy, arginfo_SBStrUtils_SBCopy)
	SB_PHP_FE(SBStrUtils, SBConcatAnsiStrings, arginfo_SBStrUtils_SBConcatAnsiStrings)
	SB_PHP_FE(SBStrUtils, OIDToStr, arginfo_SBStrUtils_OIDToStr)
	SB_PHP_FE(SBStrUtils, StrToOID, arginfo_SBStrUtils_StrToOID)
	SB_PHP_FE(SBStrUtils, StrToUTF8, arginfo_SBStrUtils_StrToUTF8)
	SB_PHP_FE(SBStrUtils, UTF8ToStr, arginfo_SBStrUtils_UTF8ToStr)
	SB_PHP_FE(SBStrUtils, StrToWideStr, arginfo_SBStrUtils_StrToWideStr)
	SB_PHP_FE(SBStrUtils, WideStrToStr, arginfo_SBStrUtils_WideStrToStr)
	SB_PHP_FE(SBStrUtils, EncodeString, arginfo_SBStrUtils_EncodeString)
	SB_PHP_FE(SBStrUtils, DecodeString, arginfo_SBStrUtils_DecodeString)
	SB_PHP_FE(SBStrUtils, UnicodeChangeEndianness, arginfo_SBStrUtils_UnicodeChangeEndianness)
	SB_PHP_FE(SBStrUtils, WideStrToUTF8, arginfo_SBStrUtils_WideStrToUTF8)
	SB_PHP_FE(SBStrUtils, UTF8ToWideStr, arginfo_SBStrUtils_UTF8ToWideStr)
	SB_PHP_FE(SBStrUtils, ConvertUTF16toUTF8, arginfo_SBStrUtils_ConvertUTF16toUTF8)
	SB_PHP_FE(SBStrUtils, isLegalUTF8, arginfo_SBStrUtils_isLegalUTF8)
	SB_PHP_FE(SBStrUtils, ConvertUTF8toUTF16, arginfo_SBStrUtils_ConvertUTF8toUTF16)
	SB_PHP_FE(SBStrUtils, ConvertFromUTF8String, arginfo_SBStrUtils_ConvertFromUTF8String)
	SB_PHP_FE(SBStrUtils, ConvertToUTF8String, arginfo_SBStrUtils_ConvertToUTF8String)
	SB_PHP_FE(SBStrUtils, ConvertFromUTF32String, arginfo_SBStrUtils_ConvertFromUTF32String)
	SB_PHP_FE(SBStrUtils, SetGlobalStringConverter, arginfo_SBStrUtils_SetGlobalStringConverter)
	SB_PHP_FE(SBStrUtils, SetDefaultCharset, arginfo_SBStrUtils_SetDefaultCharset)
	SB_PHP_FE(SBStrUtils, StrMixToInt64, arginfo_SBStrUtils_StrMixToInt64)
	SB_PHP_FE(SBStrUtils, SBTrim, arginfo_SBStrUtils_SBTrim)
	SB_PHP_FE(SBStrUtils, SBUppercase, arginfo_SBStrUtils_SBUppercase)
	SB_PHP_FE(SBStrUtils, StringReplace, arginfo_SBStrUtils_StringReplace)
	SB_PHP_FE(SBStrUtils, PrefixString, arginfo_SBStrUtils_PrefixString)
	SB_PHP_FE(SBStrUtils, SuffixString, arginfo_SBStrUtils_SuffixString)
	SB_PHP_FE(SBStrUtils, PathFirstComponent, arginfo_SBStrUtils_PathFirstComponent)
	SB_PHP_FE(SBStrUtils, PathLastComponent, arginfo_SBStrUtils_PathLastComponent)
	SB_PHP_FE(SBStrUtils, PathCutFirstComponent, arginfo_SBStrUtils_PathCutFirstComponent)
	SB_PHP_FE(SBStrUtils, PathCutLastComponent, arginfo_SBStrUtils_PathCutLastComponent)
	SB_PHP_FE(SBStrUtils, PathIsDirectory, arginfo_SBStrUtils_PathIsDirectory)
	SB_PHP_FE(SBStrUtils, PathTrim, arginfo_SBStrUtils_PathTrim)
	SB_PHP_FE(SBStrUtils, PathConcatenate, arginfo_SBStrUtils_PathConcatenate)
	SB_PHP_FE(SBStrUtils, PathNormalizeSlashes, arginfo_SBStrUtils_PathNormalizeSlashes)
	SB_PHP_FE(SBStrUtils, PathReverseSlashes, arginfo_SBStrUtils_PathReverseSlashes)
	SB_PHP_FE(SBStrUtils, PathMatchesMask, arginfo_SBStrUtils_PathMatchesMask)
	SB_PHP_FE(SBStrUtils, IsFileMask, arginfo_SBStrUtils_IsFileMask)
	SB_PHP_FE(SBStrUtils, ExtractPathFromMask, arginfo_SBStrUtils_ExtractPathFromMask)
	SB_PHP_FE(SBStrUtils, SftpNormalizePath, arginfo_SBStrUtils_SftpNormalizePath)
	SB_PHP_FE(SBStrUtils, ZipPathFirstComponent, arginfo_SBStrUtils_ZipPathFirstComponent)
	SB_PHP_FE(SBStrUtils, ZipPathLastComponent, arginfo_SBStrUtils_ZipPathLastComponent)
	SB_PHP_FE(SBStrUtils, ZipPathCutFirstComponent, arginfo_SBStrUtils_ZipPathCutFirstComponent)
	SB_PHP_FE(SBStrUtils, ZipPathCutLastComponent, arginfo_SBStrUtils_ZipPathCutLastComponent)
	SB_PHP_FE(SBStrUtils, ZipPathIsDirectory, arginfo_SBStrUtils_ZipPathIsDirectory)
	SB_PHP_FE(SBStrUtils, ZipPathTrim, arginfo_SBStrUtils_ZipPathTrim)
	SB_PHP_FE(SBStrUtils, ZipPathConcatenate, arginfo_SBStrUtils_ZipPathConcatenate)
	SB_PHP_FE(SBStrUtils, ZipPathNormalizeSlashes, arginfo_SBStrUtils_ZipPathNormalizeSlashes)
	SB_PHP_FE(SBStrUtils, ZipPathReverseSlashes, arginfo_SBStrUtils_ZipPathReverseSlashes)
	SB_PHP_FE(SBStrUtils, ZipPathMatchesMask, arginfo_SBStrUtils_ZipPathMatchesMask)
	SB_PHP_FE(SBStrUtils, ZipIsFileMask, arginfo_SBStrUtils_ZipIsFileMask)
	SB_PHP_FE(SBStrUtils, ZipExtractPathFromMask, arginfo_SBStrUtils_ZipExtractPathFromMask)
	SB_PHP_FE(SBStrUtils, PosExSafe, arginfo_SBStrUtils_PosExSafe)
	SB_PHP_FE(SBStrUtils, PosLast, arginfo_SBStrUtils_PosLast)
	SB_PHP_FE(SBStrUtils, WidePosEx, arginfo_SBStrUtils_WidePosEx)
	SB_PHP_FE(SBStrUtils, WidePosLast, arginfo_SBStrUtils_WidePosLast)
	SB_PHP_FE(SBStrUtils, WideStringToByteString, arginfo_SBStrUtils_WideStringToByteString)
	SB_PHP_FE(SBStrUtils, AnsiStringToByteWideString, arginfo_SBStrUtils_AnsiStringToByteWideString)
	SB_PHP_FE(SBStrUtils, IntToStrPadLeft, arginfo_SBStrUtils_IntToStrPadLeft)
	SB_PHP_FE(SBStrUtils, GetWideBytesOf, arginfo_SBStrUtils_GetWideBytesOf)
	SB_PHP_FE(SBStrUtils, GetStringOf, arginfo_SBStrUtils_GetStringOf)
	SB_PHP_FE(SBStrUtils, GetStringOfEx, arginfo_SBStrUtils_GetStringOfEx)
	SB_PHP_FE(SBStrUtils, GetWideStringOf, arginfo_SBStrUtils_GetWideStringOf)
	SB_PHP_FE(SBStrUtils, TrimEx, arginfo_SBStrUtils_TrimEx)
	SB_PHP_FE(SBStrUtils, TrimSemicolon, arginfo_SBStrUtils_TrimSemicolon)
	SB_PHP_FE(SBStrUtils, ExtractWideFileName, arginfo_SBStrUtils_ExtractWideFileName)
	SB_PHP_FE(SBStrUtils, ExtractFileExtension, arginfo_SBStrUtils_ExtractFileExtension)
	SB_PHP_FE(SBStrUtils, ExtractWideFileExtension, arginfo_SBStrUtils_ExtractWideFileExtension)
	SB_PHP_FE(SBStrUtils, WideTrimRight, arginfo_SBStrUtils_WideTrimRight)
	SB_PHP_FE(SBStrUtils, DecodeDateTime, arginfo_SBStrUtils_DecodeDateTime)
	SB_PHP_FE(SBStrUtils, SBDecStr2ToIntDef, arginfo_SBStrUtils_SBDecStr2ToIntDef)
	SB_PHP_FE(SBStrUtils, SBDecStr3ToIntDef, arginfo_SBStrUtils_SBDecStr3ToIntDef)
	SB_PHP_FE(SBStrUtils, SBDecStr4ToIntDef, arginfo_SBStrUtils_SBDecStr4ToIntDef)
	SB_PHP_FE(SBStrUtils, SBLength, arginfo_SBStrUtils_SBLength)
	SB_PHP_FE(SBStrUtils, SBStringZToString, arginfo_SBStrUtils_SBStringZToString)

	// SBStreams unit functions
	SB_PHP_FE(SBStreams, CopyStream, arginfo_SBStreams_CopyStream)
	SB_PHP_FE(SBStreams, StreamPosition, arginfo_SBStreams_StreamPosition)
	SB_PHP_FE(SBStreams, StreamSize, arginfo_SBStreams_StreamSize)
	SB_PHP_FE(SBStreams, SetStreamPosition, arginfo_SBStreams_SetStreamPosition)
	SB_PHP_FE(SBStreams, StreamSetPosition, arginfo_SBStreams_StreamSetPosition)
	SB_PHP_FE(SBStreams, StreamSkip, arginfo_SBStreams_StreamSkip)
	SB_PHP_FE(SBStreams, StreamRewind, arginfo_SBStreams_StreamRewind)
	SB_PHP_FE(SBStreams, StreamRead, arginfo_SBStreams_StreamRead)
	SB_PHP_FE(SBStreams, StreamReadAll, arginfo_SBStreams_StreamReadAll)
	SB_PHP_FE(SBStreams, StreamReadByte, arginfo_SBStreams_StreamReadByte)
	SB_PHP_FE(SBStreams, StreamWrite, arginfo_SBStreams_StreamWrite)
	SB_PHP_FE(SBStreams, StreamWriteLn, arginfo_SBStreams_StreamWriteLn)
	SB_PHP_FE(SBStreams, StreamClear, arginfo_SBStreams_StreamClear)

	// SBEncoding unit functions
	SB_PHP_FE(SBEncoding, B64EstimateEncodedSize, arginfo_SBEncoding_B64EstimateEncodedSize)
	SB_PHP_FE(SBEncoding, B64InitializeEncoding, arginfo_SBEncoding_B64InitializeEncoding)
	SB_PHP_FE(SBEncoding, B64InitializeDecoding, arginfo_SBEncoding_B64InitializeDecoding)
	SB_PHP_FE(SBEncoding, B64Encode, arginfo_SBEncoding_B64Encode)
	SB_PHP_FE(SBEncoding, B64Decode, arginfo_SBEncoding_B64Decode)
	SB_PHP_FE(SBEncoding, B64FinalizeEncoding, arginfo_SBEncoding_B64FinalizeEncoding)
	SB_PHP_FE(SBEncoding, B64FinalizeDecoding, arginfo_SBEncoding_B64FinalizeDecoding)
	SB_PHP_FE(SBEncoding, Base64UnicodeDecode, arginfo_SBEncoding_Base64UnicodeDecode)
	SB_PHP_FE(SBEncoding, Base64Decode, arginfo_SBEncoding_Base64Decode)
	SB_PHP_FE(SBEncoding, Base64Encode, arginfo_SBEncoding_Base64Encode)
	SB_PHP_FE(SBEncoding, Base64EncodeString, arginfo_SBEncoding_Base64EncodeString)
	SB_PHP_FE(SBEncoding, Base64DecodeString, arginfo_SBEncoding_Base64DecodeString)
	SB_PHP_FE(SBEncoding, Base64EncodeArray, arginfo_SBEncoding_Base64EncodeArray)
	SB_PHP_FE(SBEncoding, Base64DecodeArray, arginfo_SBEncoding_Base64DecodeArray)
	SB_PHP_FE(SBEncoding, Base64EncodeBinary, arginfo_SBEncoding_Base64EncodeBinary)
	SB_PHP_FE(SBEncoding, Base64DecodeBinary, arginfo_SBEncoding_Base64DecodeBinary)
	SB_PHP_FE(SBEncoding, Base64ToBase64Url, arginfo_SBEncoding_Base64ToBase64Url)
	SB_PHP_FE(SBEncoding, Base64UrlToBase64, arginfo_SBEncoding_Base64UrlToBase64)
	SB_PHP_FE(SBEncoding, B32EstimateEncodedSize, arginfo_SBEncoding_B32EstimateEncodedSize)
	SB_PHP_FE(SBEncoding, B32InitializeEncoding, arginfo_SBEncoding_B32InitializeEncoding)
	SB_PHP_FE(SBEncoding, B32Encode, arginfo_SBEncoding_B32Encode)
	SB_PHP_FE(SBEncoding, B32FinalizeEncoding, arginfo_SBEncoding_B32FinalizeEncoding)
	SB_PHP_FE(SBEncoding, Base32Encode, arginfo_SBEncoding_Base32Encode)
	SB_PHP_FE(SBEncoding, Base32EncodeBuffer, arginfo_SBEncoding_Base32EncodeBuffer)
	SB_PHP_FE(SBEncoding, Base32EncodeString, arginfo_SBEncoding_Base32EncodeString)
	SB_PHP_FE(SBEncoding, B32EstimateDecodedSize, arginfo_SBEncoding_B32EstimateDecodedSize)
	SB_PHP_FE(SBEncoding, B32InitializeDecoding, arginfo_SBEncoding_B32InitializeDecoding)
	SB_PHP_FE(SBEncoding, B32Decode, arginfo_SBEncoding_B32Decode)
	SB_PHP_FE(SBEncoding, Base32Decode, arginfo_SBEncoding_Base32Decode)
	SB_PHP_FE(SBEncoding, B32FinalizeDecoding, arginfo_SBEncoding_B32FinalizeDecoding)
	SB_PHP_FE(SBEncoding, Base32DecodeBuffer, arginfo_SBEncoding_Base32DecodeBuffer)
	SB_PHP_FE(SBEncoding, Base32DecodeString, arginfo_SBEncoding_Base32DecodeString)
	SB_PHP_FE(SBEncoding, Base32Extract, arginfo_SBEncoding_Base32Extract)
	SB_PHP_FE(SBEncoding, URLEncode, arginfo_SBEncoding_URLEncode)
	SB_PHP_FE(SBEncoding, URLDecode, arginfo_SBEncoding_URLDecode)
	SB_PHP_FE(SBEncoding, Base16DecodeString, arginfo_SBEncoding_Base16DecodeString)

	// SBCRC unit functions
	SB_PHP_FE(SBCRC, CRC32, arginfo_SBCRC_CRC32)

	// SBSocket unit functions
	SB_PHP_FE(SBSocket, AddressToString, arginfo_SBSocket_AddressToString)
	SB_PHP_FE(SBSocket, StringToAddress, arginfo_SBSocket_StringToAddress)
	SB_PHP_FE(SBSocket, IsIPv6Address, arginfo_SBSocket_IsIPv6Address)

	// SBCryptoProvUtils unit functions
	SB_PHP_FE(SBCryptoProvUtils, CryptoProvGetBoolParam, arginfo_SBCryptoProvUtils_CryptoProvGetBoolParam)
	SB_PHP_FE(SBCryptoProvUtils, GetIntegerPropFromBuffer, arginfo_SBCryptoProvUtils_GetIntegerPropFromBuffer)
	SB_PHP_FE(SBCryptoProvUtils, GetInt64PropFromBuffer, arginfo_SBCryptoProvUtils_GetInt64PropFromBuffer)
	SB_PHP_FE(SBCryptoProvUtils, GetInt64PropFromString, arginfo_SBCryptoProvUtils_GetInt64PropFromString)
	SB_PHP_FE(SBCryptoProvUtils, GetBufferFromInteger, arginfo_SBCryptoProvUtils_GetBufferFromInteger)
	SB_PHP_FE(SBCryptoProvUtils, GetBufferFromInt64, arginfo_SBCryptoProvUtils_GetBufferFromInt64)
	SB_PHP_FE(SBCryptoProvUtils, GetStringFromInt64, arginfo_SBCryptoProvUtils_GetStringFromInt64)
	SB_PHP_FE(SBCryptoProvUtils, GetBoolFromBuffer, arginfo_SBCryptoProvUtils_GetBoolFromBuffer)
	SB_PHP_FE(SBCryptoProvUtils, GetBufferFromBool, arginfo_SBCryptoProvUtils_GetBufferFromBool)
	SB_PHP_FE(SBCryptoProvUtils, GetPointerFromBuffer, arginfo_SBCryptoProvUtils_GetPointerFromBuffer)
	SB_PHP_FE(SBCryptoProvUtils, GetBufferFromPointer, arginfo_SBCryptoProvUtils_GetBufferFromPointer)
	SB_PHP_FE(SBCryptoProvUtils, ExtractSymmetricCipherParams, arginfo_SBCryptoProvUtils_ExtractSymmetricCipherParams)
	SB_PHP_FE(SBCryptoProvUtils, SerializeParams, arginfo_SBCryptoProvUtils_SerializeParams)
	SB_PHP_FE(SBCryptoProvUtils, UnserializeParams, arginfo_SBCryptoProvUtils_UnserializeParams)
	SB_PHP_FE(SBCryptoProvUtils, IsKeyDrivenOperation, arginfo_SBCryptoProvUtils_IsKeyDrivenOperation)
	SB_PHP_FE(SBCryptoProvUtils, IsSecretKeyOperation, arginfo_SBCryptoProvUtils_IsSecretKeyOperation)
	SB_PHP_FE(SBCryptoProvUtils, IsAlgorithmIndependentOperation, arginfo_SBCryptoProvUtils_IsAlgorithmIndependentOperation)
	SB_PHP_FE(SBCryptoProvUtils, GetBoolParameter, arginfo_SBCryptoProvUtils_GetBoolParameter)
	SB_PHP_FE(SBCryptoProvUtils, GetBufferTypeParameter, arginfo_SBCryptoProvUtils_GetBufferTypeParameter)

	// SBCryptoProvDefault unit functions
	SB_PHP_FE(SBCryptoProvDefault, DefaultCryptoProvider, arginfo_SBCryptoProvDefault_DefaultCryptoProvider)
	SB_PHP_FE(SBCryptoProvDefault, SetDefaultCryptoProviderType, arginfo_SBCryptoProvDefault_SetDefaultCryptoProviderType)

	// SBCryptoProvBuiltIn unit functions
	SB_PHP_FE(SBCryptoProvBuiltIn, BuiltInCryptoProvider, arginfo_SBCryptoProvBuiltIn_BuiltInCryptoProvider)
	SB_PHP_FE(SBCryptoProvBuiltIn, TestFileKeyContainer, arginfo_SBCryptoProvBuiltIn_TestFileKeyContainer)
	SB_PHP_FE(SBCryptoProvBuiltIn, CompareContainers, arginfo_SBCryptoProvBuiltIn_CompareContainers)

#ifdef SB_WINDOWS
	// SBCryptoProvWin32 unit functions
	SB_PHP_FE(SBCryptoProvWin32, Win32CryptoProvider, arginfo_SBCryptoProvWin32_Win32CryptoProvider)
#endif

	// SBCryptoProvManager unit functions
	SB_PHP_FE(SBCryptoProvManager, DefaultCryptoProviderManager, arginfo_SBCryptoProvManager_DefaultCryptoProviderManager)
#ifdef SB_WINDOWS
	SB_PHP_FE(SBCryptoProvManager, FIPSCompliantCryptoProviderManager, arginfo_SBCryptoProvManager_FIPSCompliantCryptoProviderManager)
#endif

	// SBX509 unit functions
	SB_PHP_FE(SBX509, PVKHeaderToByteArray, arginfo_SBX509_PVKHeaderToByteArray)
	SB_PHP_FE(SBX509, PVK_DeriveKey, arginfo_SBX509_PVK_DeriveKey)
	SB_PHP_FE(SBX509, RaiseX509Error, arginfo_SBX509_RaiseX509Error)
	SB_PHP_FE(SBX509, SerialNumberCorresponds, arginfo_SBX509_SerialNumberCorresponds)
	SB_PHP_FE(SBX509, GetOriginalSerialNumber, arginfo_SBX509_GetOriginalSerialNumber)
	SB_PHP_FE(SBX509, GetX509NegativeSerialWorkaround, arginfo_SBX509_GetX509NegativeSerialWorkaround)
	SB_PHP_FE(SBX509, SetX509NegativeSerialWorkaround, arginfo_SBX509_SetX509NegativeSerialWorkaround)

	// SBX509Ext unit functions
	SB_PHP_FE(SBX509Ext, OctetsToIPAddress, arginfo_SBX509Ext_OctetsToIPAddress)
	SB_PHP_FE(SBX509Ext, IPAddressToOctets, arginfo_SBX509Ext_IPAddressToOctets)

	// SBCRL unit functions
	SB_PHP_FE(SBCRL, CRLObjectFactory, arginfo_SBCRL_CRLObjectFactory)

	// SBCRLStorage unit functions
	SB_PHP_FE(SBCRLStorage, CRLManagerAddRef, arginfo_SBCRLStorage_CRLManagerAddRef)
	SB_PHP_FE(SBCRLStorage, CRLManagerRelease, arginfo_SBCRLStorage_CRLManagerRelease)

	// SBCertRetriever unit functions
	SB_PHP_FE(SBCertRetriever, CertificateRetrieverManagerAddRef, arginfo_SBCertRetriever_CertificateRetrieverManagerAddRef)
	SB_PHP_FE(SBCertRetriever, CertificateRetrieverManagerRelease, arginfo_SBCertRetriever_CertificateRetrieverManagerRelease)

	// SBCertValidator unit functions
	SB_PHP_FE(SBCertValidator, GetCertificateCache, arginfo_SBCertValidator_GetCertificateCache)

	// SBRDN unit functions
	SB_PHP_FE(SBRDN, FormatRDN, arginfo_SBRDN_FormatRDN)
	SB_PHP_FE(SBRDN, MapUnicodeString, arginfo_SBRDN_MapUnicodeString)
	SB_PHP_FE(SBRDN, InsignificantSpaceHandling, arginfo_SBRDN_InsignificantSpaceHandling)
	SB_PHP_FE(SBRDN, GetRDNStringValue, arginfo_SBRDN_GetRDNStringValue)
	SB_PHP_FE(SBRDN, GetNormalizedRDNStringValue, arginfo_SBRDN_GetNormalizedRDNStringValue)
	SB_PHP_FE(SBRDN, GetNormalizedRDNString, arginfo_SBRDN_GetNormalizedRDNString)
	SB_PHP_FE(SBRDN, CompareRDN, arginfo_SBRDN_CompareRDN)
	SB_PHP_FE(SBRDN, CompareRDNAsStrings, arginfo_SBRDN_CompareRDNAsStrings)
	SB_PHP_FE(SBRDN, NonstrictCompareRDN, arginfo_SBRDN_NonstrictCompareRDN)
	SB_PHP_FE(SBRDN, NonstrictCompareRDNAsStrings, arginfo_SBRDN_NonstrictCompareRDNAsStrings)
	SB_PHP_FE(SBRDN, GetIgnoreTagsWhenComparingRDNs, arginfo_SBRDN_GetIgnoreTagsWhenComparingRDNs)
	SB_PHP_FE(SBRDN, SetIgnoreTagsWhenComparingRDNs, arginfo_SBRDN_SetIgnoreTagsWhenComparingRDNs)

	// SBCustomCertStorage unit functions
	SB_PHP_FE(SBCustomCertStorage, IsIssuerCertificate, arginfo_SBCustomCertStorage_IsIssuerCertificate)

	// SBPKCS5 unit functions
	SB_PHP_FE(SBPKCS5, DeriveRouteOneOTP, arginfo_SBPKCS5_DeriveRouteOneOTP)

	// SBPKCS7 unit functions
	SB_PHP_FE(SBPKCS7, ProcessContentInfo, arginfo_SBPKCS7_ProcessContentInfo)
	SB_PHP_FE(SBPKCS7, SaveSignerInfo, arginfo_SBPKCS7_SaveSignerInfo)
	SB_PHP_FE(SBPKCS7, ProcessSignerInfo, arginfo_SBPKCS7_ProcessSignerInfo)
	SB_PHP_FE(SBPKCS7, RaisePKCS7Error, arginfo_SBPKCS7_RaisePKCS7Error)

	// SBPKCS7Utils unit functions
	SB_PHP_FE(SBPKCS7Utils, SaveAttributes, arginfo_SBPKCS7Utils_SaveAttributes)
	SB_PHP_FE(SBPKCS7Utils, ProcessAttributes, arginfo_SBPKCS7Utils_ProcessAttributes)
	SB_PHP_FE(SBPKCS7Utils, ProcessAlgorithmIdentifier, arginfo_SBPKCS7Utils_ProcessAlgorithmIdentifier)
	SB_PHP_FE(SBPKCS7Utils, SaveAlgorithmIdentifier, arginfo_SBPKCS7Utils_SaveAlgorithmIdentifier)

	// SBPKCS8 unit functions
	SB_PHP_FE(SBPKCS8, RaisePKCS8Error, arginfo_SBPKCS8_RaisePKCS8Error)

	// SBPKCS12 unit functions
	SB_PHP_FE(SBPKCS12, BufToInt, arginfo_SBPKCS12_BufToInt)
	SB_PHP_FE(SBPKCS12, IntToBuf, arginfo_SBPKCS12_IntToBuf)
	SB_PHP_FE(SBPKCS12, RaisePKCS12Error, arginfo_SBPKCS12_RaisePKCS12Error)

	// SBOCSPCommon unit functions
	SB_PHP_FE(SBOCSPCommon, ReasonFlagToEnum, arginfo_SBOCSPCommon_ReasonFlagToEnum)
	SB_PHP_FE(SBOCSPCommon, EnumToReasonFlag, arginfo_SBOCSPCommon_EnumToReasonFlag)
	SB_PHP_FE(SBOCSPCommon, ReadAsnInteger, arginfo_SBOCSPCommon_ReadAsnInteger)

	// SBOCSPClient unit functions
	SB_PHP_FE(SBOCSPClient, OCSPClientManagerAddRef, arginfo_SBOCSPClient_OCSPClientManagerAddRef)
	SB_PHP_FE(SBOCSPClient, OCSPClientManagerRelease, arginfo_SBOCSPClient_OCSPClientManagerRelease)
	SB_PHP_FE(SBOCSPClient, GetOCSPCertID, arginfo_SBOCSPClient_GetOCSPCertID)

	// SBPublicKeyCrypto unit functions
	SB_PHP_FE(SBPublicKeyCrypto, GetCheckKeyIntegrityBeforeUse, arginfo_SBPublicKeyCrypto_GetCheckKeyIntegrityBeforeUse)
	SB_PHP_FE(SBPublicKeyCrypto, SetCheckKeyIntegrityBeforeUse, arginfo_SBPublicKeyCrypto_SetCheckKeyIntegrityBeforeUse)

	// SBPKIAsync unit functions
	SB_PHP_FE(SBPKIAsync, GetGlobalAsyncCalculator, arginfo_SBPKIAsync_GetGlobalAsyncCalculator)

	// SBECCommon unit functions
	SB_PHP_FE(SBECCommon, GetCurveByOID, arginfo_SBECCommon_GetCurveByOID)
	SB_PHP_FE(SBECCommon, GetOIDByCurve, arginfo_SBECCommon_GetOIDByCurve)
	SB_PHP_FE(SBECCommon, IsPointCompressed, arginfo_SBECCommon_IsPointCompressed)
	SB_PHP_FE(SBECCommon, BufferToPoint, arginfo_SBECCommon_BufferToPoint)
	SB_PHP_FE(SBECCommon, PointToBuffer, arginfo_SBECCommon_PointToBuffer)
	SB_PHP_FE(SBECCommon, ValidateKey, arginfo_SBECCommon_ValidateKey)
	SB_PHP_FE(SBECCommon, HexStrToFieldElement, arginfo_SBECCommon_HexStrToFieldElement)
	SB_PHP_FE(SBECCommon, BufferToFieldElement, arginfo_SBECCommon_BufferToFieldElement)

	// SBGSSAPIBase unit functions
	SB_PHP_FE(SBGSSAPIBase, GSS_CALLING_ERROR, arginfo_SBGSSAPIBase_GSS_CALLING_ERROR)
	SB_PHP_FE(SBGSSAPIBase, GSS_ROUTINE_ERROR, arginfo_SBGSSAPIBase_GSS_ROUTINE_ERROR)
	SB_PHP_FE(SBGSSAPIBase, GSS_SUPPLEMENTARY_INFO, arginfo_SBGSSAPIBase_GSS_SUPPLEMENTARY_INFO)
	SB_PHP_FE(SBGSSAPIBase, GSS_ERROR, arginfo_SBGSSAPIBase_GSS_ERROR)
	SB_PHP_FE(SBGSSAPIBase, DecodeMechOID, arginfo_SBGSSAPIBase_DecodeMechOID)
	SB_PHP_FE(SBGSSAPIBase, EncodeMechOID, arginfo_SBGSSAPIBase_EncodeMechOID)

	// SBDNSSEC unit functions
	SB_PHP_FE(SBDNSSEC, CheckSystemNameServers, arginfo_SBDNSSEC_CheckSystemNameServers)

	// SBDNSSECUtils unit functions
	SB_PHP_FE(SBDNSSECUtils, ResourceTypeToCode, arginfo_SBDNSSECUtils_ResourceTypeToCode)
	SB_PHP_FE(SBDNSSECUtils, ResourceCodeToType, arginfo_SBDNSSECUtils_ResourceCodeToType)
	SB_PHP_FE(SBDNSSECUtils, IPv6ToString, arginfo_SBDNSSECUtils_IPv6ToString)
	SB_PHP_FE(SBDNSSECUtils, ReadDomainName, arginfo_SBDNSSECUtils_ReadDomainName)
	SB_PHP_FE(SBDNSSECUtils, WriteDomainName, arginfo_SBDNSSECUtils_WriteDomainName)
	SB_PHP_FE(SBDNSSECUtils, WriteIPv4Address, arginfo_SBDNSSECUtils_WriteIPv4Address)
	SB_PHP_FE(SBDNSSECUtils, WriteIPv6Address, arginfo_SBDNSSECUtils_WriteIPv6Address)
	SB_PHP_FE(SBDNSSECUtils, WriteString, arginfo_SBDNSSECUtils_WriteString)
	SB_PHP_FE(SBDNSSECUtils, ResponseCodeToRCode, arginfo_SBDNSSECUtils_ResponseCodeToRCode)
	SB_PHP_FE(SBDNSSECUtils, RCodeToResponseCode, arginfo_SBDNSSECUtils_RCodeToResponseCode)
	SB_PHP_FE(SBDNSSECUtils, OperationCodeToOpCode, arginfo_SBDNSSECUtils_OperationCodeToOpCode)
	SB_PHP_FE(SBDNSSECUtils, OpCodeToOperationCode, arginfo_SBDNSSECUtils_OpCodeToOperationCode)
	SB_PHP_FE(SBDNSSECUtils, CheckBufferBounds, arginfo_SBDNSSECUtils_CheckBufferBounds)
	SB_PHP_FE(SBDNSSECUtils, IsSubdomain, arginfo_SBDNSSECUtils_IsSubdomain)
	SB_PHP_FE(SBDNSSECUtils, LabelCount, arginfo_SBDNSSECUtils_LabelCount)
	SB_PHP_FE(SBDNSSECUtils, ExtractLabels, arginfo_SBDNSSECUtils_ExtractLabels)
	SB_PHP_FE(SBDNSSECUtils, CompareDomainNames, arginfo_SBDNSSECUtils_CompareDomainNames)

	// SBCustomFSAdapter unit functions
	SB_PHP_FE(SBCustomFSAdapter, RaiseVFSAdapterError, arginfo_SBCustomFSAdapter_RaiseVFSAdapterError)
	SB_PHP_FE(SBCustomFSAdapter, RaiseVFSAdapterErrorEx, arginfo_SBCustomFSAdapter_RaiseVFSAdapterErrorEx)

	// SBPunycode unit functions
	SB_PHP_FE(SBPunycode, PunycodeEncode, arginfo_SBPunycode_PunycodeEncode)
	SB_PHP_FE(SBPunycode, PunycodeDecode, arginfo_SBPunycode_PunycodeDecode)
	SB_PHP_FE(SBPunycode, ToASCII, arginfo_SBPunycode_ToASCII)
	SB_PHP_FE(SBPunycode, ToUnicode, arginfo_SBPunycode_ToUnicode)

	// SBHTTPAuth unit functions
	SB_PHP_FE(SBHTTPAuth, AuthInit, arginfo_SBHTTPAuth_AuthInit)
	SB_PHP_FE(SBHTTPAuth, AuthTerm, arginfo_SBHTTPAuth_AuthTerm)
	SB_PHP_FE(SBHTTPAuth, AuthConverse, arginfo_SBHTTPAuth_AuthConverse)
	SB_PHP_FE(SBHTTPAuth, AddAuthorizationHeader, arginfo_SBHTTPAuth_AddAuthorizationHeader)
	SB_PHP_FE(SBHTTPAuth, ValidateSecPacks, arginfo_SBHTTPAuth_ValidateSecPacks)
	SB_PHP_FE(SBHTTPAuth, InitAuthLib, arginfo_SBHTTPAuth_InitAuthLib)

	// SBSASL unit functions
	SB_PHP_FE(SBSASL, CreateSASLClient, arginfo_SBSASL_CreateSASLClient)

	// SBDC unit functions
	SB_PHP_FE(SBDC, DCBoolToStr, arginfo_SBDC_DCBoolToStr)
	SB_PHP_FE(SBDC, DCStrToBool, arginfo_SBDC_DCStrToBool)
	SB_PHP_FE(SBDC, DCBoolToByteArray, arginfo_SBDC_DCBoolToByteArray)
	SB_PHP_FE(SBDC, DCByteArrayToBool, arginfo_SBDC_DCByteArrayToBool)
	SB_PHP_FE(SBDC, DCSigMessageSort, arginfo_SBDC_DCSigMessageSort)

	// SBDCDef unit functions
	SB_PHP_FE(SBDCDef, DefaultDCRequestFactory, arginfo_SBDCDef_DefaultDCRequestFactory)

	// SBDCEnc unit functions
	SB_PHP_FE(SBDCEnc, SetDefaultDCEncoding, arginfo_SBDCEnc_SetDefaultDCEncoding)
	SB_PHP_FE(SBDCEnc, GetDefaultDCEncoding, arginfo_SBDCEnc_GetDefaultDCEncoding)

	// SBDCASN1Enc unit functions
	SB_PHP_FE(SBDCASN1Enc, DCASN1Encoding, arginfo_SBDCASN1Enc_DCASN1Encoding)

	// SBDCCanonEnc unit functions
	SB_PHP_FE(SBDCCanonEnc, DCCanonEncoding, arginfo_SBDCCanonEnc_DCCanonEncoding)

	// SBChSConv unit functions
	SB_PHP_FE(SBChSConv, EnumCharsets, arginfo_SBChSConv_EnumCharsets)
	SB_PHP_FE(SBChSConv, CreateCharset, arginfo_SBChSConv_CreateCharset)
	SB_PHP_FE(SBChSConv, CreateCharsetByDescription, arginfo_SBChSConv_CreateCharsetByDescription)
	SB_PHP_FE(SBChSConv, CreateSystemDefaultCharset, arginfo_SBChSConv_CreateSystemDefaultCharset)
	SB_PHP_FE(SBChSConv, GetSystemDefaultCharsetName, arginfo_SBChSConv_GetSystemDefaultCharsetName)
	SB_PHP_FE(SBChSConv, GetCharsetNameByAlias, arginfo_SBChSConv_GetCharsetNameByAlias)
	SB_PHP_FE(SBChSConv, ConvertCharset, arginfo_SBChSConv_ConvertCharset)
	SB_PHP_FE(SBChSConv, InitializeCharsetObjects, arginfo_SBChSConv_InitializeCharsetObjects)

	// SBChSConvBase unit functions
	SB_PHP_FE(SBChSConvBase, RegisterCharset, arginfo_SBChSConvBase_RegisterCharset)
	SB_PHP_FE(SBChSConvBase, UnregisterCharset, arginfo_SBChSConvBase_UnregisterCharset)
	SB_PHP_FE(SBChSConvBase, RegisterCharsetLibrary, arginfo_SBChSConvBase_RegisterCharsetLibrary)
	SB_PHP_FE(SBChSConvBase, AbstractError, arginfo_SBChSConvBase_AbstractError)
	SB_PHP_FE(SBChSConvBase, Initialize, arginfo_SBChSConvBase_Initialize)

	// SBChSUnicode unit functions
	SB_PHP_FE(SBChSUnicode, WideUpperCase, arginfo_SBChSUnicode_WideUpperCase)
	SB_PHP_FE(SBChSUnicode, WideTitleCase, arginfo_SBChSUnicode_WideTitleCase)
	SB_PHP_FE(SBChSUnicode, GetCharType, arginfo_SBChSUnicode_GetCharType)
	SB_PHP_FE(SBChSUnicode, WideLowerCase, arginfo_SBChSUnicode_WideLowerCase)
	SB_PHP_FE(SBChSUnicode, Normalize_NFD, arginfo_SBChSUnicode_Normalize_NFD)
	SB_PHP_FE(SBChSUnicode, Normalize_NFC, arginfo_SBChSUnicode_Normalize_NFC)
	SB_PHP_FE(SBChSUnicode, Normalize_NFKD, arginfo_SBChSUnicode_Normalize_NFKD)
	SB_PHP_FE(SBChSUnicode, Normalize_NFKC, arginfo_SBChSUnicode_Normalize_NFKC)
	SB_PHP_FE(SBChSUnicode, CheckProhibit, arginfo_SBChSUnicode_CheckProhibit)
	SB_PHP_FE(SBChSUnicode, CheckBidi, arginfo_SBChSUnicode_CheckBidi)
	SB_PHP_FE(SBChSUnicode, GetCharCode, arginfo_SBChSUnicode_GetCharCode)
	SB_PHP_FE(SBChSUnicode, GetCharValue, arginfo_SBChSUnicode_GetCharValue)

	// SBUnicode unit functions
	SB_PHP_FE(SBUnicode, CreateUnicodeStringConverter, arginfo_SBUnicode_CreateUnicodeStringConverter)

	// SBCryptoProvBuiltInEx unit functions
	SB_PHP_FE(SBCryptoProvBuiltInEx, BuiltInCryptoProviderEx, arginfo_SBCryptoProvBuiltInEx_BuiltInCryptoProviderEx)

	// SBDynStruct unit functions
	SB_PHP_FE(SBDynStruct, NullPtr, arginfo_SBDynStruct_NullPtr)
	SB_PHP_FE(SBDynStruct, GetArrayPtr, arginfo_SBDynStruct_GetArrayPtr)
	SB_PHP_FE(SBDynStruct, FreePointer, arginfo_SBDynStruct_FreePointer)

	// SBAttrCert unit functions
	SB_PHP_FE(SBAttrCert, ACWriteBitString, arginfo_SBAttrCert_ACWriteBitString)
	SB_PHP_FE(SBAttrCert, ACReadBitString, arginfo_SBAttrCert_ACReadBitString)

	// SBScrypt unit functions
	SB_PHP_FE(SBScrypt, scrypt, arginfo_SBScrypt_scrypt)

	// SBDataStorage unit functions
	SB_PHP_FE(SBDataStorage, DataStorageSecurityHandlersFactory, arginfo_SBDataStorage_DataStorageSecurityHandlersFactory)
	SB_PHP_FE(SBDataStorage, DataStorageEncodingHandlersFactory, arginfo_SBDataStorage_DataStorageEncodingHandlersFactory)

	// SBAWSDataStorage unit functions
	SB_PHP_FE(SBAWSDataStorage, GetNodeInnerXML, arginfo_SBAWSDataStorage_GetNodeInnerXML)

	// SBFileDataStorage unit functions
	SB_PHP_FE(SBFileDataStorage, ComposeETag, arginfo_SBFileDataStorage_ComposeETag)

	// SBWinAzureDataStorage unit functions
	SB_PHP_FE(SBWinAzureDataStorage, GetNodeText, arginfo_SBWinAzureDataStorage_GetNodeText)

	// SBDataStorageUtils unit functions
	SB_PHP_FE(SBDataStorageUtils, TryGetStreamSize, arginfo_SBDataStorageUtils_TryGetStreamSize)
	SB_PHP_FE(SBDataStorageUtils, PathAddExtension, arginfo_SBDataStorageUtils_PathAddExtension)

	// SBWebDAVClient unit functions
	SB_PHP_FE(SBWebDAVClient, AddSlash, arginfo_SBWebDAVClient_AddSlash)
	SB_PHP_FE(SBWebDAVClient, HTTPSuccess, arginfo_SBWebDAVClient_HTTPSuccess)
	SB_PHP_FE(SBWebDAVClient, Unauthorized, arginfo_SBWebDAVClient_Unauthorized)

	// SBWebDAVCommon unit functions
	SB_PHP_FE(SBWebDAVCommon, CalDAVTimeToDateTime, arginfo_SBWebDAVCommon_CalDAVTimeToDateTime)
	SB_PHP_FE(SBWebDAVCommon, DateTimeToCalDAV, arginfo_SBWebDAVCommon_DateTimeToCalDAV)
	SB_PHP_FE(SBWebDAVCommon, ISOTimeToDateTime, arginfo_SBWebDAVCommon_ISOTimeToDateTime)
	SB_PHP_FE(SBWebDAVCommon, DateTimeToISOTime, arginfo_SBWebDAVCommon_DateTimeToISOTime)
	SB_PHP_FE(SBWebDAVCommon, DepthToStr, arginfo_SBWebDAVCommon_DepthToStr)
	SB_PHP_FE(SBWebDAVCommon, StrToDepth, arginfo_SBWebDAVCommon_StrToDepth)
	SB_PHP_FE(SBWebDAVCommon, ScopeToStr, arginfo_SBWebDAVCommon_ScopeToStr)
	SB_PHP_FE(SBWebDAVCommon, StrToScope, arginfo_SBWebDAVCommon_StrToScope)
	SB_PHP_FE(SBWebDAVCommon, Substring, arginfo_SBWebDAVCommon_Substring)
	SB_PHP_FE(SBWebDAVCommon, URLComparePaths, arginfo_SBWebDAVCommon_URLComparePaths)
	SB_PHP_FE(SBWebDAVCommon, URLChild, arginfo_SBWebDAVCommon_URLChild)
	SB_PHP_FE(SBWebDAVCommon, URLExtractParent, arginfo_SBWebDAVCommon_URLExtractParent)
	SB_PHP_FE(SBWebDAVCommon, URLExtractExtension, arginfo_SBWebDAVCommon_URLExtractExtension)
	SB_PHP_FE(SBWebDAVCommon, URLExtractResourceName, arginfo_SBWebDAVCommon_URLExtractResourceName)
	SB_PHP_FE(SBWebDAVCommon, CollectionURL, arginfo_SBWebDAVCommon_CollectionURL)
	SB_PHP_FE(SBWebDAVCommon, URLExtractPath, arginfo_SBWebDAVCommon_URLExtractPath)
	SB_PHP_FE(SBWebDAVCommon, URLCalculateDestPath, arginfo_SBWebDAVCommon_URLCalculateDestPath)
	SB_PHP_FE(SBWebDAVCommon, URLAddPrefixSlash, arginfo_SBWebDAVCommon_URLAddPrefixSlash)
	SB_PHP_FE(SBWebDAVCommon, URLAddPostfixSlash, arginfo_SBWebDAVCommon_URLAddPostfixSlash)
	SB_PHP_FE(SBWebDAVCommon, URLRemoveSlash, arginfo_SBWebDAVCommon_URLRemoveSlash)
	SB_PHP_FE(SBWebDAVCommon, URLFixSlashes, arginfo_SBWebDAVCommon_URLFixSlashes)
	SB_PHP_FE(SBWebDAVCommon, URLEncodeEx, arginfo_SBWebDAVCommon_URLEncodeEx)
	SB_PHP_FE(SBWebDAVCommon, URLConcat, arginfo_SBWebDAVCommon_URLConcat)
	SB_PHP_FE(SBWebDAVCommon, CheckStatusCode, arginfo_SBWebDAVCommon_CheckStatusCode)
	SB_PHP_FE(SBWebDAVCommon, SingleChildElement, arginfo_SBWebDAVCommon_SingleChildElement)
	SB_PHP_FE(SBWebDAVCommon, MaxDateTime, arginfo_SBWebDAVCommon_MaxDateTime)
	SB_PHP_FE(SBWebDAVCommon, GenerateRandomStr, arginfo_SBWebDAVCommon_GenerateRandomStr)
	SB_PHP_FE(SBWebDAVCommon, StrToPrivilege, arginfo_SBWebDAVCommon_StrToPrivilege)
	SB_PHP_FE(SBWebDAVCommon, PrivilegeToStr, arginfo_SBWebDAVCommon_PrivilegeToStr)
	SB_PHP_FE(SBWebDAVCommon, PrivilegesArray, arginfo_SBWebDAVCommon_PrivilegesArray)

	// SBWebDAVServer unit functions
	SB_PHP_FE(SBWebDAVServer, FindLockInList, arginfo_SBWebDAVServer_FindLockInList)

	// SBDCXMLEnc unit functions
	SB_PHP_FE(SBDCXMLEnc, DCXMLEncoding, arginfo_SBDCXMLEnc_DCXMLEncoding)

	// SBFTPSCommon unit functions
	SB_PHP_FE(SBFTPSCommon, IsWhitespace, arginfo_SBFTPSCommon_IsWhitespace)
	SB_PHP_FE(SBFTPSCommon, DateTimeToFTPTimeVal, arginfo_SBFTPSCommon_DateTimeToFTPTimeVal)
	SB_PHP_FE(SBFTPSCommon, UnixPermissionsToStringRwx, arginfo_SBFTPSCommon_UnixPermissionsToStringRwx)
	SB_PHP_FE(SBFTPSCommon, UnixPermissionsToStringOct, arginfo_SBFTPSCommon_UnixPermissionsToStringOct)

	// SBHTTPSCommon unit functions
	SB_PHP_FE(SBHTTPSCommon, HTTPHeaderGetDelimiter, arginfo_SBHTTPSCommon_HTTPHeaderGetDelimiter)

	// SBHTTPOCSPClient unit functions
	SB_PHP_FE(SBHTTPOCSPClient, RegisterHTTPOCSPClientFactory, arginfo_SBHTTPOCSPClient_RegisterHTTPOCSPClientFactory)
	SB_PHP_FE(SBHTTPOCSPClient, UnregisterHTTPOCSPClientFactory, arginfo_SBHTTPOCSPClient_UnregisterHTTPOCSPClientFactory)

	// SBHTTPCertRetriever unit functions
	SB_PHP_FE(SBHTTPCertRetriever, RegisterHTTPCertificateRetrieverFactory, arginfo_SBHTTPCertRetriever_RegisterHTTPCertificateRetrieverFactory)
	SB_PHP_FE(SBHTTPCertRetriever, UnregisterHTTPCertificateRetrieverFactory, arginfo_SBHTTPCertRetriever_UnregisterHTTPCertificateRetrieverFactory)

	// SBHTTPCRL unit functions
	SB_PHP_FE(SBHTTPCRL, RegisterHTTPCRLRetrieverFactory, arginfo_SBHTTPCRL_RegisterHTTPCRLRetrieverFactory)
	SB_PHP_FE(SBHTTPCRL, UnregisterHTTPCRLRetrieverFactory, arginfo_SBHTTPCRL_UnregisterHTTPCRLRetrieverFactory)

	// SBHTTPSServer unit functions
	SB_PHP_FE(SBHTTPSServer, GetDefaultReasonPhrase, arginfo_SBHTTPSServer_GetDefaultReasonPhrase)

	// SBLDAPCertRetriever unit functions
	SB_PHP_FE(SBLDAPCertRetriever, RegisterLDAPCertificateRetrieverFactory, arginfo_SBLDAPCertRetriever_RegisterLDAPCertificateRetrieverFactory)
	SB_PHP_FE(SBLDAPCertRetriever, UnregisterLDAPCertificateRetrieverFactory, arginfo_SBLDAPCertRetriever_UnregisterLDAPCertificateRetrieverFactory)

	// SBLDAPCRL unit functions
	SB_PHP_FE(SBLDAPCRL, RegisterLDAPCRLRetrieverFactory, arginfo_SBLDAPCRL_RegisterLDAPCRLRetrieverFactory)
	SB_PHP_FE(SBLDAPCRL, UnregisterLDAPCRLRetrieverFactory, arginfo_SBLDAPCRL_UnregisterLDAPCRLRetrieverFactory)

	// SBLDAPSCore unit functions
	SB_PHP_FE(SBLDAPSCore, AttrFromString, arginfo_SBLDAPSCore_AttrFromString)
	SB_PHP_FE(SBLDAPSCore, AttrFromBuffer, arginfo_SBLDAPSCore_AttrFromBuffer)
	SB_PHP_FE(SBLDAPSCore, PutSimpleFilter, arginfo_SBLDAPSCore_PutSimpleFilter)
	SB_PHP_FE(SBLDAPSCore, PutSubstringFilter, arginfo_SBLDAPSCore_PutSubstringFilter)
	SB_PHP_FE(SBLDAPSCore, SplitValue, arginfo_SBLDAPSCore_SplitValue)
	SB_PHP_FE(SBLDAPSCore, PutFilterList, arginfo_SBLDAPSCore_PutFilterList)
	SB_PHP_FE(SBLDAPSCore, IsDigit, arginfo_SBLDAPSCore_IsDigit)
	SB_PHP_FE(SBLDAPSCore, IsHexLower, arginfo_SBLDAPSCore_IsHexLower)
	SB_PHP_FE(SBLDAPSCore, IsHexUpper, arginfo_SBLDAPSCore_IsHexUpper)
	SB_PHP_FE(SBLDAPSCore, IsHex, arginfo_SBLDAPSCore_IsHex)
	SB_PHP_FE(SBLDAPSCore, IsLower, arginfo_SBLDAPSCore_IsLower)
	SB_PHP_FE(SBLDAPSCore, IsUpper, arginfo_SBLDAPSCore_IsUpper)
	SB_PHP_FE(SBLDAPSCore, IsAlpha, arginfo_SBLDAPSCore_IsAlpha)
	SB_PHP_FE(SBLDAPSCore, IsAlnum, arginfo_SBLDAPSCore_IsAlnum)
	SB_PHP_FE(SBLDAPSCore, IsLdh, arginfo_SBLDAPSCore_IsLdh)
	SB_PHP_FE(SBLDAPSCore, IsSpace, arginfo_SBLDAPSCore_IsSpace)
	SB_PHP_FE(SBLDAPSCore, Hex2Value, arginfo_SBLDAPSCore_Hex2Value)
	SB_PHP_FE(SBLDAPSCore, GetMessageLenSize, arginfo_SBLDAPSCore_GetMessageLenSize)
	SB_PHP_FE(SBLDAPSCore, GetMessageLen, arginfo_SBLDAPSCore_GetMessageLen)
	SB_PHP_FE(SBLDAPSCore, GetMessageType, arginfo_SBLDAPSCore_GetMessageType)

	// SBIMAPUtils unit functions
	SB_PHP_FE(SBIMAPUtils, QuoteString, arginfo_SBIMAPUtils_QuoteString)
	SB_PHP_FE(SBIMAPUtils, QuoteStringIfNeed, arginfo_SBIMAPUtils_QuoteStringIfNeed)
	SB_PHP_FE(SBIMAPUtils, UnQuoteString, arginfo_SBIMAPUtils_UnQuoteString)
	SB_PHP_FE(SBIMAPUtils, IsLiteralToken, arginfo_SBIMAPUtils_IsLiteralToken)

	// SBMIME unit functions
	SB_PHP_FE(SBMIME, WideSameText, arginfo_SBMIME_WideSameText)
	SB_PHP_FE(SBMIME, GetHeaderFromStream, arginfo_SBMIME_GetHeaderFromStream)
	SB_PHP_FE(SBMIME, DeleteQuotationMarks, arginfo_SBMIME_DeleteQuotationMarks)
	SB_PHP_FE(SBMIME, SetInQuotationMarks, arginfo_SBMIME_SetInQuotationMarks)
	SB_PHP_FE(SBMIME, IsAddressListField, arginfo_SBMIME_IsAddressListField)
	SB_PHP_FE(SBMIME, IsMessageScopeField, arginfo_SBMIME_IsMessageScopeField)
	SB_PHP_FE(SBMIME, IsUnstructuredField, arginfo_SBMIME_IsUnstructuredField)
	SB_PHP_FE(SBMIME, RegisterUnstructuredField, arginfo_SBMIME_RegisterUnstructuredField)
	SB_PHP_FE(SBMIME, AddRegisteredMIMEMessagePartHandler, arginfo_SBMIME_AddRegisteredMIMEMessagePartHandler)
	SB_PHP_FE(SBMIME, RemoveRegisteredMIMEMessagePartHandler, arginfo_SBMIME_RemoveRegisteredMIMEMessagePartHandler)

	// SBMIMEEnc unit functions
	SB_PHP_FE(SBMIMEEnc, DecodeHeader, arginfo_SBMIMEEnc_DecodeHeader)
	SB_PHP_FE(SBMIMEEnc, EncodeQuotedPrintableBodyForHeader, arginfo_SBMIMEEnc_EncodeQuotedPrintableBodyForHeader)

	// SBMIMEStream unit functions
	SB_PHP_FE(SBMIMEStream, WriteStringToStream, arginfo_SBMIMEStream_WriteStringToStream)
	SB_PHP_FE(SBMIMEStream, WriteWideStringToStream, arginfo_SBMIMEStream_WriteWideStringToStream)
	SB_PHP_FE(SBMIMEStream, WriteStreamToStream, arginfo_SBMIMEStream_WriteStreamToStream)
	SB_PHP_FE(SBMIMEStream, ReadLineFromStream, arginfo_SBMIMEStream_ReadLineFromStream)
	SB_PHP_FE(SBMIMEStream, SeekStreamToEnd, arginfo_SBMIMEStream_SeekStreamToEnd)

	// SBCompoundFile unit functions
	SB_PHP_FE(SBCompoundFile, IsValidDirectoryEntryName, arginfo_SBCompoundFile_IsValidDirectoryEntryName)
	SB_PHP_FE(SBCompoundFile, CompareDirectoryEntryNames, arginfo_SBCompoundFile_CompareDirectoryEntryNames)
	SB_PHP_FE(SBCompoundFile, CopyStorage, arginfo_SBCompoundFile_CopyStorage)

	// SBOffice unit functions
	SB_PHP_FE(SBOffice, RegisterSecurityHandler, arginfo_SBOffice_RegisterSecurityHandler)
	SB_PHP_FE(SBOffice, UnregisterSecurityHandler, arginfo_SBOffice_UnregisterSecurityHandler)
	SB_PHP_FE(SBOffice, DocumentFormatToString, arginfo_SBOffice_DocumentFormatToString)
	SB_PHP_FE(SBOffice, BinaryDocumentTypeToString, arginfo_SBOffice_BinaryDocumentTypeToString)
	SB_PHP_FE(SBOffice, OpenXMLDocumentTypeToString, arginfo_SBOffice_OpenXMLDocumentTypeToString)
	SB_PHP_FE(SBOffice, OpenDocumentTypeToString, arginfo_SBOffice_OpenDocumentTypeToString)
	SB_PHP_FE(SBOffice, IsSharedWorkbook, arginfo_SBOffice_IsSharedWorkbook)
	SB_PHP_FE(SBOffice, Initialize, arginfo_SBOffice_Initialize)

	// SBOfficeBinaryCore unit functions
	SB_PHP_FE(SBOfficeBinaryCore, BufferToInt32, arginfo_SBOfficeBinaryCore_BufferToInt32)
	SB_PHP_FE(SBOfficeBinaryCore, BufferToInt64, arginfo_SBOfficeBinaryCore_BufferToInt64)
	SB_PHP_FE(SBOfficeBinaryCore, Int32ToBuffer, arginfo_SBOfficeBinaryCore_Int32ToBuffer)
	SB_PHP_FE(SBOfficeBinaryCore, UInt32ToBuffer, arginfo_SBOfficeBinaryCore_UInt32ToBuffer)
	SB_PHP_FE(SBOfficeBinaryCore, Int64ToBuffer, arginfo_SBOfficeBinaryCore_Int64ToBuffer)
	SB_PHP_FE(SBOfficeBinaryCore, SwapTimeEncoding, arginfo_SBOfficeBinaryCore_SwapTimeEncoding)

	// SBOfficeXMLCore unit functions
	SB_PHP_FE(SBOfficeXMLCore, IsValidPartIRI, arginfo_SBOfficeXMLCore_IsValidPartIRI)
	SB_PHP_FE(SBOfficeXMLCore, IsValidPartURI, arginfo_SBOfficeXMLCore_IsValidPartURI)
	SB_PHP_FE(SBOfficeXMLCore, ConvertPartIRIToURI, arginfo_SBOfficeXMLCore_ConvertPartIRIToURI)
	SB_PHP_FE(SBOfficeXMLCore, ConvertPartURIToIRI, arginfo_SBOfficeXMLCore_ConvertPartURIToIRI)
	SB_PHP_FE(SBOfficeXMLCore, ComparePartIRI, arginfo_SBOfficeXMLCore_ComparePartIRI)
	SB_PHP_FE(SBOfficeXMLCore, ComparePartURI, arginfo_SBOfficeXMLCore_ComparePartURI)
	SB_PHP_FE(SBOfficeXMLCore, NormalizePartIRI, arginfo_SBOfficeXMLCore_NormalizePartIRI)
	SB_PHP_FE(SBOfficeXMLCore, NormalizePartURI, arginfo_SBOfficeXMLCore_NormalizePartURI)
	SB_PHP_FE(SBOfficeXMLCore, ResolveRelativePartIRI, arginfo_SBOfficeXMLCore_ResolveRelativePartIRI)
	SB_PHP_FE(SBOfficeXMLCore, ResolveRelativePartURI, arginfo_SBOfficeXMLCore_ResolveRelativePartURI)
	SB_PHP_FE(SBOfficeXMLCore, GetRelativePartURI, arginfo_SBOfficeXMLCore_GetRelativePartURI)
	SB_PHP_FE(SBOfficeXMLCore, GetRelationshipURI, arginfo_SBOfficeXMLCore_GetRelationshipURI)
	SB_PHP_FE(SBOfficeXMLCore, GetPartURIExtension, arginfo_SBOfficeXMLCore_GetPartURIExtension)
	SB_PHP_FE(SBOfficeXMLCore, GetPartURIPath, arginfo_SBOfficeXMLCore_GetPartURIPath)
	SB_PHP_FE(SBOfficeXMLCore, GetPartURIName, arginfo_SBOfficeXMLCore_GetPartURIName)
	SB_PHP_FE(SBOfficeXMLCore, GetPartURIQueryComponent, arginfo_SBOfficeXMLCore_GetPartURIQueryComponent)
	SB_PHP_FE(SBOfficeXMLCore, RemovePartURIExtension, arginfo_SBOfficeXMLCore_RemovePartURIExtension)
	SB_PHP_FE(SBOfficeXMLCore, RemovePartIRIQueryComponent, arginfo_SBOfficeXMLCore_RemovePartIRIQueryComponent)
	SB_PHP_FE(SBOfficeXMLCore, RemovePartURIQueryComponent, arginfo_SBOfficeXMLCore_RemovePartURIQueryComponent)
	SB_PHP_FE(SBOfficeXMLCore, GetValueFromQueryComponent, arginfo_SBOfficeXMLCore_GetValueFromQueryComponent)
	SB_PHP_FE(SBOfficeXMLCore, IsLogicalItemSuffixName, arginfo_SBOfficeXMLCore_IsLogicalItemSuffixName)
	SB_PHP_FE(SBOfficeXMLCore, ParseLogicalItemSuffixName, arginfo_SBOfficeXMLCore_ParseLogicalItemSuffixName)
	SB_PHP_FE(SBOfficeXMLCore, FormatLogicalItemSuffixName, arginfo_SBOfficeXMLCore_FormatLogicalItemSuffixName)
	SB_PHP_FE(SBOfficeXMLCore, DecodeXMLName, arginfo_SBOfficeXMLCore_DecodeXMLName)
	SB_PHP_FE(SBOfficeXMLCore, EncodeXMLNameSimple, arginfo_SBOfficeXMLCore_EncodeXMLNameSimple)
	SB_PHP_FE(SBOfficeXMLCore, GenerateUniqueIdForRelationship, arginfo_SBOfficeXMLCore_GenerateUniqueIdForRelationship)
	SB_PHP_FE(SBOfficeXMLCore, GetOpenXMLDocumentTypeFromContentType, arginfo_SBOfficeXMLCore_GetOpenXMLDocumentTypeFromContentType)
	SB_PHP_FE(SBOfficeXMLCore, GetOpenDocumentTypeFromMimeType, arginfo_SBOfficeXMLCore_GetOpenDocumentTypeFromMimeType)
	SB_PHP_FE(SBOfficeXMLCore, WideCompareStrOrdinal, arginfo_SBOfficeXMLCore_WideCompareStrOrdinal)

	// SBPDF unit functions
	SB_PHP_FE(SBPDF, RegisterSecurityHandler, arginfo_SBPDF_RegisterSecurityHandler)
	SB_PHP_FE(SBPDF, UnregisterSecurityHandler, arginfo_SBPDF_UnregisterSecurityHandler)
	SB_PHP_FE(SBPDF, GetPDFStandardType1FontName, arginfo_SBPDF_GetPDFStandardType1FontName)

	// SBPDFCore unit functions
	SB_PHP_FE(SBPDFCore, GetNameObjectFromDictionary, arginfo_SBPDFCore_GetNameObjectFromDictionary)
	SB_PHP_FE(SBPDFCore, GetIntObjectFromDictionary, arginfo_SBPDFCore_GetIntObjectFromDictionary)
	SB_PHP_FE(SBPDFCore, GetRealObjectFromDictionary, arginfo_SBPDFCore_GetRealObjectFromDictionary)
	SB_PHP_FE(SBPDFCore, GetStringObjectFromDictionary, arginfo_SBPDFCore_GetStringObjectFromDictionary)
	SB_PHP_FE(SBPDFCore, GetArrayObjectFromDictionary, arginfo_SBPDFCore_GetArrayObjectFromDictionary)
	SB_PHP_FE(SBPDFCore, GetDictionaryObjectFromDictionary, arginfo_SBPDFCore_GetDictionaryObjectFromDictionary)
	SB_PHP_FE(SBPDFCore, GetBooleanObjectFromDictionary, arginfo_SBPDFCore_GetBooleanObjectFromDictionary)
	SB_PHP_FE(SBPDFCore, AddRealObjectToDictionary, arginfo_SBPDFCore_AddRealObjectToDictionary)
	SB_PHP_FE(SBPDFCore, AddIntObjectToDictionary, arginfo_SBPDFCore_AddIntObjectToDictionary)
	SB_PHP_FE(SBPDFCore, AddBooleanObjectToDictionary, arginfo_SBPDFCore_AddBooleanObjectToDictionary)
	SB_PHP_FE(SBPDFCore, AddStringObjectToDictionary, arginfo_SBPDFCore_AddStringObjectToDictionary)
	SB_PHP_FE(SBPDFCore, AddNameObjectToDictionary, arginfo_SBPDFCore_AddNameObjectToDictionary)
	SB_PHP_FE(SBPDFCore, AddRectangleObjectToDictionary, arginfo_SBPDFCore_AddRectangleObjectToDictionary)
	SB_PHP_FE(SBPDFCore, AddReferenceToDictionary, arginfo_SBPDFCore_AddReferenceToDictionary)
	SB_PHP_FE(SBPDFCore, AddRealObjectToArray, arginfo_SBPDFCore_AddRealObjectToArray)
	SB_PHP_FE(SBPDFCore, AddIntObjectToArray, arginfo_SBPDFCore_AddIntObjectToArray)
	SB_PHP_FE(SBPDFCore, AddNameObjectToArray, arginfo_SBPDFCore_AddNameObjectToArray)
	SB_PHP_FE(SBPDFCore, AddStringObjectToArray, arginfo_SBPDFCore_AddStringObjectToArray)
	SB_PHP_FE(SBPDFCore, CreateStream, arginfo_SBPDFCore_CreateStream)
	SB_PHP_FE(SBPDFCore, CompressStream, arginfo_SBPDFCore_CompressStream)
	SB_PHP_FE(SBPDFCore, EncodePDFDate, arginfo_SBPDFCore_EncodePDFDate)
	SB_PHP_FE(SBPDFCore, DecodePDFDate, arginfo_SBPDFCore_DecodePDFDate)
	SB_PHP_FE(SBPDFCore, EncodeTextString, arginfo_SBPDFCore_EncodeTextString)
	SB_PHP_FE(SBPDFCore, EncodeTextStringUnicode, arginfo_SBPDFCore_EncodeTextStringUnicode)
	SB_PHP_FE(SBPDFCore, DecodeTextString, arginfo_SBPDFCore_DecodeTextString)
	SB_PHP_FE(SBPDFCore, GetSortedKeyList, arginfo_SBPDFCore_GetSortedKeyList)

	// SBPDFUtils unit functions
	SB_PHP_FE(SBPDFUtils, IntToByteArray, arginfo_SBPDFUtils_IntToByteArray)
	SB_PHP_FE(SBPDFUtils, UIntToByteArray, arginfo_SBPDFUtils_UIntToByteArray)
	SB_PHP_FE(SBPDFUtils, IsPNGPredictor, arginfo_SBPDFUtils_IsPNGPredictor)
	SB_PHP_FE(SBPDFUtils, DecodePNG, arginfo_SBPDFUtils_DecodePNG)
	SB_PHP_FE(SBPDFUtils, TrimArray, arginfo_SBPDFUtils_TrimArray)

	// SBPGPEntities unit functions
	SB_PHP_FE(SBPGPEntities, CreateEntity, arginfo_SBPGPEntities_CreateEntity)
	SB_PHP_FE(SBPGPEntities, CloneEntity, arginfo_SBPGPEntities_CloneEntity)

	// SBPGPMD unit functions
	SB_PHP_FE(SBPGPMD, MDGetDigestSize, arginfo_SBPGPMD_MDGetDigestSize)
	SB_PHP_FE(SBPGPMD, MDInitialize, arginfo_SBPGPMD_MDInitialize)
	SB_PHP_FE(SBPGPMD, MDHash, arginfo_SBPGPMD_MDHash)
	SB_PHP_FE(SBPGPMD, MDFinalize, arginfo_SBPGPMD_MDFinalize)

	// SBPGPUtils unit functions
	SB_PHP_FE(SBPGPUtils, UTCTime, arginfo_SBPGPUtils_UTCTime)
	SB_PHP_FE(SBPGPUtils, TimestampToDateTime, arginfo_SBPGPUtils_TimestampToDateTime)
	SB_PHP_FE(SBPGPUtils, DateTimeToTimestamp, arginfo_SBPGPUtils_DateTimeToTimestamp)
	SB_PHP_FE(SBPGPUtils, ReadMPInt, arginfo_SBPGPUtils_ReadMPInt)
	SB_PHP_FE(SBPGPUtils, WriteMPInt, arginfo_SBPGPUtils_WriteMPInt)
	#ifdef SB_DEFINE_FPC_SPECIFIC_METHODS
	SB_PHP_FE(SBPGPUtils, WriteMPInt2, arginfo_SBPGPUtils_WriteMPInt2)
	#endif /* SB_DEFINE_FPC_SPECIFIC_METHODS */
	SB_PHP_FE(SBPGPUtils, GetPGPPacketHeaderSize, arginfo_SBPGPUtils_GetPGPPacketHeaderSize)
	SB_PHP_FE(SBPGPUtils, GetSigSubpktTypeByExtension, arginfo_SBPGPUtils_GetSigSubpktTypeByExtension)
	SB_PHP_FE(SBPGPUtils, WriteSizeInt, arginfo_SBPGPUtils_WriteSizeInt)
	SB_PHP_FE(SBPGPUtils, MPIntToByteArray, arginfo_SBPGPUtils_MPIntToByteArray)
	SB_PHP_FE(SBPGPUtils, IsCorrectHashAlgorithm, arginfo_SBPGPUtils_IsCorrectHashAlgorithm)
	SB_PHP_FE(SBPGPUtils, IsCorrectSymmetricAlgorithm, arginfo_SBPGPUtils_IsCorrectSymmetricAlgorithm)
	SB_PHP_FE(SBPGPUtils, AlgorithmCanSign, arginfo_SBPGPUtils_AlgorithmCanSign)
	SB_PHP_FE(SBPGPUtils, AlgorithmCanEncrypt, arginfo_SBPGPUtils_AlgorithmCanEncrypt)
	SB_PHP_FE(SBPGPUtils, TranslateMDAlgorithmFromPGP, arginfo_SBPGPUtils_TranslateMDAlgorithmFromPGP)
	SB_PHP_FE(SBPGPUtils, TranslateMDAlgorithmToPGP, arginfo_SBPGPUtils_TranslateMDAlgorithmToPGP)
	SB_PHP_FE(SBPGPUtils, TranslateSKAlgorithmFromPGP, arginfo_SBPGPUtils_TranslateSKAlgorithmFromPGP)
	SB_PHP_FE(SBPGPUtils, TranslateSKAlgorithmToPGP, arginfo_SBPGPUtils_TranslateSKAlgorithmToPGP)
	SB_PHP_FE(SBPGPUtils, TranslateMDAlgorithmToECDSA, arginfo_SBPGPUtils_TranslateMDAlgorithmToECDSA)
	SB_PHP_FE(SBPGPUtils, AddPKCS1Prefix, arginfo_SBPGPUtils_AddPKCS1Prefix)
	SB_PHP_FE(SBPGPUtils, SymmetricInitialize, arginfo_SBPGPUtils_SymmetricInitialize)
	SB_PHP_FE(SBPGPUtils, SymmetricFinalize, arginfo_SBPGPUtils_SymmetricFinalize)
	SB_PHP_FE(SBPGPUtils, MPIntSize, arginfo_SBPGPUtils_MPIntSize)
	SB_PHP_FE(SBPGPUtils, MPIntBitCount, arginfo_SBPGPUtils_MPIntBitCount)
	SB_PHP_FE(SBPGPUtils, CRC24, arginfo_SBPGPUtils_CRC24)
	SB_PHP_FE(SBPGPUtils, CalculateChecksum, arginfo_SBPGPUtils_CalculateChecksum)
	#ifdef SB_DEFINE_FPC_SPECIFIC_METHODS
	SB_PHP_FE(SBPGPUtils, ToBase64_32, arginfo_SBPGPUtils_ToBase64_32)
	#endif /* SB_DEFINE_FPC_SPECIFIC_METHODS */
	SB_PHP_FE(SBPGPUtils, ToBase64_2, arginfo_SBPGPUtils_ToBase64_2)
	SB_PHP_FE(SBPGPUtils, ToBase64_1, arginfo_SBPGPUtils_ToBase64_1)
	SB_PHP_FE(SBPGPUtils, SKGetBlockSize, arginfo_SBPGPUtils_SKGetBlockSize)
	SB_PHP_FE(SBPGPUtils, SKGetKeySize, arginfo_SBPGPUtils_SKGetKeySize)
	SB_PHP_FE(SBPGPUtils, CreateAndInitRandom, arginfo_SBPGPUtils_CreateAndInitRandom)
	SB_PHP_FE(SBPGPUtils, Max64, arginfo_SBPGPUtils_Max64)
	SB_PHP_FE(SBPGPUtils, Min64, arginfo_SBPGPUtils_Min64)
	SB_PHP_FE(SBPGPUtils, IsPublicKeyEncryptionAlgorithm, arginfo_SBPGPUtils_IsPublicKeyEncryptionAlgorithm)
	SB_PHP_FE(SBPGPUtils, IsPublicKeySigningAlgorithm, arginfo_SBPGPUtils_IsPublicKeySigningAlgorithm)
	SB_PHP_FE(SBPGPUtils, AlgorithmMPIntsPublic, arginfo_SBPGPUtils_AlgorithmMPIntsPublic)
	SB_PHP_FE(SBPGPUtils, AlgorithmMPIntsSecret, arginfo_SBPGPUtils_AlgorithmMPIntsSecret)
	SB_PHP_FE(SBPGPUtils, CompareKeyID, arginfo_SBPGPUtils_CompareKeyID)
	SB_PHP_FE(SBPGPUtils, CompareKeyFP, arginfo_SBPGPUtils_CompareKeyFP)
	SB_PHP_FE(SBPGPUtils, CompareKeyIDArrays, arginfo_SBPGPUtils_CompareKeyIDArrays)
	SB_PHP_FE(SBPGPUtils, GetSymmetricKeyAlgorithmName, arginfo_SBPGPUtils_GetSymmetricKeyAlgorithmName)
	SB_PHP_FE(SBPGPUtils, GetSymmetricKeyAlgorithmByName, arginfo_SBPGPUtils_GetSymmetricKeyAlgorithmByName)
	SB_PHP_FE(SBPGPUtils, FormatPKCS1, arginfo_SBPGPUtils_FormatPKCS1)
	SB_PHP_FE(SBPGPUtils, UnformatPKCS1, arginfo_SBPGPUtils_UnformatPKCS1)
	SB_PHP_FE(SBPGPUtils, PGPCurveByOID, arginfo_SBPGPUtils_PGPCurveByOID)
	SB_PHP_FE(SBPGPUtils, OIDByPGPCurve, arginfo_SBPGPUtils_OIDByPGPCurve)
	SB_PHP_FE(SBPGPUtils, PGPCurveByBits, arginfo_SBPGPUtils_PGPCurveByBits)
	SB_PHP_FE(SBPGPUtils, BitsInPGPCurve, arginfo_SBPGPUtils_BitsInPGPCurve)
	SB_PHP_FE(SBPGPUtils, HashAlgorithmByPGPCurve, arginfo_SBPGPUtils_HashAlgorithmByPGPCurve)
	SB_PHP_FE(SBPGPUtils, SymmetricAlgorithmByPGPCurve, arginfo_SBPGPUtils_SymmetricAlgorithmByPGPCurve)
	SB_PHP_FE(SBPGPUtils, DetectMessageEncoding, arginfo_SBPGPUtils_DetectMessageEncoding)
	SB_PHP_FE(SBPGPUtils, BytesInEncoding, arginfo_SBPGPUtils_BytesInEncoding)
	SB_PHP_FE(SBPGPUtils, UnicodeMessageToUtf8, arginfo_SBPGPUtils_UnicodeMessageToUtf8)
	SB_PHP_FE(SBPGPUtils, IsCleartextMessage, arginfo_SBPGPUtils_IsCleartextMessage)
	SB_PHP_FE(SBPGPUtils, SizeOfMessageInEncoding, arginfo_SBPGPUtils_SizeOfMessageInEncoding)
	SB_PHP_FE(SBPGPUtils, IsWhitespace, arginfo_SBPGPUtils_IsWhitespace)
	SB_PHP_FE(SBPGPUtils, IsEOL, arginfo_SBPGPUtils_IsEOL)
	SB_PHP_FE(SBPGPUtils, IsEmailChar, arginfo_SBPGPUtils_IsEmailChar)
	SB_PHP_FE(SBPGPUtils, UserIDCorrespondsToEmail, arginfo_SBPGPUtils_UserIDCorrespondsToEmail)
	SB_PHP_FE(SBPGPUtils, KeyID2Str, arginfo_SBPGPUtils_KeyID2Str)
	SB_PHP_FE(SBPGPUtils, KeyID2Array, arginfo_SBPGPUtils_KeyID2Array)
	SB_PHP_FE(SBPGPUtils, KeyFP2Str, arginfo_SBPGPUtils_KeyFP2Str)
	SB_PHP_FE(SBPGPUtils, PKAlg2Str, arginfo_SBPGPUtils_PKAlg2Str)
	SB_PHP_FE(SBPGPUtils, HashAlg2Str, arginfo_SBPGPUtils_HashAlg2Str)
	SB_PHP_FE(SBPGPUtils, Str2HashAlg, arginfo_SBPGPUtils_Str2HashAlg)
	SB_PHP_FE(SBPGPUtils, ComprAlg2Str, arginfo_SBPGPUtils_ComprAlg2Str)
	SB_PHP_FE(SBPGPUtils, ConvertDaysToSeconds, arginfo_SBPGPUtils_ConvertDaysToSeconds)
	SB_PHP_FE(SBPGPUtils, ConvertSecondsToDays, arginfo_SBPGPUtils_ConvertSecondsToDays)
	SB_PHP_FE(SBPGPUtils, EncodePassword, arginfo_SBPGPUtils_EncodePassword)
	SB_PHP_FE(SBPGPUtils, GetOpenPGPPasswordCharset, arginfo_SBPGPUtils_GetOpenPGPPasswordCharset)
	SB_PHP_FE(SBPGPUtils, SetOpenPGPPasswordCharset, arginfo_SBPGPUtils_SetOpenPGPPasswordCharset)

	// SBPGPMIME unit functions
	SB_PHP_FE(SBPGPMIME, Initialize, arginfo_SBPGPMIME_Initialize)

	// SBCMS unit functions
	SB_PHP_FE(SBCMS, GetTimestampTypeOID, arginfo_SBCMS_GetTimestampTypeOID)

	// SBCryptoProvPKCS11 unit functions
	SB_PHP_FE(SBCryptoProvPKCS11, PKCS11CryptoProvider, arginfo_SBCryptoProvPKCS11_PKCS11CryptoProvider)

	// SBPKCS11Base unit functions
	SB_PHP_FE(SBPKCS11Base, PKCS11AlgorithmConverter, arginfo_SBPKCS11Base_PKCS11AlgorithmConverter)
	SB_PHP_FE(SBPKCS11Base, CreateMutexCallback, arginfo_SBPKCS11Base_CreateMutexCallback)
	SB_PHP_FE(SBPKCS11Base, DestroyMutexCallback, arginfo_SBPKCS11Base_DestroyMutexCallback)
	SB_PHP_FE(SBPKCS11Base, LockMutexCallback, arginfo_SBPKCS11Base_LockMutexCallback)
	SB_PHP_FE(SBPKCS11Base, UnlockMutexCallback, arginfo_SBPKCS11Base_UnlockMutexCallback)
	SB_PHP_FE(SBPKCS11Base, GetPKCS11String, arginfo_SBPKCS11Base_GetPKCS11String)
	SB_PHP_FE(SBPKCS11Base, PKCS11CheckError, arginfo_SBPKCS11Base_PKCS11CheckError)
	SB_PHP_FE(SBPKCS11Base, GetPKCS11ErrorNameByCode, arginfo_SBPKCS11Base_GetPKCS11ErrorNameByCode)
	SB_PHP_FE(SBPKCS11Base, EncodeErrorInfo, arginfo_SBPKCS11Base_EncodeErrorInfo)
	SB_PHP_FE(SBPKCS11Base, GetPKCS11ModuleList, arginfo_SBPKCS11Base_GetPKCS11ModuleList)
	SB_PHP_FE(SBPKCS11Base, UnloadPKCS11Modules, arginfo_SBPKCS11Base_UnloadPKCS11Modules)

	// SBPKCS11CertStorage unit functions
	SB_PHP_FE(SBPKCS11CertStorage, GetContextByCertificate, arginfo_SBPKCS11CertStorage_GetContextByCertificate)

	// SBAuthenticode unit functions
	SB_PHP_FE(SBAuthenticode, GetDigestAlgorithm, arginfo_SBAuthenticode_GetDigestAlgorithm)
	SB_PHP_FE(SBAuthenticode, GetDigestAlgorithmOID, arginfo_SBAuthenticode_GetDigestAlgorithmOID)
	SB_PHP_FE(SBAuthenticode, GetAuthenticodeDigestAlgorithm, arginfo_SBAuthenticode_GetAuthenticodeDigestAlgorithm)
	SB_PHP_FE(SBAuthenticode, GetAuthenticodeDigestAlgorithmName, arginfo_SBAuthenticode_GetAuthenticodeDigestAlgorithmName)

	// SBJWCrypto unit functions
	SB_PHP_FE(SBJWCrypto, Base64UrlEncode, arginfo_SBJWCrypto_Base64UrlEncode)
	SB_PHP_FE(SBJWCrypto, Base64UrlDecode, arginfo_SBJWCrypto_Base64UrlDecode)

	// SBHID unit functions
	SB_PHP_FE(SBHID, HIDEnumerateDevices, arginfo_SBHID_HIDEnumerateDevices)

#ifdef SB_WINDOWS
	// SBHIDWin unit functions
	SB_PHP_FE(SBHIDWin, HIDEnumerateDevices, arginfo_SBHIDWin_HIDEnumerateDevices)
	SB_PHP_FE(SBHIDWin, LoadHIDModule, arginfo_SBHIDWin_LoadHIDModule)
	SB_PHP_FE(SBHIDWin, LoadSetupAPIModule, arginfo_SBHIDWin_LoadSetupAPIModule)
	SB_PHP_FE(SBHIDWin, UnloadHIDModule, arginfo_SBHIDWin_UnloadHIDModule)
	SB_PHP_FE(SBHIDWin, UnloadSetupAPIModule, arginfo_SBHIDWin_UnloadSetupAPIModule)
	SB_PHP_FE(SBHIDWin, HIDOpenDevice, arginfo_SBHIDWin_HIDOpenDevice)
	SB_PHP_FE(SBHIDWin, HIDCloseDevice, arginfo_SBHIDWin_HIDCloseDevice)
	SB_PHP_FE(SBHIDWin, HIDReadTimeout, arginfo_SBHIDWin_HIDReadTimeout)
	SB_PHP_FE(SBHIDWin, HIDWriteTimeout, arginfo_SBHIDWin_HIDWriteTimeout)
	SB_PHP_FE(SBHIDWin, HIDIsInvalidDevice, arginfo_SBHIDWin_HIDIsInvalidDevice)
	SB_PHP_FE(SBHIDWin, HIDGetDeviceAttributes, arginfo_SBHIDWin_HIDGetDeviceAttributes)
	SB_PHP_FE(SBHIDWin, HIDGetDeviceSerialNumber, arginfo_SBHIDWin_HIDGetDeviceSerialNumber)
	SB_PHP_FE(SBHIDWin, HIDGetDeviceManufacturer, arginfo_SBHIDWin_HIDGetDeviceManufacturer)
	SB_PHP_FE(SBHIDWin, HIDGetDeviceProduct, arginfo_SBHIDWin_HIDGetDeviceProduct)
	SB_PHP_FE(SBHIDWin, HIDGetDeviceIndexedString, arginfo_SBHIDWin_HIDGetDeviceIndexedString)
	SB_PHP_FE(SBHIDWin, HIDGetDeviceCapabilities, arginfo_SBHIDWin_HIDGetDeviceCapabilities)
	SB_PHP_FE(SBHIDWin, HIDGetDeviceFeature, arginfo_SBHIDWin_HIDGetDeviceFeature)
	SB_PHP_FE(SBHIDWin, HIDSetDeviceFeature, arginfo_SBHIDWin_HIDSetDeviceFeature)
#endif
#ifdef LINUX
	// SBHIDLinux unit functions
	SB_PHP_FE(SBHIDLinux, HIDEnumerateDevices, arginfo_SBHIDLinux_HIDEnumerateDevices)
	SB_PHP_FE(SBHIDLinux, LoadUdevModule, arginfo_SBHIDLinux_LoadUdevModule)
	SB_PHP_FE(SBHIDLinux, UnloadUdevModule, arginfo_SBHIDLinux_UnloadUdevModule)
	SB_PHP_FE(SBHIDLinux, HIDOpenDevice, arginfo_SBHIDLinux_HIDOpenDevice)
	SB_PHP_FE(SBHIDLinux, HIDCloseDevice, arginfo_SBHIDLinux_HIDCloseDevice)
	SB_PHP_FE(SBHIDLinux, HIDReadTimeout, arginfo_SBHIDLinux_HIDReadTimeout)
	SB_PHP_FE(SBHIDLinux, HIDWriteTimeout, arginfo_SBHIDLinux_HIDWriteTimeout)
	SB_PHP_FE(SBHIDLinux, HIDIsInvalidDevice, arginfo_SBHIDLinux_HIDIsInvalidDevice)
	SB_PHP_FE(SBHIDLinux, HIDGetDeviceAttributes, arginfo_SBHIDLinux_HIDGetDeviceAttributes)
	SB_PHP_FE(SBHIDLinux, HIDGetDeviceSerialNumber, arginfo_SBHIDLinux_HIDGetDeviceSerialNumber)
	SB_PHP_FE(SBHIDLinux, HIDGetDeviceManufacturer, arginfo_SBHIDLinux_HIDGetDeviceManufacturer)
	SB_PHP_FE(SBHIDLinux, HIDGetDeviceProduct, arginfo_SBHIDLinux_HIDGetDeviceProduct)
	SB_PHP_FE(SBHIDLinux, HIDGetDeviceIndexedString, arginfo_SBHIDLinux_HIDGetDeviceIndexedString)
	SB_PHP_FE(SBHIDLinux, HIDGetDeviceCapabilities, arginfo_SBHIDLinux_HIDGetDeviceCapabilities)
	SB_PHP_FE(SBHIDLinux, HIDGetDeviceFeature, arginfo_SBHIDLinux_HIDGetDeviceFeature)
	SB_PHP_FE(SBHIDLinux, HIDSetDeviceFeature, arginfo_SBHIDLinux_HIDSetDeviceFeature)
	SB_PHP_FE(SBHIDLinux, GetHIDOptions, arginfo_SBHIDLinux_GetHIDOptions)
	SB_PHP_FE(SBHIDLinux, SetHIDOptions, arginfo_SBHIDLinux_SetHIDOptions)
#endif
#ifdef MACOS
	// SBHIDMac unit functions
	SB_PHP_FE(SBHIDMac, HIDEnumerateDevices, arginfo_SBHIDMac_HIDEnumerateDevices)
	SB_PHP_FE(SBHIDMac, LoadIOHIDModule, arginfo_SBHIDMac_LoadIOHIDModule)
	SB_PHP_FE(SBHIDMac, UnloadIOHIDModule, arginfo_SBHIDMac_UnloadIOHIDModule)
	SB_PHP_FE(SBHIDMac, HIDOpenDevice, arginfo_SBHIDMac_HIDOpenDevice)
	SB_PHP_FE(SBHIDMac, HIDCloseDevice, arginfo_SBHIDMac_HIDCloseDevice)
	SB_PHP_FE(SBHIDMac, HIDReadTimeout, arginfo_SBHIDMac_HIDReadTimeout)
	SB_PHP_FE(SBHIDMac, HIDWriteTimeout, arginfo_SBHIDMac_HIDWriteTimeout)
	SB_PHP_FE(SBHIDMac, HIDIsInvalidDevice, arginfo_SBHIDMac_HIDIsInvalidDevice)
	SB_PHP_FE(SBHIDMac, HIDGetDeviceAttributes, arginfo_SBHIDMac_HIDGetDeviceAttributes)
	SB_PHP_FE(SBHIDMac, HIDGetDeviceSerialNumber, arginfo_SBHIDMac_HIDGetDeviceSerialNumber)
	SB_PHP_FE(SBHIDMac, HIDGetDeviceManufacturer, arginfo_SBHIDMac_HIDGetDeviceManufacturer)
	SB_PHP_FE(SBHIDMac, HIDGetDeviceProduct, arginfo_SBHIDMac_HIDGetDeviceProduct)
	SB_PHP_FE(SBHIDMac, HIDGetDeviceIndexedString, arginfo_SBHIDMac_HIDGetDeviceIndexedString)
	SB_PHP_FE(SBHIDMac, HIDGetDeviceCapabilities, arginfo_SBHIDMac_HIDGetDeviceCapabilities)
	SB_PHP_FE(SBHIDMac, HIDGetDeviceFeature, arginfo_SBHIDMac_HIDGetDeviceFeature)
	SB_PHP_FE(SBHIDMac, HIDSetDeviceFeature, arginfo_SBHIDMac_HIDSetDeviceFeature)
#endif

	// SBU2FHID unit functions
	SB_PHP_FE(SBU2FHID, U2FHIDEnumerateDevices, arginfo_SBU2FHID_U2FHIDEnumerateDevices)
	SB_PHP_FE(SBU2FHID, U2FHIDInit, arginfo_SBU2FHID_U2FHIDInit)
	SB_PHP_FE(SBU2FHID, U2FHIDSendCmd, arginfo_SBU2FHID_U2FHIDSendCmd)
	SB_PHP_FE(SBU2FHID, U2FHIDMessage, arginfo_SBU2FHID_U2FHIDMessage)
	SB_PHP_FE(SBU2FHID, U2FHIDPing, arginfo_SBU2FHID_U2FHIDPing)
	SB_PHP_FE(SBU2FHID, U2FHIDWink, arginfo_SBU2FHID_U2FHIDWink)
	SB_PHP_FE(SBU2FHID, U2FHIDLock, arginfo_SBU2FHID_U2FHIDLock)
	SB_PHP_FE(SBU2FHID, U2FHIDSync, arginfo_SBU2FHID_U2FHIDSync)

	// SBU2FCommon unit functions
	SB_PHP_FE(SBU2FCommon, U2FFormatRequestMessageFrame, arginfo_SBU2FCommon_U2FFormatRequestMessageFrame)
	SB_PHP_FE(SBU2FCommon, U2FGetStatusCodeFromResponseMessageFrame, arginfo_SBU2FCommon_U2FGetStatusCodeFromResponseMessageFrame)
	SB_PHP_FE(SBU2FCommon, U2FStatusCodeToMessage, arginfo_SBU2FCommon_U2FStatusCodeToMessage)
	SB_PHP_FE(SBU2FCommon, U2FFormatRegistrationRequestMessage, arginfo_SBU2FCommon_U2FFormatRegistrationRequestMessage)
	SB_PHP_FE(SBU2FCommon, U2FParseRegistrationResponseMessage, arginfo_SBU2FCommon_U2FParseRegistrationResponseMessage)
	SB_PHP_FE(SBU2FCommon, U2FFormatAuthRequestMessage, arginfo_SBU2FCommon_U2FFormatAuthRequestMessage)
	SB_PHP_FE(SBU2FCommon, U2FParseAuthResponseMessage, arginfo_SBU2FCommon_U2FParseAuthResponseMessage)
	SB_PHP_FE(SBU2FCommon, U2FJSONFormatClientData, arginfo_SBU2FCommon_U2FJSONFormatClientData)
	SB_PHP_FE(SBU2FCommon, U2FJSONParseClientData, arginfo_SBU2FCommon_U2FJSONParseClientData)
	SB_PHP_FE(SBU2FCommon, U2FJSONFormatRegistrationChallenge, arginfo_SBU2FCommon_U2FJSONFormatRegistrationChallenge)
	SB_PHP_FE(SBU2FCommon, U2FJSONParseRegistrationChallenge, arginfo_SBU2FCommon_U2FJSONParseRegistrationChallenge)
	SB_PHP_FE(SBU2FCommon, U2FJSONFormatAuthenticationChallenge, arginfo_SBU2FCommon_U2FJSONFormatAuthenticationChallenge)
	SB_PHP_FE(SBU2FCommon, U2FJSONParseAuthenticationChallenge, arginfo_SBU2FCommon_U2FJSONParseAuthenticationChallenge)
	SB_PHP_FE(SBU2FCommon, U2FJSONLoadU2FRegisterRequest, arginfo_SBU2FCommon_U2FJSONLoadU2FRegisterRequest)
	SB_PHP_FE(SBU2FCommon, U2FJSONSaveU2FRegisterRequest, arginfo_SBU2FCommon_U2FJSONSaveU2FRegisterRequest)
	SB_PHP_FE(SBU2FCommon, U2FJSONLoadU2FRegisterResponse, arginfo_SBU2FCommon_U2FJSONLoadU2FRegisterResponse)
	SB_PHP_FE(SBU2FCommon, U2FJSONSaveU2FRegisterResponse, arginfo_SBU2FCommon_U2FJSONSaveU2FRegisterResponse)
	SB_PHP_FE(SBU2FCommon, U2FJSONSaveU2FRegisterResponseError, arginfo_SBU2FCommon_U2FJSONSaveU2FRegisterResponseError)
	SB_PHP_FE(SBU2FCommon, U2FJSONLoadU2FSignRequest, arginfo_SBU2FCommon_U2FJSONLoadU2FSignRequest)
	SB_PHP_FE(SBU2FCommon, U2FJSONSaveU2FSignRequest, arginfo_SBU2FCommon_U2FJSONSaveU2FSignRequest)
	SB_PHP_FE(SBU2FCommon, U2FJSONLoadU2FSignResponse, arginfo_SBU2FCommon_U2FJSONLoadU2FSignResponse)
	SB_PHP_FE(SBU2FCommon, U2FJSONSaveU2FSignResponse, arginfo_SBU2FCommon_U2FJSONSaveU2FSignResponse)
	SB_PHP_FE(SBU2FCommon, U2FJSONSaveU2FSignResponseError, arginfo_SBU2FCommon_U2FJSONSaveU2FSignResponseError)
	SB_PHP_FE(SBU2FCommon, U2FJSAPIErrorToServerError, arginfo_SBU2FCommon_U2FJSAPIErrorToServerError)
	SB_PHP_FE(SBU2FCommon, U2FBase64UrlEncodeBytes, arginfo_SBU2FCommon_U2FBase64UrlEncodeBytes)
	SB_PHP_FE(SBU2FCommon, U2FBase64UrlDecodeBytes, arginfo_SBU2FCommon_U2FBase64UrlDecodeBytes)
	SB_PHP_FE(SBU2FCommon, U2FVerifyRegistrationSignature, arginfo_SBU2FCommon_U2FVerifyRegistrationSignature)
	SB_PHP_FE(SBU2FCommon, U2FVerifyAuthenticationSignature, arginfo_SBU2FCommon_U2FVerifyAuthenticationSignature)

#ifdef SB_WINDOWS
	// SBCryptoProvCardPIV unit functions
	SB_PHP_FE(SBCryptoProvCardPIV, PIVCardCryptoProvider, arginfo_SBCryptoProvCardPIV_PIVCardCryptoProvider)
#endif

	// SBSftpCommon unit functions
	SB_PHP_FE(SBSftpCommon, WriteDefaultAttributes, arginfo_SBSftpCommon_WriteDefaultAttributes)
	SB_PHP_FE(SBSftpCommon, RealPathControlToByte, arginfo_SBSftpCommon_RealPathControlToByte)
	SB_PHP_FE(SBSftpCommon, ByteToRealPathControl, arginfo_SBSftpCommon_ByteToRealPathControl)
	SB_PHP_FE(SBSftpCommon, FileOpenAccessToUInt32, arginfo_SBSftpCommon_FileOpenAccessToUInt32)
	SB_PHP_FE(SBSftpCommon, UInt32ToFileOpenAccess, arginfo_SBSftpCommon_UInt32ToFileOpenAccess)
	SB_PHP_FE(SBSftpCommon, UInt32ToRenameFlags, arginfo_SBSftpCommon_UInt32ToRenameFlags)
	SB_PHP_FE(SBSftpCommon, GetSFTPPacketNameByCode, arginfo_SBSftpCommon_GetSFTPPacketNameByCode)

	// SBSMIMECore unit functions
	SB_PHP_FE(SBSMIMECore, Initialize, arginfo_SBSMIMECore_Initialize)

	// SBSSHConstants unit functions
	SB_PHP_FE(SBSSHConstants, GetSSHPacketNameByCode, arginfo_SBSSHConstants_GetSSHPacketNameByCode)

	// SBSSHUtils unit functions
	SB_PHP_FE(SBSSHUtils, WriteString, arginfo_SBSSHUtils_WriteString)
	SB_PHP_FE(SBSSHUtils, WriteBitCount, arginfo_SBSSHUtils_WriteBitCount)
	SB_PHP_FE(SBSSHUtils, ReadSSH2MPInt, arginfo_SBSSHUtils_ReadSSH2MPInt)
	SB_PHP_FE(SBSSHUtils, ReadBoolean, arginfo_SBSSHUtils_ReadBoolean)
	SB_PHP_FE(SBSSHUtils, ReadString, arginfo_SBSSHUtils_ReadString)
	SB_PHP_FE(SBSSHUtils, ReadBuffer, arginfo_SBSSHUtils_ReadBuffer)
	SB_PHP_FE(SBSSHUtils, ReadSSH1MPInt, arginfo_SBSSHUtils_ReadSSH1MPInt)
	SB_PHP_FE(SBSSHUtils, ReadLength, arginfo_SBSSHUtils_ReadLength)
	SB_PHP_FE(SBSSHUtils, ReadUINT16, arginfo_SBSSHUtils_ReadUINT16)
	SB_PHP_FE(SBSSHUtils, ReadUINT64, arginfo_SBSSHUtils_ReadUINT64)
	SB_PHP_FE(SBSSHUtils, WriteSSH2MPInt, arginfo_SBSSHUtils_WriteSSH2MPInt)
	SB_PHP_FE(SBSSHUtils, WriteBoolean, arginfo_SBSSHUtils_WriteBoolean)

	// SBSSHCommon unit functions
	SB_PHP_FE(SBSSHCommon, SSHEncodeString, arginfo_SBSSHCommon_SSHEncodeString)
	SB_PHP_FE(SBSSHCommon, SSHDecodeString, arginfo_SBSSHCommon_SSHDecodeString)
	SB_PHP_FE(SBSSHCommon, SSHMemoryManager, arginfo_SBSSHCommon_SSHMemoryManager)

#ifdef SB_WINDOWS
	// SBSSHAuthAgent unit functions
	SB_PHP_FE(SBSSHAuthAgent, PageantAvailable, arginfo_SBSSHAuthAgent_PageantAvailable)
	SB_PHP_FE(SBSSHAuthAgent, ParseAccessInfo, arginfo_SBSSHAuthAgent_ParseAccessInfo)
#endif

	// SBSSLCommon unit functions
	SB_PHP_FE(SBSSLCommon, ConvertAlertDescriptionToErrorCode, arginfo_SBSSLCommon_ConvertAlertDescriptionToErrorCode)
	SB_PHP_FE(SBSSLCommon, ConvertSSLError, arginfo_SBSSLCommon_ConvertSSLError)
	SB_PHP_FE(SBSSLCommon, GetAlertDescriptionFromValidityReason, arginfo_SBSSLCommon_GetAlertDescriptionFromValidityReason)
	SB_PHP_FE(SBSSLCommon, GetSecondsCount, arginfo_SBSSLCommon_GetSecondsCount)
	SB_PHP_FE(SBSSLCommon, GetCurveByTlsCurve, arginfo_SBSSLCommon_GetCurveByTlsCurve)
	SB_PHP_FE(SBSSLCommon, GetTlsCurveByCurve, arginfo_SBSSLCommon_GetTlsCurveByCurve)
	SB_PHP_FE(SBSSLCommon, ReadLengthPrefixedArray, arginfo_SBSSLCommon_ReadLengthPrefixedArray)
	SB_PHP_FE(SBSSLCommon, SSLMemoryManager, arginfo_SBSSLCommon_SSLMemoryManager)

	// SBSSLServer unit functions
	SB_PHP_FE(SBSSLServer, CreateSSLServerTemplate, arginfo_SBSSLServer_CreateSSLServerTemplate)
	SB_PHP_FE(SBSSLServer, GetTLSCipherSuiteByCode, arginfo_SBSSLServer_GetTLSCipherSuiteByCode)
	SB_PHP_FE(SBSSLServer, PrepareSSLServerEnvironment, arginfo_SBSSLServer_PrepareSSLServerEnvironment)
	SB_PHP_FE(SBSSLServer, GetSSLDHKeyLength, arginfo_SBSSLServer_GetSSLDHKeyLength)
	SB_PHP_FE(SBSSLServer, SetSSLDHKeyLength, arginfo_SBSSLServer_SetSSLDHKeyLength)

	// SBSessionPool unit functions
	SB_PHP_FE(SBSessionPool, FreeSessionContext, arginfo_SBSessionPool_FreeSessionContext)

	// SBXMLCore unit functions
	SB_PHP_FE(SBXMLCore, isXMLblank, arginfo_SBXMLCore_isXMLblank)
	SB_PHP_FE(SBXMLCore, isXMLIdeographic, arginfo_SBXMLCore_isXMLIdeographic)
	SB_PHP_FE(SBXMLCore, isXMLBaseChar, arginfo_SBXMLCore_isXMLBaseChar)
	SB_PHP_FE(SBXMLCore, isXMLCombining, arginfo_SBXMLCore_isXMLCombining)
	SB_PHP_FE(SBXMLCore, isXMLDigit, arginfo_SBXMLCore_isXMLDigit)
	SB_PHP_FE(SBXMLCore, isXMLExtender, arginfo_SBXMLCore_isXMLExtender)
	SB_PHP_FE(SBXMLCore, XMLGetPrefix, arginfo_SBXMLCore_XMLGetPrefix)
	SB_PHP_FE(SBXMLCore, XMLGetLocalName, arginfo_SBXMLCore_XMLGetLocalName)

	// SBXMLUtils unit functions
	SB_PHP_FE(SBXMLUtils, ParseElementFromXMLString, arginfo_SBXMLUtils_ParseElementFromXMLString)
	SB_PHP_FE(SBXMLUtils, ParseNodeListFromXMLString, arginfo_SBXMLUtils_ParseNodeListFromXMLString)
	SB_PHP_FE(SBXMLUtils, ConvertToBase64String, arginfo_SBXMLUtils_ConvertToBase64String)
	SB_PHP_FE(SBXMLUtils, ConvertFromBase64String, arginfo_SBXMLUtils_ConvertFromBase64String)
	SB_PHP_FE(SBXMLUtils, ConvertBinaryToBigInt, arginfo_SBXMLUtils_ConvertBinaryToBigInt)
	SB_PHP_FE(SBXMLUtils, ConvertBigIntToBinary, arginfo_SBXMLUtils_ConvertBigIntToBinary)
	SB_PHP_FE(SBXMLUtils, ConvertHexToBinary, arginfo_SBXMLUtils_ConvertHexToBinary)
	SB_PHP_FE(SBXMLUtils, AddTextToXMLElement, arginfo_SBXMLUtils_AddTextToXMLElement)
	SB_PHP_FE(SBXMLUtils, InsertTextBeforeXMLElement, arginfo_SBXMLUtils_InsertTextBeforeXMLElement)
	SB_PHP_FE(SBXMLUtils, GetTextFromXMLElement, arginfo_SBXMLUtils_GetTextFromXMLElement)
	SB_PHP_FE(SBXMLUtils, GetStrictTextFromXMLElement, arginfo_SBXMLUtils_GetStrictTextFromXMLElement)
	SB_PHP_FE(SBXMLUtils, FindChildElementByLocalName, arginfo_SBXMLUtils_FindChildElementByLocalName)
	SB_PHP_FE(SBXMLUtils, FindChildElement, arginfo_SBXMLUtils_FindChildElement)
	SB_PHP_FE(SBXMLUtils, FindElementById, arginfo_SBXMLUtils_FindElementById)
	SB_PHP_FE(SBXMLUtils, FindElementByName, arginfo_SBXMLUtils_FindElementByName)
	SB_PHP_FE(SBXMLUtils, ExtractIdFromLocalURI, arginfo_SBXMLUtils_ExtractIdFromLocalURI)
	SB_PHP_FE(SBXMLUtils, GetElementId, arginfo_SBXMLUtils_GetElementId)
	SB_PHP_FE(SBXMLUtils, SetElementId, arginfo_SBXMLUtils_SetElementId)
	SB_PHP_FE(SBXMLUtils, CanonicalizationMethodToURI, arginfo_SBXMLUtils_CanonicalizationMethodToURI)
	SB_PHP_FE(SBXMLUtils, URIToCanonicalizationMethod, arginfo_SBXMLUtils_URIToCanonicalizationMethod)
	SB_PHP_FE(SBXMLUtils, AddPrefixes, arginfo_SBXMLUtils_AddPrefixes)
	SB_PHP_FE(SBXMLUtils, DateTimeToXMLString, arginfo_SBXMLUtils_DateTimeToXMLString)
	SB_PHP_FE(SBXMLUtils, XMLStringToDateTime, arginfo_SBXMLUtils_XMLStringToDateTime)
	SB_PHP_FE(SBXMLUtils, DateTimeFormatToString, arginfo_SBXMLUtils_DateTimeFormatToString)
	SB_PHP_FE(SBXMLUtils, DecodeXMLEntities, arginfo_SBXMLUtils_DecodeXMLEntities)
	SB_PHP_FE(SBXMLUtils, EncodeXMLEntities, arginfo_SBXMLUtils_EncodeXMLEntities)

	// SBXMLAdES unit functions
	SB_PHP_FE(SBXMLAdES, GetXAdESVersion, arginfo_SBXMLAdES_GetXAdESVersion)
	SB_PHP_FE(SBXMLAdES, GetXAdESNamespaceURI, arginfo_SBXMLAdES_GetXAdESNamespaceURI)
	SB_PHP_FE(SBXMLAdES, GetXAdESReferenceType, arginfo_SBXMLAdES_GetXAdESReferenceType)
	SB_PHP_FE(SBXMLAdES, XAdESVersionToString, arginfo_SBXMLAdES_XAdESVersionToString)
	SB_PHP_FE(SBXMLAdES, XAdESFormToString, arginfo_SBXMLAdES_XAdESFormToString)
	SB_PHP_FE(SBXMLAdES, XAdESFormGreaterThan, arginfo_SBXMLAdES_XAdESFormGreaterThan)
	SB_PHP_FE(SBXMLAdES, XAdESFormGreaterOrEqual, arginfo_SBXMLAdES_XAdESFormGreaterOrEqual)
	SB_PHP_FE(SBXMLAdES, IsExtendedXAdESForm, arginfo_SBXMLAdES_IsExtendedXAdESForm)
	SB_PHP_FE(SBXMLAdES, XAdESFormToExtendedForm, arginfo_SBXMLAdES_XAdESFormToExtendedForm)
	SB_PHP_FE(SBXMLAdES, XAdESFormToStandardForm, arginfo_SBXMLAdES_XAdESFormToStandardForm)

	// SBXMLSec unit functions
	SB_PHP_FE(SBXMLSec, ToCryptoBinary, arginfo_SBXMLSec_ToCryptoBinary)
	SB_PHP_FE(SBXMLSec, FindChildElementEnc, arginfo_SBXMLSec_FindChildElementEnc)
	SB_PHP_FE(SBXMLSec, FindChildElementSig, arginfo_SBXMLSec_FindChildElementSig)
	SB_PHP_FE(SBXMLSec, FindChildElementXAdES, arginfo_SBXMLSec_FindChildElementXAdES)
	SB_PHP_FE(SBXMLSec, CalculateDigest, arginfo_SBXMLSec_CalculateDigest)
	SB_PHP_FE(SBXMLSec, CalculateDigestStream, arginfo_SBXMLSec_CalculateDigestStream)
	SB_PHP_FE(SBXMLSec, DigestMethodToHashAlgorithm, arginfo_SBXMLSec_DigestMethodToHashAlgorithm)
	SB_PHP_FE(SBXMLSec, DigestMethodToURI, arginfo_SBXMLSec_DigestMethodToURI)
	SB_PHP_FE(SBXMLSec, URIToDigestMethod, arginfo_SBXMLSec_URIToDigestMethod)
	SB_PHP_FE(SBXMLSec, GetDigestMethodFromSignatureMethod, arginfo_SBXMLSec_GetDigestMethodFromSignatureMethod)
	SB_PHP_FE(SBXMLSec, HashAlgorithmToDigestMethod, arginfo_SBXMLSec_HashAlgorithmToDigestMethod)
	SB_PHP_FE(SBXMLSec, FormatRDN, arginfo_SBXMLSec_FormatRDN)
	SB_PHP_FE(SBXMLSec, ExtractRDN, arginfo_SBXMLSec_ExtractRDN)
	SB_PHP_FE(SBXMLSec, RDNDescriptorMap, arginfo_SBXMLSec_RDNDescriptorMap)

	// SBXMLTransform unit functions
	SB_PHP_FE(SBXMLTransform, Initialize, arginfo_SBXMLTransform_Initialize)
	SB_PHP_FE(SBXMLTransform, LoadDocumentFromData, arginfo_SBXMLTransform_LoadDocumentFromData)
	SB_PHP_FE(SBXMLTransform, NodeToNodeList, arginfo_SBXMLTransform_NodeToNodeList)
	SB_PHP_FE(SBXMLTransform, RegisterTransformClass, arginfo_SBXMLTransform_RegisterTransformClass)
	SB_PHP_FE(SBXMLTransform, UnregisterTransformClass, arginfo_SBXMLTransform_UnregisterTransformClass)
	SB_PHP_FE(SBXMLTransform, FindTransformClass, arginfo_SBXMLTransform_FindTransformClass)

	// SBXMLSOAPCore unit functions
	SB_PHP_FE(SBXMLSOAPCore, GetSOAPNamespaceURI, arginfo_SBXMLSOAPCore_GetSOAPNamespaceURI)
	SB_PHP_FE(SBXMLSOAPCore, SOAPSecGetElementId, arginfo_SBXMLSOAPCore_SOAPSecGetElementId)
	SB_PHP_FE(SBXMLSOAPCore, SOAPSecSetElementId, arginfo_SBXMLSOAPCore_SOAPSecSetElementId)

	// SBXMLWSSCore unit functions
	SB_PHP_FE(SBXMLWSSCore, WSUGetElementId, arginfo_SBXMLWSSCore_WSUGetElementId)
	SB_PHP_FE(SBXMLWSSCore, WSUSetElementId, arginfo_SBXMLWSSCore_WSUSetElementId)
	SB_PHP_FE(SBXMLWSSCore, WSSETokenTypeToURI, arginfo_SBXMLWSSCore_WSSETokenTypeToURI)

	// SBXMLSOAP unit functions
	SB_PHP_FE(SBXMLSOAP, RegisterSecurityHandler, arginfo_SBXMLSOAP_RegisterSecurityHandler)
	SB_PHP_FE(SBXMLSOAP, UnregisterSecurityHandler, arginfo_SBXMLSOAP_UnregisterSecurityHandler)
	SB_PHP_FE(SBXMLSOAP, Initialize, arginfo_SBXMLSOAP_Initialize)

	// SBXMLSOAPClient unit functions
	SB_PHP_FE(SBXMLSOAPClient, SOAPParametersManager, arginfo_SBXMLSOAPClient_SOAPParametersManager)

	// SBArcBase unit functions
	SB_PHP_FE(SBArcBase, GetUseUTCTimeInNewEntries, arginfo_SBArcBase_GetUseUTCTimeInNewEntries)
	SB_PHP_FE(SBArcBase, SetUseUTCTimeInNewEntries, arginfo_SBArcBase_SetUseUTCTimeInNewEntries)

	// SBZipUtils unit functions
	SB_PHP_FE(SBZipUtils, BufferToUINT16, arginfo_SBZipUtils_BufferToUINT16)
	SB_PHP_FE(SBZipUtils, UINT16ToBuffer, arginfo_SBZipUtils_UINT16ToBuffer)
	SB_PHP_FE(SBZipUtils, BufferToUINT32, arginfo_SBZipUtils_BufferToUINT32)
	SB_PHP_FE(SBZipUtils, UINT32ToBuffer, arginfo_SBZipUtils_UINT32ToBuffer)
	SB_PHP_FE(SBZipUtils, BufferToUINT64, arginfo_SBZipUtils_BufferToUINT64)
	SB_PHP_FE(SBZipUtils, UINT64ToBuffer, arginfo_SBZipUtils_UINT64ToBuffer)
	SB_PHP_FE(SBZipUtils, ReverseBuffer, arginfo_SBZipUtils_ReverseBuffer)
	SB_PHP_FE(SBZipUtils, ZipInitializeEncryption, arginfo_SBZipUtils_ZipInitializeEncryption)
	SB_PHP_FE(SBZipUtils, ZipUpdateKeys, arginfo_SBZipUtils_ZipUpdateKeys)
	SB_PHP_FE(SBZipUtils, ZipEncrypt, arginfo_SBZipUtils_ZipEncrypt)
	SB_PHP_FE(SBZipUtils, ZipDecrypt, arginfo_SBZipUtils_ZipDecrypt)
	SB_PHP_FE(SBZipUtils, ZipHashAlgorithmToSBB, arginfo_SBZipUtils_ZipHashAlgorithmToSBB)
	SB_PHP_FE(SBZipUtils, SBBHashAlgorithmToZip, arginfo_SBZipUtils_SBBHashAlgorithmToZip)
	SB_PHP_FE(SBZipUtils, ZipSymmetricAlgorithmToSBB, arginfo_SBZipUtils_ZipSymmetricAlgorithmToSBB)
	SB_PHP_FE(SBZipUtils, ZipCipherDefaultKeySize, arginfo_SBZipUtils_ZipCipherDefaultKeySize)
	SB_PHP_FE(SBZipUtils, ZipCipherIVSize, arginfo_SBZipUtils_ZipCipherIVSize)
	SB_PHP_FE(SBZipUtils, ZipCompressionMethodName, arginfo_SBZipUtils_ZipCompressionMethodName)
	SB_PHP_FE(SBZipUtils, ZipEncryptionAlgorithmName, arginfo_SBZipUtils_ZipEncryptionAlgorithmName)
	SB_PHP_FE(SBZipUtils, ZipVersionStr, arginfo_SBZipUtils_ZipVersionStr)
	SB_PHP_FE(SBZipUtils, OEMEncodingName, arginfo_SBZipUtils_OEMEncodingName)
	SB_PHP_FE(SBZipUtils, ANSIEncodingName, arginfo_SBZipUtils_ANSIEncodingName)
	SB_PHP_FE(SBZipUtils, CopyStreamPart, arginfo_SBZipUtils_CopyStreamPart)

	// SBXMLSAMLBind unit functions
	SB_PHP_FE(SBXMLSAMLBind, ParseHTTPParameters, arginfo_SBXMLSAMLBind_ParseHTTPParameters)

	// SBXMLSAMLCommon unit functions
	SB_PHP_FE(SBXMLSAMLCommon, XMLDocToStr, arginfo_SBXMLSAMLCommon_XMLDocToStr)

	// SBXMLSAMLCore unit functions
	SB_PHP_FE(SBXMLSAMLCore, GetSAMLNSMap, arginfo_SBXMLSAMLCore_GetSAMLNSMap)
	SB_PHP_FE(SBXMLSAMLCore, SetSAMLNSMap, arginfo_SBXMLSAMLCore_SetSAMLNSMap)
	SB_PHP_FE(SBXMLSAMLCore, CreateElementNS, arginfo_SBXMLSAMLCore_CreateElementNS)
	SB_PHP_FE(SBXMLSAMLCore, StreamToStr, arginfo_SBXMLSAMLCore_StreamToStr)
	SB_PHP_FE(SBXMLSAMLCore, StreamToStrUTF8, arginfo_SBXMLSAMLCore_StreamToStrUTF8)
	SB_PHP_FE(SBXMLSAMLCore, StreamToArray, arginfo_SBXMLSAMLCore_StreamToArray)
	SB_PHP_FE(SBXMLSAMLCore, FindChildElement, arginfo_SBXMLSAMLCore_FindChildElement)
	SB_PHP_FE(SBXMLSAMLCore, FreeList, arginfo_SBXMLSAMLCore_FreeList)
	SB_PHP_FE(SBXMLSAMLCore, XMLStrToBool, arginfo_SBXMLSAMLCore_XMLStrToBool)
	SB_PHP_FE(SBXMLSAMLCore, BoolToXMLStr, arginfo_SBXMLSAMLCore_BoolToXMLStr)
	SB_PHP_FE(SBXMLSAMLCore, GenerateID, arginfo_SBXMLSAMLCore_GenerateID)
	SB_PHP_FE(SBXMLSAMLCore, RandomString, arginfo_SBXMLSAMLCore_RandomString)
	SB_PHP_FE(SBXMLSAMLCore, DateTimeToString, arginfo_SBXMLSAMLCore_DateTimeToString)
	SB_PHP_FE(SBXMLSAMLCore, CurrentDateTime, arginfo_SBXMLSAMLCore_CurrentDateTime)

	// SBXMLSAMLMetadata unit functions
	SB_PHP_FE(SBXMLSAMLMetadata, ContactTypeToStr, arginfo_SBXMLSAMLMetadata_ContactTypeToStr)
	SB_PHP_FE(SBXMLSAMLMetadata, StrToContactType, arginfo_SBXMLSAMLMetadata_StrToContactType)
	SB_PHP_FE(SBXMLSAMLMetadata, KeyUsageToStr, arginfo_SBXMLSAMLMetadata_KeyUsageToStr)
	SB_PHP_FE(SBXMLSAMLMetadata, StrToKeyUsage, arginfo_SBXMLSAMLMetadata_StrToKeyUsage)

	PHP_FE_END
};

zend_module_entry sbb_module_entry = {
	STANDARD_MODULE_HEADER,
	"SecureBlackbox",
	sbb_functions,
	PHP_MINIT(sbb),
	PHP_MSHUTDOWN(sbb),
	PHP_RINIT(sbb),
	PHP_RSHUTDOWN(sbb),
	PHP_MINFO(sbb),
	PHP_SBB_VERSION,
	STANDARD_MODULE_PROPERTIES
};
